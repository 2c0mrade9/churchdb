<?php

class SimplePager {

	public $totalPages;
	public $startRow;
	
	public function SimplePager($rowsPerPage, $numRows, $currentPage = 1) {
		
		$this->totalPages = ceil(($numRows) / $rowsPerPage);
		
		if($currentPage < 1) {
			$currentPage = 1;
		} else if($currentPage > $this->totalPages) {
			$currentPage = $this->totalPages;
		}
		
		$this->startRow = (($currentPage - 1) * $rowsPerPage);
		
	}
	
	function getTotalPages() {
		return $this->totalPages;
	}
	
	function getStartRow() {
		return $this->startRow;
	}
	
	function rowsPerPage() {
		return $this->rowsPerPage;
	}
	
}
?>