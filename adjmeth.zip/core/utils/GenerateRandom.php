<?php
/**
*@generate a random pin
*@this is used for all the pin generations
*@passport, drivers licence and birth certificate
*@a 8 number random keys
**/
function generateRandomFileNumber($iLen = 6) {
    $sRes = '';
	
	/**
	*@integers for the pin generation
	**/
    $sChars = "0123456789";
    for ($i = 0; $i < $iLen; $i++) {
        $z = rand(0, strlen($sChars) -1);
        $sRes .= $sChars[$z];
    }
	
	/**
	*@pass the newly generated key into a session
	*@$_SESSION['getRandomPIN']
	**/
	$_SESSION['getRandomPIN'] = $sRes;
    return $sRes;
}

function generateRandomString($iLen = 8) {
    $sRes = '';
	
	/**
	*@integers for the pin generation
	**/
    $sChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for ($i = 0; $i < $iLen; $i++) {
        $z = rand(0, strlen($sChars) -1);
        $sRes .= $sChars[$z];
    }
	
	/**
	*@pass the newly generated key into a session
	*@$_SESSION['getRandomPIN']
	**/
	$_SESSION['getRandomPIN'] = $sRes;
    return $sRes;
}


/**
*@generate a random pin
*@this is used for all the pin generations
*@voucher uid
*@a 6 number random keys
**/
function generateRandomVoucherUID($iLen = 6) {
    $sRes = '';
	
	/**
	*@integers for the pin generation
	**/
    $sChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for ($i = 0; $i < $iLen; $i++) {
        $z = rand(0, strlen($sChars) -1);
        $sRes .= $sChars[$z];
    }
	
	/**
	*@pass the newly generated key into a session
	*@$_SESSION['getRandomPIN']
	**/
	$_SESSION['getRandomPIN'] = $sRes;
    return $sRes;
}


/**
*@generate a random pin
*@this is used for all the pin generations
*@voucher pin
*@a 8 number random keys
**/
function generateRandomVoucherPIN($iLen = 12) {
    $sRes = '';
	
	/**
	*@integers for the pin generation
	**/
    $sChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for ($i = 0; $i < $iLen; $i++) {
        $z = rand(0, strlen($sChars) -1);
        $sRes .= $sChars[$z];
    }
	
	/**
	*@pass the newly generated key into a session
	*@$_SESSION['getRandomPIN']
	**/
	$_SESSION['getRandomPIN'] = $sRes;
    return $sRes;
}
?>