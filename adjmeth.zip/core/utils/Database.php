<?php
/** A PHP class to access the Database Model as well as other related pages
  * in an object oriented way, and with a powerful debug system.\n
  * Licence:  LGPL \n
  * Web site: http://yomaioutreach.org
  * @version  1.0
  * @author   Emmanuel Obeng (emmallob14@gmail.com | obeng@yomaioutreach.org)
*/
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    die("<h1 align='center'>
		WELCOME:<br>
		SORRY! Unable to Connect to the Database.<br>
		Please contact the Web Administrator.<Br>
		Thank You.
		</h1>");
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
class Database {
	
	/*
	* Create variables for credientials to MySQl database
	* the database connection link
	* the database name
	* the password
	*/	
	private $dbhost = DB_HOST;
	private $dbuser = DB_USER;
	private $dbname = DB_NAME;
	private $dbpass = DB_PASS;
	private $query = NULL;
	private $con = NULL;
	private $result = array();
	
	/**
	 *@call the connection function
	 **/
	public function __construct() {
        $this->connect();
    }
	
	public function superAdministrator() {
		return FALSE;
	}
	
	public function connect() {
		if($this->con == NULL) {
			//connect to the database
			$this->mysqli = @new mysqli($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname);
			
			if($this->mysqli->connect_errno) {
				//Diplay error message
				die("<h1 align='center'>
				WELCOME TO: YOMAI-OUTREACH Official Website<br>
				SORRY! Unable to Connect to the Database.<br>
				Please contact the Web Administrator.<Br>
				Thank You.
				</h1>");			
			} else {
				//set the connection to true
				$this->con = true;
				return true;
			}
		} else {
			return false;
		}
	}
	
	
	public function getConnection() {
		return $this->con;	
	}
	
	public function disconnect() {
		if($this->con) {
			if(@mysqli_close($this->con)) {
				$this->con = false;
				return true;
			} else {
				return false;
			} 
		}
	}
	
	/*
	 *@query the database
	 *@request table and where clauses@
	 *
	*/
	public function select($sql) {
		$query = $this->mysqli->query($sql);
		return $query;
	}
	
	public function insert($sql) {
		$query = $this->mysqli->query($sql);
		
		if($query) {
			return $query;
		} else {
			return @mysqli_error($this->con);
		}
	}
	
	public function simple_insert($table, $data) {
		$query = $this->mysqli->query("INSERT INTO `$table` VALUES ($data)");
		
		if($query) {
			return $query;
		} else {
			return @mysqli_error($this->con);
		}
	}
	/*
	*@count the number of rows
	*/	
	public function scount($sql) {
		if($sql) {
			return mysqli_num_rows($sql);
		} else {
			return @mysqli_error($this->con);
		}
	}
	
	public function maxOfAll($column, $table) {
		$this->mQuery = $this->select("SELECT MAX(`$column`) as ID FROM `$table`");
		while($result = $this->mQuery->fetch_assoc()) {
			return $result['ID'];
		}
	}
	
	function maxOf($column, $table, $where) {
		$this->mQuery = $this->select("SELECT MAX(`$column`) as ID FROM `$table` WHERE $where");
		while($result = $this->mQuery->fetch_assoc()) {
			return $result['ID'];
		}
    }
	
	public function countOf($table, $where) {
		$this->mQuery = $this->select("SELECT COUNT(*) as Count FROM `$table` WHERE $where");
		while($result = $this->mQuery->fetch_assoc()) {
			return $result['Count'];
		}
    }
    /** Get the count of rows in a table.
      * @param $table The table where to compute the number of rows.
      * @return The number of rows (0 or more).
      */
    public function countOfAll($table) {
		$this->mQuery = $this->select("SELECT COUNT(*) as Count FROM `$table`");
		while($result = $this->mQuery->fetch_assoc()) {
			return $result['Count'];
		}
    }

	public function update($sql) {
		if($sql) {
			return $this->mysqli->query($sql);
		} else {
			return @mysqli_error($this->con);
		}
	}
	
	public function delete($table, $where) {
		$query = $this->mysqli->query("DELETE FROM `$table` $where");
		if($query) {
			return $query;
		} else {
			return @mysqli_error($this->con);
		}
	}
	
	public function db_error() {
		return mysqli_error($this->mysqli);
	}
	/**
	 * Get the insert id of the query
	 *
	 */
	public function getInsertId() {
	   return $this->mysqli->insert_id;   
	}
	
	/**
	 * Returns the database object used by the manager
	 * @return cleanData
	 * Cleans the user inputs 
	*/	
	public function cleanData($theValue) {
			
		if (PHP_VERSION < 6) {
			$theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
		}
			
		$theValue = function_exists("mysqli_real_escape_string") ? $this->mysqli->escape_string($theValue) : $this->mysqli->escape_string($theValue);
		//$theValue =  preg_replace("/(?![.=$'€%-])\p{P}/u", '', $theValue);
		$theValue = filter_var($theValue, FILTER_SANITIZE_STRING);

		$theValue = trim(stripslashes($theValue));
		
		return $theValue;
	}
	
	public function cleanOthers($theValue) {
			
		if (PHP_VERSION < 6) {
			$theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
		}
			
		$theValue = function_exists("mysqli_real_escape_string") ? $this->mysqli->escape_string($theValue) : $this->mysqli->escape_string($theValue);
		$theValue = filter_var($theValue, FILTER_SANITIZE_STRING);

		$theValue = trim(stripslashes($theValue));
		
		return $theValue;
	}
	
	public function filter_sanitize_email($value, $params = NULL) {
		if(filter_var($value, FILTER_VALIDATE_EMAIL)):
			return $value;
		else:
			return "";
		endif;
	}

	public function filter_htmlencode($value, $params = NULL) {
		return filter_var($value, FILTER_SANITIZE_SPECIAL_CHARS);  
	}
	
	/**
	 * Returns the database object used by the manager
	 * @return cleanData
	 * validates only strings
	*/
	public function str_validate($validString){
		
		$name_exp = "/^[a-zA-Z][A-Za-z]+$/";
		
		if(!preg_match($name_exp, $validString)):
			return false;
		else:
			return true;
		endif;
		
	}
			
	/**
	 * get the results of the query
	 * @return results
	 **/
	public function getResult() {
		return $this->result;
	}
}
?>
