<?php
$page = '';
$addLink = '';
$catappend = '';

if(!isset($_POST['cpage']) || empty($_POST['cpage']) || $_POST['cpage']=="" || $_POST['cpage']==" ")
	$page = 1;
else
	$page = $db->cleanData($_POST['cpage']);

if(isset($_POST['q']))
	$addLink .= 'q='.$_GET['q'];	

if(isset($_POST['cat']))
	$addLink .= '&cat='.$_GET['cat'];	

	
if(isset($_POST['gallery_category']))
	$addLink .= 'gallery_category='.$_GET['gallery_category'];	

	
$pager = new SimplePager($rowsPerPage, $counter, $page);

$paginate = '<div class="pd_pagination_system">';

if($page == 1) {
	$paginate .= '<span class="disabled">Prev</span>';
} else {
	$prevpage = $page - 1;
	$paginate .= "<a href='?$addLink&cpage=1'>First Page</a>";
	$paginate .= "<a href='?$addLink&cpage=$prevpage'>Prev</a>";
}
 	
for ($i = 1; $i <= $pager->getTotalPages(); $i++) {
	
	$paginate .= "<a href=\"?$addLink&cpage=$i\">";
	if ($i == $page) {
		$paginate .= '<span class="current">' .$i. '</span>';
	} else {
		$paginate .= $i;
	}
	$paginate .= '</a>';
	
	
}

if($page == $pager->getTotalPages()) {
	$paginate .= '<span class="disabled">Next</span>';
} else {
	$nextpage = $page + 1;
	$paginate .= "<a href='?$addLink&cpage=$nextpage'>Next</a>";
	$paginate .= "<a href='?$addLink&cpage=".$pager->getTotalPages()."'>Last Page</a>";
}

$paginate .= '</div>';

?>
