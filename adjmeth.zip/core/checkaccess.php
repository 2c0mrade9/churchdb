<?php
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
//start a new session
//assign some initial variables
$restrictGoTo = "login.php";
$db = new Database;

//check if the user is logged in
if(!isset($_SESSION['theAdjMethAdminLoggedIn'])) {
	//generating the redirection url
	require 'pages/login.php';
	exit;
} else {
	$session = $_SESSION['theAdjMethAdminLoggedIn'];
	
	if($db->scount($db->select("select sessions from adjmeth_sessions where sessions='$session' limit 1")) < 1) {
		header("location: ".SITE_URL."/login?logout&expired&true");
		exit();
	}
} 
?>
