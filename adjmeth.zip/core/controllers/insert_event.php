<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['name'])) {
	$end_date=$db->cleanData($_POST['end_date']);
	$start_date=$db->cleanData($_POST['start_date']);
	$name=ucwords($db->cleanData($_POST['name']));
	$end_time=$db->cleanData($_POST['end_time']);
	$start_time=$db->cleanData($_POST['start_time']);
	$details=$db->cleanData($_POST['details']);
	$event_members=$db->cleanData($_POST['event_members']);
	$event_visitors=$db->cleanData($_POST['event_visitors']);
	$event_total=$db->cleanData($_POST['event_total']);
	$ministry = $db->cleanData($_POST['ministry']);
	$ministry_slug = $models->create_slug($ministry);
	$alias = $models->create_slug($name." ".$start_date);
	$ministry_sel = "<option value='{$ministry}'>".$ministry."</option>";
	
	//check if the category already exists
	$check = $db->select("SELECT * FROM adjmeth_events WHERE `slug`='$alias'");
	if($db->scount($check) > 0) {
		print "<font color=red> Dublicate Entry. Please Verify</font>";
	} else {

		$ins = $db->insert("INSERT INTO adjmeth_events 
		(name,slug,start_date,end_date,start_time,end_time,
		details,total,members,visitors,ministry,ministry_slug,entry,status) 
		values ('$name','$alias','$start_date','$end_date',
		'$details','$event_total','$event_members','$event_visitors',
		'$ministry','$ministry_slug',now(),'1')");
?>
	<script>window.location.href="<?php print SITE_URL; ?>/add_event?success";</script>
<?php
	}	

} else {
	$start_date = "";
	$end_date = "";
	$start_time = "9:00";
	$end_time = "12:00";
	$name 	= "";
	$details = "";
	$event_total="0";
	$event_members="0";
	$event_visitors="0";
	$ministry_sel = "";
}			

?>
