<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;
$events = new EventsModel;

if(isset($_POST['Submit']) and isset($_POST['name'])) {
	$end_date=$db->cleanData($_POST['end_date']);
	$start_date=$db->cleanData($_POST['start_date']);
	$end_time=$db->cleanData($_POST['end_time']);
	$start_time=$db->cleanData($_POST['start_time']);
	$name=ucwords($db->cleanData($_POST['name']));
	$event_members=$db->cleanData($_POST['event_members']);
	$event_visitors=$db->cleanData($_POST['event_visitors']);
	$event_total=$db->cleanData($_POST['event_total']);
	//get the members 
	if($event_members==0)
		$event_members=$event_total;
	//continue
	$details=$db->cleanData($_POST['details']);
	$ministry = $db->cleanData($_POST['ministry']);
	$status = $db->cleanData($_POST['status']);
	$ministry_slug = $models->create_slug($ministry);
	$eid = $events->EventById($ACTION[1], "alias")->eid;
	$slug = $events->EventById($ACTION[1], "alias")->eslug;
	$alias = $models->create_slug($name." ".$start_date);
	$ministry_sel = "<option value='{$ministry}'>".$ministry."</option>";
	$status_sel = "<option value='{$status}'>".$status."</option>";
	
	//check if the category already exists
	$check = $db->select("SELECT * FROM adjmeth_events WHERE `slug`='$slug'");
	if($db->scount($check) != 1) {
		print "<font color=red>Sorry this Event does not exist in the database</font>";
	} else {

		$update = $db->update("UPDATE adjmeth_events SET 
				name='$name',slug='$alias',start_date='$start_date',end_date='$end_date',
				start_time='".strtotime($start_time)."',end_time='".strtotime($end_time)."',
				details='$details',total='$event_total',members='$event_members',
				visitors='$event_visitors',ministry='$ministry',
				ministry_slug='$ministry_slug',e_status='$status' WHERE id='$eid'");
		if($update) {
?>
	<script>window.location.href="<?php print SITE_URL; ?>/update_event/<?php print $alias; ?>/update_event?success";</script>
<?php	} else {
?>
	<script>alert("Sorry there was an error in updating the Event Information");</script>
<?php
		}
	}	

} else {
	$start_date = $events->EventById($ACTION[1], "alias")->esdate;
	$end_date = $events->EventById($ACTION[1], "alias")->eedate;
	$name 	= $events->EventById($ACTION[1], "alias")->ename;
	$details = $events->EventById($ACTION[1], "alias")->edetails;
	$ministry_sel = $events->EventById($ACTION[1], "alias")->eministry_opt;
	$status_sel = $events->EventById($ACTION[1], "alias")->estatus_opt;
	$start_time= $events->EventById($ACTION[1], "alias")->estime;
	$end_time= $events->EventById($ACTION[1], "alias")->eetime;
	$event_total=$events->EventById($ACTION[1], "alias")->etotal;
	$event_members=$events->EventById($ACTION[1], "alias")->emembers;
	$event_visitors=$events->EventById($ACTION[1], "alias")->evisitors;
}			

?>
