<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;
$member = new MemberModel;
$class = new ClassModel;
$cat = new OrganizationModel;

if(isset($_POST['Submit']) and isset($_POST['cname'])) {
	$cleader=$db->cleanData($_POST['cleader']);
	$acleader=$db->cleanData($_POST['acleader']);
	$cname=ucwords($db->cleanData($_POST['cname']));
	$csecretary=$db->cleanData($_POST['csecretary']);
	$alias = $models->create_slug($cname);
	$classid = $db->cleanData($_POST['classid']);
	
	//check if the category already exists
	$ncl = $member->MemberById($models->create_slug($cleader),null,"create","slug")->mem_fulln;
	$nacl = $member->MemberById($models->create_slug($acleader),null,"create","slug")->mem_fulln;
	$ncs = $member->MemberById($models->create_slug($csecretary),null,"create","slug")->mem_fulln;

	
	$update = $db->update("update adjmeth_class set
			name='$cname',slug='$alias',class_leader='$ncl',class_leader_assist='$nacl',class_secretary='$ncs'
			where slug='$classid'
		");
?>
	<script>window.location.href="<?php print SITE_URL; ?>/update_class/<?php print $alias; ?>/view_class";</script>
<?php

} else {
	$cleader = $class->ClassById($ACTION[1],"alias")->cleader;
	$acleader = $class->ClassById($ACTION[1],"alias")->acleader;
	$cname 	= $class->ClassById($ACTION[1],"alias")->cname;
	$class_id 	= $class->ClassById($ACTION[1],"alias")->cid;
	$csecretary = $class->ClassById($ACTION[1],"alias")->csecretary;
}			

?>
