<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;
$members = new MemberModel;

if(isset($_POST['Submit']) and isset($_POST['cname'])) {
	$cname=$db->cleanData($_POST['cname']);
	$month=$db->cleanData($_POST['month']);
	$year=ucwords($db->cleanData($_POST['year']));
	$payee=$db->cleanData($_POST['paidby']);
	$amount=$db->cleanData($_POST['amount']);
	$alias = $models->create_slug($cname);
	$alias2 = $models->create_slug($payee);
	
	if($members->MemberById($alias,"","","slug")->found==true)
		$memberid=$members->MemberById($alias,"","","slug")->mem_id;
	else
		$memberid="";
	
	//check if all the fields are not empty
	if(empty($cname)){
		print "<font color=red> Name is required. Please Verify</font>";
	} elseif(empty($amount)){
		print "<font color=red> Amount is required. Please Verify</font>";
	} elseif(empty($payee)){
		print "<font color=red> Payee name is required. Please Verify</font>";
	} elseif(empty($month) || $month=="Null"){
		print "<font color=red> Month is required. Please Verify</font>";
	} elseif(empty($year)){
		print "<font color=red> Year is required. Please Verify</font>";
	} elseif(!is_numeric($amount)) {
		print "<font color=red> Amount should be numerics. Please Verify</font>";
	} else {
		//check if the payment already exists
		$check = $db->select("SELECT * FROM adjmeth_welfare
				WHERE `member_id`='$memberid' and month='$month' and year='$year'");
		if($db->scount($check) > 0) {
			print "<font color=red> Dublicate Entry. Please Verify</font>";
		} else {
			
			$admin =$_SESSION['AdjMethFullName'];
			
			if($members->MemberById($alias2,"","","slug")->found==true)
				$payeeid=$members->MemberById($alias2,"","","slug")->mem_id;
			else
				$payeeid="";
			
			$query="INSERT INTO adjmeth_welfare 
			(member_id,member,type,month,year,amount,paid_by,paid_byid,received_by,date_added,date_paid) 
			values ('$memberid','$cname','member','$month','$year',
					'$amount','$payee','$payeeid','$admin',now(),now())";
			
			$ins = $db->insert($query) or die($db->db_error());
			$db->insert("insert into adjmeth_welfare_history(query,date,admin)values
				('A Payment for the period $month $year was inserted. It was paid by $payee with ID $payeeid on behalf of $cname with ID $memberid. The amount paid was $amount and received by $admin.',now(),'$admin')");
?>
		<script>window.location.href="<?php print SITE_URL; ?>/add_welfare?success";</script>
<?php
		}
	}

} else {
	$cname = "";
	$payee = "";
	$amount = "";
	$month = "";
	$year = "";
}			

?>
