<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;

//initialization
$amount = "";
$pamount = "";
$description = "";
$redeem_date = "";
$name 	= "";
$pledges = "";
$harv_date="";
$harv_type_new="";
$mem_uid="";

$admin_id = $_SESSION["AdjMethUsername"];

global $db;

//check if the form has been submitted
if(isset($_POST['Submit'])) {
	
	//if the user wants to record harvest
	if(isset($_POST['recordHarvest'])) {
		$harv_date=$db->cleanData($_POST['harv_date']);
		$harv_type=ucwords($db->cleanData($_POST['harv_type']));
		$amount=$db->cleanData($_POST['amount']);
		$pledges=$db->cleanData($_POST['pledges']);
		$name=$db->cleanData($_POST['name']);
		$description=$db->cleanData($_POST['description']);
		
		$mon=date("m",strtotime($harv_date));
		$day=date("d",strtotime($harv_date));
		$year=date("Y",strtotime($harv_date));
		
		$rid = "HARV".$models->generateRandomNumber(8);
		
		if($pledges > $amount)
			$balance=$pledges-$amount;
		elseif($amount > $pledges)
			$balance=$pledges;
		
		if($harv_type=="NULL") {
			print "<font color=red> Sorry! Please select the Harvest Type.</font>";
		} else {
		//record harvests information
		$ins = $db->insert("INSERT INTO adjmeth_finance 
			(trancid,name_of,typename,typeid,typesub,typesubid,
			day,month,year,fulldate,amount,pledges,balance,
			recorded_by,recorded_date,modified_date,comments) 
			values
			('$rid','$name','Harvests','3','$harv_type','','$day',
			'$mon','$year','$harv_date','$amount','$pledges','$balance',
			'$admin_id',now(),now(),'$description')");
?>
		<script>window.location.href="<?php print SITE_URL; ?>/add_harvests?success";</script>
<?php	
		}
	}
	
	//check if the redeem harvest pledge form has been sent
	if(isset($_POST["redeemHarvestPledge"])) {
		
		//fetch the details
		if(isset($_POST["mem_uid"]))
			$mem_uid=$db->cleanData($_POST["mem_uid"]);
		if(isset($_POST["name"]))
			$name=$db->cleanData($_POST["name"]);
		if(isset($_POST["evt_type"]) and is_numeric($_POST["evt_type"])) {
			//assign variable to the event type
			$evt_type=$db->cleanData($_POST["evt_type"]);
			//generate a new option
			$sql_new = $db->select("SELECT * FROM `adjmeth_finance_type` WHERE `id`='$evt_type'");
			if($db->scount($sql_new)==1){
				$sql_res=$sql_new->fetch_assoc();
				$harv_type_new = "<option value='$evt_type' selected='selected'>{$sql_res["name"]}</option>";
			}		
			//check and assign variable to the event sub
			if(isset($_POST["evt_type_sub"]))
				$evt_type_sub=$db->cleanData($_POST["evt_type_sub"]);
			else
				$evt_type_sub="nullify";
			//continue
			$pamount=$db->cleanData($_POST["amount"]);
			//check if the amount is numeric
			if(is_numeric($pamount)) {
				//date mechanism
				$date=date("Y-m-d");
				//mechanism
				$mon=date("m",strtotime($date));
				$day=date("d",strtotime($date));
				$year=date("Y",strtotime($date));
				//check if the event type parsed is not a numeric
				if($evt_type_sub != "nullify") {
					//fetch the user pledge details
					$pdet=$db->select("select * from 
					adjmeth_finance_pledge where 
					trancid='$evt_type_sub' and mem_uid='$mem_uid'");
					//GENERATE REDEEM PLEDGE ID
					$pid = "RDPLG".$models->generateRandomNumber(8);
					//if any record was found in the database
					if($db->scount($pdet) > 0) {
						//assign variable
						$pl_res=$pdet->fetch_assoc();
						$amt_pledge=$pl_res["balance"];
						//continue
						//overdraft processing
						if($pamount>$amt_pledge)
							$overdraft=$pamount-$amt_pledge;
						else
							$overdraft=0.00;
						//balance processing
						if($amt_pledge>$pamount)
							$nbalance=$amt_pledge-$pamount;
						else
							$nbalance=0.00;
					} else {
						$nbalance=0.00;
						$overdraft=0.00;
					}
					
					//fetch the main entry in the database
					$ffsql = $db->select("SELECT * FROM `adjmeth_finance` 
					WHERE `trancid`='$evt_type_sub'");
					//assign variable
					$plf_res=$ffsql->fetch_assoc();
					$received=$plf_res["amount"];
					$pledges=$plf_res["pledges"];
					$fbalance=$plf_res["balance"];
					$foverdraft=$plf_res["overdraft"];
					//continue
					if($pamount > $pledges) {
						$new_balance=0.00;
						$new_amount=$received+$pamount;
						$new_overdraft=$foverdraft+($pamount-$pledges);
					} elseif($pamount < $pledges) {
						$new_balance=$fbalance-$pamount;
						$new_amount=$received+$pamount;
						$new_overdraft=$foverdraft;
					} elseif($pamount == $pledges) {
						$new_balance=0.00;
						$new_amount=$received+$pamount;
						$new_overdraft=$foverdraft+($pamount-$pledges);
					} 
					
					//insert the new record
					$db->insert("insert into adjmeth_finance
					(trancid,typename,typesub,
					membername,memberid,day,month,year,fulldate,
					amount,balance,overdraft,recorded_by,recorded_date)
					values
					('$pid','redeem-pledge','$evt_type_sub',
					'$name','$mem_uid','$day','$mon','$year',
					now(),'$pamount','$nbalance','$overdraft','$admin_id',now())");
					
					//update the pledge table
					if($db->scount($pdet) > 0) {
						$db->update("update adjmeth_finance_pledge
						set overdraft='$overdraft',balance='$nbalance'
						where trancid='$evt_type_sub' and mem_uid='$mem_uid'");
					}
					//update the event where the pledge was made
					if($db->update("update adjmeth_finance
						set amount='$new_amount',pledges='$pledges',
						balance='$new_balance',overdraft='$new_overdraft',
						modified_by='$admin_id',modified_date=now()
					where trancid='$evt_type_sub'")) {
						?>
						<script>window.location.href="<?php print SITE_URL; ?>/redeem_pledge?success";</script>
						<?php
					}
					
				} else {
					//fetch the right name
					$sql2 = $db->select("SELECT * FROM `adjmeth_finance_type` WHERE `id`='$evt_type'");
					//using the while loop to fetch the information
					if($db->scount($sql2) == 1) {
						//using fetch_assoc to get information
						$result=$sql2->fetch_assoc();
						//assign variable
						$res_name=$result["name"];
						$res_id=$result["id"];
						//record the information
						//insert the new record
						/*$db->insert("insert into adjmeth_finance
						(trancid,name_of,typename,typeid,
						membername,memberid,day,month,year,fulldate,
						amount,balance,overdraft,recorded_by,recorded_date)
						values
						('$pid','$res_name','redeem-pledge','$res_id',
						'$name','$mem_uid','$day','$mon','$year',
						now(),'$pamount','0.00','0.00','$admin_id',now())");*/
					}
				}
			} else {
				print "<font color=red> Sorry! Please amount must be numerics.</font>";
			}
		} else {
			print "<font color=red> Sorry! Please select the Event Type.</font>";
		}
		
	}
	
	
	//RECORD NEW PLEDGE
	if(isset($_POST["recordHarvestPledge"])) {
		//fetch the details
		if(isset($_POST["mem_uid"]))
			$mem_uid=$db->cleanData($_POST["mem_uid"]);
		if(isset($_POST["name"]))
			$name=$db->cleanData($_POST["name"]);
		if(isset($_POST["evt_type"]) and is_numeric($_POST["evt_type"])) {
			//continue
			$pamount=$db->cleanData($_POST["amount"]);
			$redeem_date=$db->cleanData($_POST["redeem_date"]);
			//check if the amount is numeric
			if(is_numeric($pamount)) {
				
				//event date
				if(isset($_POST["evt_type_sub"])) {
					$trancid=$db->cleanData($_POST["evt_type_sub"]);
					//fetch the main entry in the database
					$ffsql = $db->select("SELECT * FROM `adjmeth_finance` 
					WHERE `trancid`='$trancid'");
					//assign variable
					$plf_res=$ffsql->fetch_assoc();
					$name_of=''.ucwords($plf_res["name_of"]).' ('.date("F",strtotime($plf_res["fulldate"])).' '.date("Y",strtotime($plf_res["fulldate"])).')';
					//update the transaction details
					$new_pledge=$plf_res["pledges"]+$pamount;
					$new_balance=$plf_res["balance"]+$pamount;
					//update
					$db->update("update adjmeth_finance
					set pledges='$new_pledge', balance='$new_balance'
					where trancid='$trancid'");
					
				} else {
					$ffsql = $db->select("SELECT * FROM 
					`adjmeth_finance_type` 
					WHERE `id`='{$_POST["evt_type"]}'");
					//assign variable
					$plf_res=$ffsql->fetch_assoc();
					$name_of=$plf_res["name"];
					$trancid=$plf_res["tid"].$models->generateRandomNumber(8);
				}
				
				//check if the user has already pledged for this event
				$check_plg=$db->select("select * from adjmeth_finance_pledge
				where trancid='$trancid' and mem_uid='$mem_uid'");
				if($db->scount($check_plg)==1) {
					//fetch details
					$check_plg_res=$check_plg->fetch_assoc();
					//assign variables
					$ch_balance=$check_plg_res["balance"]+$pamount;
					$ch_amount=$check_plg_res["amount"]+$pamount;
					//update the records 
					$db->update("update adjmeth_finance_pledge
					set amount='$ch_amount',balance='$ch_amount'
					where trancid='$trancid' and mem_uid='$mem_uid'");
				} else {
					//insert the pledge into the pledge table
					if($db->insert("insert into adjmeth_finance_pledge
						(trancid,mem_name,mem_uid,event_name,
							redeem_date,amount,balance,admin_id,date
						)values(
							'$trancid','$name','$mem_uid','$name_of',
							'$redeem_date','$pamount','$pamount',
							'$admin_id','".time()."'
						)
					")) {
						?>
						<script>window.location.href="<?php print SITE_URL; ?>/add_pledge?success";</script>
						<?php
					}
				
				}
				
			}
		}
	}
}
?>
