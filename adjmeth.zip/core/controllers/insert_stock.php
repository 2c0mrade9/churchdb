<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$sup = new SupplierModel;
$cat = new CategoryModel;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['stockid'])) {
	//clean the data sent by the administrator
	$name=ucwords($db->cleanData($_POST['name']));
	$stockid=$db->cleanData($_POST['stockid']);
	
	$sell=0;
	$stock_avail = $db->cleanData($_POST['stock_avail']);
	$cost=$db->cleanData($_POST['cost']);
	$supplier=$db->cleanData($_POST['supplier']);
	$category=$db->cleanData($_POST['parent_category']);
	
	if(isset($_POST['subcat'])) {
		$scategory=$db->cleanData($_POST['subcat']);
		$subcat= $scategory;
	} else
		$subcat = 0;

	if(isset($_POST['subsubcat'])) {
		$subsubcat=$db->cleanData($_POST['subsubcat']);
		$subcat1= $subsubcat;
	} else
		$subcat1 = 0;


	$time = date("d-m-Y H:i:s");
	$uname =$_SESSION['kwintUsername'];
	
	if($category == 0) {
		print "<font color=red> Sorry! Please select category</font>";
	} else {
	$alias = $models->create_slug($name);

	$newsup = $sup->supplierById($models->create_slug($supplier), "alias","create")->supid;
	
	//make some checks before inserting the stock information
	$insert = $db->insert("insert into adjmeth_stock(stock_id, stock_name,palias, stock_quantity, supplier_id, 
				company_price, selling_price, category, category_sub, category_subsub, entry_by, date,status) 
			values('$stockid','$name', '$alias','$stock_avail', '$newsup','$cost', '$sell', '$category', '$subcat', '$subcat1',
			'$uname',now(),'1')");
	
	if($insert) {
		$check = $db->select("SELECT * FROM adjmeth_stock WHERE `palias`='$stockid'");
		if($db->scount($check) < 1 ) {
			$db->insert("insert into adjmeth_stock_avail(name,palias,quantity) values('$name','$stockid','$stock_avail')");
		}
		$msg=" $name Stock Details Added" ;
		?>
		<script>window.location.href="<?php print SITE_URL; ?>/add_stock?success";</script>
<?php 	
	}
	}

} else {
	$name 		= "";
	$stockid 	= "";
	$stock_avail = "";
	$sell           = "";
	$cost    	= "";
	$supplier 	= "";
	$category 	= "";
}			

?>
