<?php
/********************************************************************************
* This script is written by Emmaneul Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//create new database object
include_once 'core/utils/GenerateRandom.php';
$db = new Database();
//the error log file
$processing_log =  array();

if(isset($_POST['uname'])) {
	//check if the page is a valid one
	$fname = trim($_POST['fname']);
	$lname = trim($_POST['lname']);
	$uname = trim($_POST['uname']);
	$uid = trim($_POST['uid']);
	$email = trim($_POST['email']);
	
	if(is_numeric($uid)) {
		//update the page information
		$update = $db->update("
			UPDATE 
				`".TABLE_PREFIX."admin`
			SET 
				`FirstName`='$fname',
				`LastName`='$lname',
				`FullName`='$fname $lname',
				`Username`='$uname',
				`Email`='$email'
			WHERE
				`id`='$uid'
		");
		
		if($update)
			$processing_log[] = '<div class="alert alert-success">User Information was sucessfully updated</div>';
		else
			$processing_log[] = '<div class="alert alert-danger">Sorry! User Information update was unsuccessful</div>';
	} else if(isset($_POST['adduser']) and $_POST['adduser'] == "adduser") {
		
		//make some data checks
		if(strlen($fname) < 3) {
			$processing_log[] = '<div class="alert alert-danger">Sorry! FirstName should be at least 3 characters</div>';
		} elseif(strlen($lname) < 3) {
			$processing_log[] = '<div class="alert alert-danger">Sorry! LastName should be at least 3 characters.</div>';
		} elseif(strlen($uname) < 5) {
			$processing_log[] = '<div class="alert alert-danger">Sorry! Username should be at least 5 characters.</div>';
		}  else {
			//make some checks
			$check_uname = $db->select("SELECT * FROM `napetb_admin` WHERE `Username`='$uname'"); 
			$ucount = $db->scount($check_uname);
			if($ucount > 0) {
				$processing_log[] = '<div class="alert alert-danger">Sorry! Username already exists in the database.</div>';
			} else {
				$check_email = $db->select("SELECT * FROM `napetb_admin` WHERE `Email`='$email'"); 
				$ecount = $db->scount($check_email);
				
				if($ecount > 0) {
					$processing_log[] = '<div class="alert alert-danger">Sorry! Email Address already exists in the database.</div>';
				} else {
					//get the password
					$password = generateRandomPassword();
					$password_enc = md5(sha1($password));
					
					
					$insert = $db->insert("
							INSERT INTO
								`".TABLE_PREFIX."admin`
									(`FirstName`, `LastName`, `FullName`, `Username`, `Password`, `Email`, `LastAccess`, `Activated`)
							VALUES
								('$fname','$lname','$fname $lname', '$uname', '$password_enc', '$email', now, 1);
						");
					
					if($insert)
						$processing_log[] = '<div class="alert alert-success">User Information was sucessfully inserted. Please Check Email Address Provided to Get Your Password</div>';
					else
						$processing_log[] = '<div class="alert alert-danger">Sorry! There was an error while inserting admin details</div>';
						
					$msg = '<h2>Admin Registration Details</h2>';
					$msg .= 'You have been registered as an administrator at '.$site->getSiteName(). '<br>';
					$msg .= 'Details of Registration are as follows<br>';
					$msg .= '<strong>Username</strong>: '.$uname.'<br>';
					$msg .= '<strong>Password</strong>: '.$password.'<br><br>';
					$msg .= 'Please <a href="'.$site->getSiteUrl().'/palmcms"> click here to login</a>'; 
					
					$header = "From:mlawer@theokanteygroup.com";
					$header .= "MIME-Version: 1.0";
					$header .= "Content-type: text/html";
						
					mail($email, 'Admin Details at '.$site->getSiteName(), $msg, $header);
				}
			}
		}
	} else {
		$processing_log[] = '<div class="alert alert-danger">Sorry! User Information insertion was unsuccessful</div>';
	}
}  else {
	$fname = '';
	$lname = '';
	$uname = '';
	$email = '';
	//$processing_log[] = '<div class="alert alert-danger">Please all fields are Required</div>';
}

foreach($processing_log as $processing_log) {
	print $processing_log;
}