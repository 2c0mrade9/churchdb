<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$sup = new SupplierModel;
$cat = new CategoryModel;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['stockid'])) {
	//clean the data sent by the administrator
	$name=ucwords($db->cleanData($_POST['name']));
	$stockid=$db->cleanData($_POST['stockid']);
	
	$sell=0;
	$stock_avail = $db->cleanData($_POST['stock_avail']);
	$cost=$db->cleanData($_POST['cost']);
	$supplier=$db->cleanData($_POST['supplier']);
	$category=$db->cleanData($_POST['category']);

	$time = date("d-m-Y H:i:s");
	$uname =$_SESSION['kwintUsername'];

	$alias = $models->create_slug($name);

	//fetch the category name
	$newcat = $cat->categoryById($models->create_slug($category), "alias","create")->catid;
	$newsup = $sup->supplierById($models->create_slug($supplier), "alias","create")->supid;
	
	
	//make some checks before inserting the stock information
	$update = $db->update("update adjmeth_stock set 
				stock_name='$name', palias='$alias', stock_quantity='$stock_avail', 
				supplier_id='$newsup', company_price='$cost', selling_price='$sell', 
				category='$newcat', modified_by='$uname', modified_date=now() where 
				stock_id='$stockid' limit 1");
	
	if($update) { 
		$db->update("update adjmeth_stock_avail set name='$name',palias='$stockid',quantity='$stock_avail' where palias='$stockid' limit 1");
		?>
		<script>window.location.href="<?php print SITE_URL; ?>/update_stock/<?php print $stockid; ?>/view_product?success";</script>
<?php 	
	}

} else {
	$name 		= "";
	$stockid 	= "";
	$stock_avail 	= "";
	$sell           = "";
	$cost    	= "";
	$supplier 	= "";
	$category 	= "";
}			

?>
