<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;
$min = new MinistryModel;
$cat = new OrganizationModel;

if(isset($_POST['Submit']) and isset($_POST['name'])) {
	$abbrev=$db->cleanData($_POST['abbrev']);
	$name=ucwords($db->cleanData($_POST['name']));
	$ministry=$db->cleanData($_POST['ministry']);
	$description=$db->cleanData($_POST['description']);
	
	$alias = $models->create_slug($name);
	$newmini = $min->MinistryById($models->create_slug($ministry),"alias","create")->mid;

	//check if the category already exists
	$check = $db->select("SELECT * FROM adjmeth_groups WHERE `slug`='$alias'");
	if($db->scount($check) > 0) {
		print "<font color=red> Dublicate Entry. Please Verify</font>";
	} else {
		$ins = $db->insert("INSERT INTO adjmeth_groups 
		(name,slug, abbrev, ministry,description,status) 
		values ('$name', '$alias', '$abbrev', '$newmini','$description','1')");
?>
	<script>window.location.href="<?php print SITE_URL; ?>/add_organization?success";</script>
<?php
	}	

} else {
	$abbrev = "";
	$description = "";
	$name 	= "";
	$ministry = "";
}			

?>
