<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['name'])) {
	$address=$db->cleanData($_POST['address']);
	$name=$db->cleanData($_POST['name']);
	$catid=$db->cleanData($_POST['catid']);
	$parent=$db->cleanData($_POST['parent_category']);
	if(isset($_POST['subcat']))
		$subcat=$db->cleanData($_POST['subcat']);
	else
		$subcat = 0;

	$alias = $models->create_slug($name);

	//check if the category already exists
	$ins = $db->insert("UPDATE adjmeth_stock_category SET
		category_name='$name', category_parent='$parent', category_sparent='$subcat', category_alias='$alias', 
		category_description='$address' WHERE id='$catid'");
?>
	<script>window.location.href="<?php print SITE_URL; ?>/update_category/<?php print $alias; ?>?success";</script>
<?php	

} else {
	$address = "";
	$name 	= "";
}			

?>
