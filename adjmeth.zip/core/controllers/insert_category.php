<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;
$cat = new CategoryModel;

if(isset($_POST['Submit']) and isset($_POST['name'])) {
	$address=$db->cleanData($_POST['address']);
	$name=$db->cleanData($_POST['name']);
	$parent=$db->cleanData($_POST['parent_category']);
	if(isset($_POST['subcat']))
		$subcat=$db->cleanData($_POST['subcat']);
	else
		$subcat = 0;

	$newcat = $cat->categoryById($models->create_slug($parent), "id",false)->catname;
	$cparent = "<option value='$parent' selected='selected'>$newcat</option>";

	$alias = $models->create_slug($name)."-".$parent;

	//check if the category already exists
	$check = $db->select("SELECT * FROM adjmeth_stock_category WHERE `category_alias`='$alias' AND category_parent='$parent'");
	if($db->scount($check) > 0) {
		print "<font color=red> Dublicate Entry. Please Verify</font>";
	} else {
		$ins = $db->insert("INSERT INTO adjmeth_stock_category 
		(category_name,category_parent, category_sparent, category_alias,category_description,status) 
		values ('$name', '$parent', '$subcat', '$alias','$address','1')");
?>
	<script>window.location.href="<?php print SITE_URL; ?>/add_category?success";</script>
<?php
	}	

} else {
	$address = "";
	$name 	= "";
	$cparent = "";
}			

?>
