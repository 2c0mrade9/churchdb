<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$org = new OrganizationModel;
$occup = new OccupationModel;
$res = new ResidenceModel;
$cla = new ClassModel;
$member = new MemberModel;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['memberid'])) {
	//clean the data sent by the administrator
	$memberid=$db->cleanData($_POST['memberid']);
	
	$fname=ucwords($db->cleanData($_POST['fname']));
	$datejoin=ucwords($db->cleanData($_POST['datejoin']));
	$lname=ucwords($db->cleanData($_POST['lname']));
	$occupation=ucwords($db->cleanData($_POST['occupation']));
	$phone1=$db->cleanData($_POST['phone1']);
	$residence=ucwords($db->cleanData($_POST['residence']));
	$email=$db->filter_sanitize_email($_POST['email']);
	$phone2=$db->cleanData($_POST['phone2']);
	$dob=$db->cleanData($_POST['dob']);
	$gender=$db->cleanData($_POST['gender']);
	$mdob=date("m", strtotime($dob));
	$ddob=date("l", strtotime($dob));
	$ydob=date("Y", strtotime($dob));
	$mjoin=date("m", strtotime($datejoin));
	$djoin=date("l", strtotime($datejoin));
	$yjoin=date("Y", strtotime($datejoin));
	$title=ucwords($db->cleanData($_POST['title']));
	$class=$db->cleanData($_POST['class']);
	$noofchild=$db->cleanData($_POST['noofchild']);
	$marstat=$db->cleanData($_POST['marstat']);
	$address=$db->cleanData($_POST['address']);
	$organization=ucwords($db->cleanData($_POST['organization']));
	$organization2=ucwords($db->cleanData($_POST['organization2']));
	$nameslug = $models->create_slug($lname." ".$fname);
	
	$time = date("d-m-Y H:i:s");
	$uname =$_SESSION['AdjMethUsername'];
	
	$mdob = $member->MonthById($mdob,"mid")->m_name;
	$mjoin = $member->MonthById($mjoin,"mid")->m_name;
	
	$neworg = $org->OrganizationById($models->create_slug($organization),"alias","create")->gid;
	$neworg2 = $org->OrganizationById($models->create_slug($organization2),"alias","create")->gid;
	$newres = $res->ResidenceById($models->create_slug($residence),"alias","create")->rname;
	$newclass = $cla->ClassById($models->create_slug($class),"alias","create")->cid;
	$newoccup = $occup->OccupationById($models->create_slug($occupation),"alias","create")->oname;
	
	//check if member already exists in the database
	//make some checks before inserting the stock information
	$update = $db->update("update adjmeth_members set title='$title',fname='$fname',lname='$lname',
					fullname='$lname $fname',dob='$dob',day_born='$ddob',month_born='$mdob',year_born='$ydob',
					gender='$gender',marital_status='$marstat',no_of_children='$noofchild',
					slug='$nameslug',phone='$phone1',phone1='$phone2',address='$address', residence='$newres',
					occupation='$newoccup',email='$email',m_class='$newclass',date_join='$datejoin',day_join='$djoin',month_join='$mjoin',
					year_join='$yjoin',organization='$neworg',suborganization='$neworg2', orgname='$organization',
					orgsub='$organization2' where uniqueid='$memberid'
					");
	if(isset($update)) {
		
		if(isset($_FILES['userimage']['tmp_name']) and !empty($_FILES['userimage']['tmp_name'])):
			
			$date = date("Y")."".date("m").date("d");
			//insert data into the database
			$filename = $models->create_slug($lname."-".$fname).'-'.$date.'-'.rand(0, 9999).'.jpg';
			move_uploaded_file($_FILES["userimage"]["tmp_name"], "assets/images/members/".$filename);
					
			$db->update("
				UPDATE `adjmeth_members`
				SET `image`='$filename'
				WHERE `uniqueid`='$memberid'
			");
		endif;
		?>
		<script>window.location.href="<?php print SITE_URL; ?>/update_member/<?php print $memberid; ?>/update_members?success";</script>
<?php 	
		}
} else {
	$name 		= "";
	$dob 		= "";
	$memberid 	= "";
	$gender = "";
	$organization2 	= "";
	$fname 		= "";
	$occupation="";
	$lname           = "";
	$phone1    	= "";
	$phone2 	= "";
	$email = "";
	$class 	= "";
	$address = "";
	$residence = "";
	$title = "";
	$organization 	= "";
	$datejoin = "";
}			

?>
