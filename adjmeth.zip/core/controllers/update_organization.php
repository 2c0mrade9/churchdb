<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;
$min = new MinistryModel;

if(isset($_POST['Submit']) and isset($_POST['name'])) {
	$abbrev=$db->cleanData($_POST['abbrev']);
	$name=ucwords($db->cleanData($_POST['name']));
	$ministry=$db->cleanData($_POST['ministry']);
	$description=$db->cleanData($_POST['description']);
	$orgid=$db->cleanData($_POST['orgid']);
	
	$alias = $models->create_slug($name);
	$newmini = $min->MinistryById($models->create_slug($ministry),"alias","create")->mid;

	//update category information
	$update = $db->update("UPDATE adjmeth_groups 
		set name='$name',slug='$alias', abbrev='$abbrev', ministry='$newmini',description='$description'
		where id='$orgid'");
?>
	<script>window.location.href="<?php print SITE_URL; ?>/update_organization/<?php print $alias; ?>?success";</script>
<?php	

} else {
	$address = "";
	$name 	= "";
}			

?>
