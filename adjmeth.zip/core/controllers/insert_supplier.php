<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$sup = new SupplierModel;
$cat = new CategoryModel;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['name'])) {
	//clean the user input submitted
	$name = $db->cleanData($_POST['name']);
	$address = $db->cleanData($_POST['address']);
	$contact2 = $db->cleanData($_POST['contact2']);
	$contact1 = $db->cleanData($_POST['contact1']);
	
	if(strlen($name) < 3) {
		print "<font color=red> PLEASE ENTER SUPPLIER NAME</font>";
	} else {
	$uname =$_SESSION['kwintUsername'];

	$alias = $models->create_slug($name);
	
	$check = $db->select("SELECT * FROM supplier_details WHERE `alias`='$alias'");
	if($db->scount($check) > 0) {
		print "<font color=red> Dublicate Entry. Please Verify</font>";
	} else {
		$insert = $db->insert("insert into supplier_details 
			values(NULL,'$name','$alias','$address','$contact1','$contact2',0,'1','','$uname',now(),now())") or trigger_error($db->db_error());
		$name 		= "";
		$address 	= "";
		$contact1	= "";
		$contact2 	= "";
?>
	<script>//window.location.href="<?php print SITE_URL; ?>/add_supplier?success";</script>
<?php
			
	}
	}
} else {
	$name 		= "";
	$address 	= "";
	$contact1	= "";
	$contact2 	= "";
}			

?>
