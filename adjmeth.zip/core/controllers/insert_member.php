<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$org = new OrganizationModel;
$res = new ResidenceModel;
$member = new MemberModel;
$occup = new OccupationModel;
//$count = new CountryModel;
$cla = new ClassModel;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['memberid'])) {
	//clean the data sent by the administrator
	$memberid=$db->cleanData($_POST['memberid']);
	
	if(isset($_POST["fname"]) and !empty($_POST["fname"])) {
	$fname=ucwords($db->cleanData($_POST['fname']));
	$datejoin=ucwords($db->cleanData($_POST['datejoin']));
	$occupation=ucwords($db->cleanData($_POST['occupation']));
	$lname=ucwords($db->cleanData($_POST['lname']));
	$phone1=$db->cleanData($_POST['phone1']);
	$email=$db->filter_sanitize_email($_POST['email']);
	$residence=$db->cleanData($_POST['residence']);
	$phone2=$db->cleanData($_POST['phone2']);
	$dob=$db->cleanData($_POST['dob']);
	$gender=$db->cleanData($_POST['gender']);
	$mdob=date("m", strtotime($dob));
	$ddob=date("l", strtotime($dob));
	$ydob=date("Y", strtotime($dob));
	$mjoin=date("m", strtotime($datejoin));
	$djoin=date("l", strtotime($datejoin));
	$yjoin=date("Y", strtotime($datejoin));
	$noofchild=$db->cleanData($_POST['noofchild']);
	$marstat=$db->cleanData($_POST['marstat']);
	$title=ucwords($db->cleanData($_POST['title']));
	$class=$db->cleanData($_POST['class']);
	$address=$db->cleanData($_POST['address']);
	$hometown=$db->cleanData($_POST['hometown']);
	$country=$db->cleanData($_POST['country']);
	$organization=ucwords($db->cleanData($_POST['organization']));
	$organization2=ucwords($db->cleanData($_POST['organization2']));
	$nameslug = $models->create_slug($lname." ".$fname);
	
	$time = date("d-m-Y H:i:s");
	$uname =$_SESSION['AdjMethUsername'];
	
	$neworg = $org->OrganizationById($models->create_slug($organization),"alias","create")->gid;
	$neworg2 = $org->OrganizationById($models->create_slug($organization2),"alias","create")->gid;
	$newres = $res->ResidenceById($models->create_slug($residence),"alias","create")->rname;
	$newclass = $cla->ClassById($models->create_slug($class),"alias","create")->cid;
	$newoccup = $occup->OccupationById($models->create_slug($occupation),"alias","create")->oname;
	$mdob = $member->MonthById($mdob,"mid")->m_name;
	$mjoin = $member->MonthById($mjoin,"mid")->m_name;
	
	//check if member already exists in the database
	$sql = $db->select("select * from adjmeth_members where (slug='$nameslug' and phone='$phone1') 
					or (slug='$nameslug' and phone1='$phone2')
			") or trigger_error($db->db_error());
	if($db->scount($sql) > 0 ) {
			print "<font color=red> Sorry! Please Member already added into the database.</font>";			
	} else {
	
		//make some checks before inserting the stock information
		$insert = $db->insert("insert into adjmeth_members(uniqueid,title,fname,lname,fullname,dob,day_born,
				month_born,year_born,gender,marital_status,no_of_children,slug,phone, phone1, address, residence,
				country,hometown,occupation,email,m_class,date_join,
				day_join,month_join,year_join,organization,suborganization,orgname,orgsub,created_by, created_date) 
			values('$memberid','$title', '$fname','$lname', '$lname $fname','$dob','$ddob','$mdob','$ydob','$gender',
					'$marstat','$noofchild','$nameslug',
					'$phone1', '$phone2','$address', '$newres','$country','$hometown','$newoccup','$email','$newclass','$datejoin','$djoin','$mjoin',
					'$yjoin','$neworg','$neworg2','$organization','$organization2','$uname',now())");
			
		if($insert) {
			if(isset($_FILES['userimage']['tmp_name']) and !empty($_FILES['userimage']['tmp_name'])):
			
				$date = date("Y")."".date("m").date("d");
				//insert data into the database
				$filename = $models->create_slug($lname."-".$fname).'-'.$date.'-'.rand(0, 9999).'.jpg';
				move_uploaded_file($_FILES["userimage"]["tmp_name"], "assets/images/members/".$filename);
						
				$db->update("
					UPDATE `adjmeth_members`
					SET `image`='$filename'
					WHERE `uniqueid`='$memberid'
				");
			endif;
			?>
			<script>window.location.href="<?php print SITE_URL; ?>/add_member?success";</script>
<?php 	
			}
		}
	}
} else {
	$name 		= "";
	$dob 		= "";
	$memberid 	= "";
	$organization2 	= "";
	$occupation	= "";
	$fname 		= "";
	$lname           = "";
	$phone1    	= "";
	$phone2 	= "";
	$datejoin = "";
	$email = "";
	$class 	= "";
	$gender = "";
	$address = "";
	$residence = "";
	$hometown = "";
	$country = "";
	$noofchild="";
	$title = "";
	$organization 	= "";
}			

?>
