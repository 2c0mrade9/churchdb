<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$member = new MemberModel;
$home = new HometownModel;
$sch = new SundaySchoolModel;
$res = new ResidenceModel;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['memberid'])) {
	//clean the data sent by the administrator
	$memberid=$db->cleanData($_POST['memberid']);
	
	$fname=ucwords($db->cleanData($_POST['fname']));
	$datejoin=ucwords($db->cleanData($_POST['datejoin']));
	$parent=ucwords($db->cleanData($_POST['parent']));
	$lname=ucwords($db->cleanData($_POST['lname']));
	$phone1=$db->cleanData($_POST['phone1']);
	$residence=$db->cleanData($_POST['residence']);
	$school=$db->cleanData($_POST['school']);
	$dob=$db->cleanData($_POST['dob']);
	$gender=$db->cleanData($_POST['gender']);
	$address=ucwords($db->cleanData($_POST['address']));
	$schloc=$db->cleanData($_POST['schoollocation']);
	$region=$db->cleanData($_POST['region']);
	$edulevel=$db->cleanData($_POST['edulevel']);
	$schclass=$db->cleanData($_POST['schclass']);
	$hometown=$db->cleanData($_POST['hometown']);
	$remarks=$db->cleanData($_POST['remarks']);
	$pcontact=$db->cleanData($_POST['pcontact']);
	$presidence=$db->cleanData($_POST['presidence']);
	$paddress=ucwords($db->cleanData($_POST['paddress']));
	$mdob=date("m", strtotime($dob));
	$ddob=date("l", strtotime($dob));
	$ydob=date("Y", strtotime($dob));
	$mjoin=date("m", strtotime($datejoin));
	$djoin=date("l", strtotime($datejoin));
	$yjoin=date("Y", strtotime($datejoin));
	$stuclass=$db->cleanData($_POST['stuclass']);
	$nameslug = $models->create_slug($lname." ".$fname);
	
	$time = date("d-m-Y H:i:s");
	$uname =$_SESSION['AdjMethUsername'];
	
	$newschool = $sch->SchoolById($models->create_slug($school),"alias","create")->sname;
	$newres = $res->ResidenceById($models->create_slug($residence),"alias","create")->rname;
	$mdob = $member->MonthById($mdob,"mid")->m_name;
	$mjoin = $member->MonthById($mjoin,"mid")->m_name;
	$hometown = $home->HometownById($models->create_slug($hometown),"alias","create")->rname;
	
	//check if member already exists in the database
	if($gender=="0") {
		print "<font color=red> Sorry! Please Select the Sex of the Member.</font>";
	} else {
		//make some checks before inserting the stock information
			$update = $db->update("update adjmeth_sunday_school_members set
			surname='$lname',firstname='$fname',fullname='$lname $fname',dob='$dob',
			day_born='$ddob',month_born='$mdob',year_born='$ydob',gender='$gender',
			slug='$nameslug',phone='$phone1',address='$address',m_class='$stuclass',
			date_join='$datejoin',day_join='$djoin',month_join='$mjoin',year_join='$yjoin',
			parent='$parent',pcontact='$pcontact',presidence='$presidence',
			paddress='$paddress',school='$newschool',schoollocation='$schloc',
			schclass='$schclass',edulevel='$edulevel',residence='$newres',
			hometown='$hometown',region='$region',remarks='$remarks'
			where studentid='$memberid'");
				
		if($update) {
			?>
			<script>window.location.href="<?php print SITE_URL; ?>/update_sunday_school_member/<?php print $memberid; ?>/update_members?success";</script>
<?php 	
		}
	}
} else {
	$name 		= "";
	$dob 		= "";
	$memberid 	= "";
	$organization2 	= "";
	$occupation	= "";
	$fname 		= "";
	$lname           = "";
	$phone1    	= "";
	$phone2 	= "";
	$datejoin = "";
	$parent = "";
	$stuclass 	= "";
	$gender = "";
	$address = "";
	$remarks="";
	$residence = "";
	$title = "";
	$school 	= "";
}			

?>
