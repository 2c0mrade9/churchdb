<?php
/********************************************************************************
* Paddies Group of Companies Limited
* Written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Website: youthofxcellence.webs.com
*
*********************************Copyright Info***********************************
* This script must not be sold or 
* use for commercial purpose without the consent of Royal Bloggers 
* Please do not remove this copyright information from the top of this page
* All Copy Rights Reserved by Royal Bloggers
***********************************************************************************/
$db = new Database();

$updateResult = '';

//the error log file
$processing_log =  array();

//process request form
if(isset($_POST['SiteName'])) {
			
	//strip all tags
	$SiteName = $db->cleanData($_POST['SiteName']);
	$SiteSlogan  = $db->cleanData($_POST['SiteSlogan']);
	$SiteEmail = $db->filter_sanitize_email($_POST['SiteEmail']);
	$SiteAddress = $db->cleanData($_POST['SiteAddress']);
	$SitePhone  = $db->cleanOthers($_POST['SitePhone']);
	$SiteDescription = $db->cleanData($_POST['SiteDescription']);
	$SiteKeywords = $db->cleanOthers($_POST['SiteKeywords']);
	$seo = $db->cleanData($_POST['seo']);
			
	//insert into the database
	$update = $db->update("
				UPDATE `adjmeth_options`
					SET
				SiteName = '$SiteName',
				SiteSlogan = '$SiteSlogan',
				SiteDescription = '$SiteDescription',
				SiteEmail = '$SiteEmail',
				SitePhone = '$SitePhone',
				SiteAddress = '$SiteAddress',
				SiteKeywords = '$SiteKeywords',
				SiteSEO = '$seo'
					WHERE
				id = '1'
					LIMIT 1						
		") or trigger_error($db->db_error());
		//redirect to the main page again
		if( $update ) {
			//redirect user
			$processing_log[] = '<div class="alert alert-success">Site Settings was sucessfully updated</div>';
		} else {
			$processing_log[] = '<div class="alert alert-danger">Sorry! Site Settings update was unsuccessful</div>';
		}
}

foreach($processing_log as $processing_log) {
	print $processing_log;
}
?>
