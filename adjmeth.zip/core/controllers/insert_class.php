<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$models = new Models;
$members = new MemberModel;
$cat = new OrganizationModel;

if(isset($_POST['Submit']) and isset($_POST['cname'])) {
	$cleader=$db->cleanData($_POST['cleader']);
	$acleader=$db->cleanData($_POST['acleader']);
	$cname=ucwords($db->cleanData($_POST['cname']));
	$csecretary=$db->cleanData($_POST['csecretary']);
	$alias = $models->create_slug($cname);
	
	//check if the category already exists
	$check = $db->select("SELECT * FROM adjmeth_class WHERE `slug`='$alias'");
	if($db->scount($check) > 0) {
		print "<font color=red> Dublicate Entry. Please Verify</font>";
	} else {

		$ncl = $members->MemberById($models->create_slug($cleader),null,"create","slug")->mem_id;
		$nacl = $members->MemberById($models->create_slug($acleader),null,"create","slug")->mem_id;
		$ncs = $members->MemberById($models->create_slug($csecretary),null,"create","slug")->mem_id;

	
		$ins = $db->insert("INSERT INTO adjmeth_class 
		(name,slug,class_leader,class_leader_assist,class_secretary,status) 
		values ('$cname','$alias','$ncl','$nacl','$ncs','1')");
?>
	<script>window.location.href="<?php print SITE_URL; ?>/add_class?success";</script>
<?php
	}	

} else {
	$cleader = "";
	$acleader = "";
	$cname 	= "";
	$csecretary = "";
}			

?>
