<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$member = new MemberModel;
$sch = new SundaySchoolModel;
$res = new ResidenceModel;
$home = new HometownModel;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['memberid'])) {
	//clean the data sent by the administrator
	$memberid=$db->cleanData($_POST['memberid']);
	
	$fname=ucwords($db->cleanData($_POST['fname']));
	$datejoin=ucwords($db->cleanData($_POST['datejoin']));
	$parent=ucwords($db->cleanData($_POST['parent']));
	$lname=ucwords($db->cleanData($_POST['lname']));
	$phone1=$db->cleanData($_POST['phone1']);
	$pcontact=$db->cleanData($_POST['pcontact']);
	$residence=$db->cleanData($_POST['residence']);
	$school=$db->cleanData($_POST['school']);
	$dob=$db->cleanData($_POST['dob']);
	$gender=$db->cleanData($_POST['gender']);
	$address=$db->cleanData($_POST['address']);
	$schloc=$db->cleanData($_POST['schoollocation']);
	$edulevel=$db->cleanData($_POST['edulevel']);
	$region=$db->cleanData($_POST['region']);
	$presidence=$db->cleanData($_POST['presidence']);
	$paddress =$db->cleanData($_POST['paddress']);
	$schclass=$db->cleanData($_POST['schclass']);
	$hometown=$db->cleanData($_POST['hometown']);
	$remarks=$db->cleanData($_POST['remarks']);
	$mdob=date("m", strtotime($dob));
	$ddob=date("l", strtotime($dob));
	$ydob=date("Y", strtotime($dob));
	$mjoin=date("m", strtotime($datejoin));
	$djoin=date("l", strtotime($datejoin));
	$yjoin=date("Y", strtotime($datejoin));
	$stuclass=$db->cleanData($_POST['stuclass']);
	$nameslug = $models->create_slug($lname." ".$fname);
	
	$time = date("d-m-Y H:i:s");
	$uname =$_SESSION['AdjMethUsername'];
	
	$newschool = $sch->SchoolById($models->create_slug($school),"alias","create")->sname;
	$newres = $res->ResidenceById($models->create_slug($residence),"alias","create")->rname;
	$hometown = $home->HometownById($models->create_slug($hometown),"alias","create")->rname;
	$mdob = $member->MonthById($mdob,"mid")->m_name;
	$mjoin = $member->MonthById($mjoin,"mid")->m_name;
	
	//check if member already exists in the database
	$sql = $db->select("select * from adjmeth_sunday_school_members where (slug='$nameslug' and phone='$phone1')");
	
	if($gender=="0") {
		print "<font color=red> Sorry! Please Select the Sex of the Member.</font>";
	} else {
		if($db->scount($sql) > 0 ) {
				print "<font color=red> Sorry! Please Member already added into the database.</font>";			
		} else {
		
			//make some checks before inserting the stock information
			$insert = $db->insert("insert into adjmeth_sunday_school_members(
					studentid,surname,firstname,fullname,dob,day_born,
					month_born,year_born,gender,slug,phone, address,m_class,
					date_join,day_join,month_join,year_join,
					parent,pcontact,presidence,paddress,school,schoollocation,schclass,
					edulevel,
					residence,hometown,region,remarks,created_by,created_date) 
				values('$memberid','$lname','$fname','$lname $fname','$dob','$ddob','$mdob',
						'$ydob','$gender','$nameslug','$phone1','$address', '$stuclass',
						'$datejoin','$djoin','$mjoin','$yjoin','$parent',
						'$pcontact','$presidence','$paddress','$newschool','$schloc',
						'$schclass','$edulevel','$newres','$hometown','$region',
						'$remarks','$uname',now())");
				
			if($insert) {
				?>
				<script>window.location.href="<?php print SITE_URL; ?>/add_sunday_school_member?success";</script>
<?php 	
			}
		}
	}
} else {
	$name 		= "";
	$dob 		= "";
	$memberid 	= "";
	$organization2 	= "";
	$pcontact="";
	$schclass = "";
	$occupation	= "";
	$fname 		= "";
	$lname           = "";
	$phone1    	= "";
	$phone2 	= "";
	$datejoin = "";
	$parent = "";
	$presidence = "";
	$stuclass 	= "";
	$paddress = "";
	$gender = "";
	$address = "";
	$residence = "";
	$schloc="";
	$region="";
	$remarks = "";
	$hometown="";
	$title = "";
	$school 	= "";
}			

?>
