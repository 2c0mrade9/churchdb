<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db = new Database;
$sup = new SupplierModel;
$cat = new CategoryModel;
$models = new Models;

if(isset($_POST['Submit']) and isset($_POST['name']) and isset($_POST['supid']) and is_numeric($_POST['supid'])) {
	//clean the user input submitted
	$name = $db->cleanData($_POST['name']);
	$address = $db->cleanData($_POST['address']);
	$contact2 = $db->cleanData($_POST['contact2']);
	$contact1 = $db->cleanData($_POST['contact1']);
	$alias = $models->create_slug($name);

	$supid = $db->cleanData($_POST['supid']);
	
	if(strlen($name) < 3) {
		print "<font color=red> PLEASE ENTER SUPPLIER NAME</font>";
	} else {
	$uname =$_SESSION['kwintUsername'];

	$alias = $models->create_slug($name);
	
	$update = $db->update("update supplier_details set supplier_name='$name', alias='$alias',supplier_address='$address', supplier_contact1='$contact1', supplier_contact2='$contact2', modified_date=now()");
	$name 		= "";
	$address 	= "";
	$contact1	= "";
	$contact2 	= "";
?>
	<script>window.location.href="<?php print SITE_URL; ?>/update_supplier/<?php print $alias; ?>?success";</script>
<?php
			
	}
} else {
	$name 		= "";
	$address 	= "";
	$contact1	= "";
	$contact2 	= "";
}			

?>
