<?php
/********************************************************************************
* This script is written by Emmaneul Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//create new database object
include_once 'core/utils/GenerateRandom.php';
$db = new Database();
//the error log file
$processing_log =  array();

if(isset($_POST['uname'])) {
	//check if the page is a valid one
	$fname = $db->cleanData($_POST['fname']);
	$lname = $db->cleanData($_POST['lname']);
	$uname = $db->cleanData($_POST['uname']);
	$password = $db->cleanData($_POST['password']);
	$role = $db->cleanData($_POST['role']);
	$uid = $db->cleanData($_POST['uid']);
	$question = $db->cleanData($_POST['question']);
	$answer = $db->cleanData($_POST['answer']);
	$email = stripcslashes($_POST['email']);
	$question = $models->create_slug($question);
	$answer = $models->create_slug($answer);
	
	$question_opt = "<option selected='selected' value='$question'>".ucfirst(str_replace("-"," ", $question))."</option>";
	
	if($question == "0") {
		$processing_log[] = '<div class="alert alert-danger">Sorry! Please select a Secure Question.</div>';
	} else {
		if(is_numeric($uid)) {
			if(isset($ACTION[2]) and $user->UserById($ACTION[2],"alias")->found == true) {
				$level = $db->cleanData($_POST['level']);
				//check the password sent by the user-
				$actPassword = md5(sha1($password));
				//query the database
				if($db->scount($db->select("select id, Password from `".TABLE_PREFIX."admin` where Password='$actPassword' and id='$uid'")) == 1) {
					//query the username that the user has selected to see if there is no user with that username
					$sql = $db->select("select id, Username from `".TABLE_PREFIX."admin` where id='$uid'");
					$sql2 = $db->select("select id, Username from `".TABLE_PREFIX."admin` where Username='$uname' and id!='$uid'"); 
					//use the $db->fetch_assoc() function to get the details
					$result = $sql->fetch_assoc();
					$result2 = $sql2->fetch_assoc();
					//having gotten the information ensure that the username meets the query
					if($uname==$result["Username"] || ($db->scount($sql2) == 0)) {
						//update the page information
						$update = $db->update("
							UPDATE 
								`".TABLE_PREFIX."admin`
							SET 
								`FirstName`='$fname',
								`LastName`='$lname',
								`FullName`='$fname $lname',
								`Username`='$uname',
								`Password`='$actPassword',
								`Email`='$email',
								`Level`='Level',
								`Role`='$role',
								SecureQuestion='$question',
								SecureAnswer='$answer'
							WHERE
								`id`='$uid'
						");
						if($update) {
							$processing_log[] = '<script>alert("User Information was sucessfully updated");</script>';
							$processing_log[] = "<script>window.location.href='".SITE_URL."/update_admins/mem/$uname'</script>";
						} else
							$processing_log[] = '<div class="alert alert-danger">Sorry! User Information update was unsuccessful</div>';
					} else {
						$processing_log[] = '<div class="alert alert-danger">Sorry! There is a user with the same name in the database.</div>';
					}
					
				} else {
					$processing_log[] = '<div class="alert alert-danger">Sorry! You supplied a wrong Password. Please enter your current Password.</div>';
				}
			} else {
				$processing_log[] = '<div class="alert alert-danger">Sorry! User Information update was unsuccessful</div>';
			}
		} else if(isset($_POST['adduser']) and $_POST['adduser'] == "adduser") {
			
			//make some data checks
			if(strlen($fname) < 3) {
				$processing_log[] = '<div class="alert alert-danger">Sorry! FirstName should be at least 3 characters</div>';
			} elseif(strlen($lname) < 3) {
				$processing_log[] = '<div class="alert alert-danger">Sorry! LastName should be at least 3 characters.</div>';
			} elseif(strlen($uname) < 5) {
				$processing_log[] = '<div class="alert alert-danger">Sorry! Username should be at least 5 characters.</div>';
			}  else {
				//make some checks
				$check_uname = $db->select("SELECT * FROM `adjmeth_admin` WHERE `Username`='$uname'"); 
				$ucount = $db->scount($check_uname);
				if($ucount > 0) {
					$processing_log[] = '<div class="alert alert-danger">Sorry! Username already exists in the database.</div>';
				} else {
					$check_email = $db->select("SELECT * FROM `adjmeth_admin` WHERE `Email`='$email'"); 
					$ecount = $db->scount($check_email);
					
					if($ecount > 0) {
						$processing_log[] = '<div class="alert alert-danger">Sorry! Email Address already exists in the database.</div>';
					} else {
						//get the password
						$password_enc = md5(sha1($password));
						
						$insert = $db->insert("
								INSERT INTO
									`".TABLE_PREFIX."admin`
										(`FirstName`, `LastName`, `FullName`, `Username`, `Password`, `Email`, `Role`, `SecureQuestion`, 
											`SecureAnswer`,`LastAccess`, `Activated`)
								VALUES
									('$fname','$lname','$fname $lname', '$uname', '$password_enc', '$email', '$role', '$question','$answer',now(), 1);
							");
						
						if($insert)
							$processing_log[] = '<div class="alert alert-success">User Information was sucessfully inserted.</div>';
						else
							$processing_log[] = '<div class="alert alert-danger">Sorry! There was an error while inserting admin details</div>';
							
						$msg = '<h2>Admin Registration Details</h2>';
						$msg .= 'You have been registered as an administrator at '.$site->getSiteName(). '<br>';
						$msg .= 'Details of Registration are as follows<br>';
						$msg .= '<strong>Username</strong>: '.$uname.'<br>';
						$msg .= '<strong>Password</strong>: '.$password.'<br><br>';
						$msg .= 'Please <a href="'.$site->getSiteUrl().'/login"> click here to login</a>'; 
						
						$header = "From:emmallob14@gmail.com";
						$header .= "MIME-Version: 1.0";
						$header .= "Content-type: text/html";
							
						mail($email, 'Admin Details at '.$site->getSiteName(), $msg, $header);
					}
				}
			}
		} else {
			$processing_log[] = '<div class="alert alert-danger">Sorry! User Information insertion was unsuccessful</div>';
		}
	}
}  else {
	if(isset($ACTION[2]) and $user->UserById($ACTION[2],"alias")->found == true) { 
		$fname = $user->UserById($ACTION[2],"alias")->FIRSTNAME;
		$lname = $user->UserById($ACTION[2],"alias")->LASTNAME;
		$level = $user->UserById($ACTION[2],"alias")->LEVEL_OPT;
		$password = '';
		$answer = $user->UserById($ACTION[2],"alias")->ANSWER;
		$question_opt = $user->UserById($ACTION[2],"alias")->QUESTION_OPT;
		$uname = $user->UserById($ACTION[2],"alias")->USERNAME;
		$email = $user->UserById($ACTION[2],"alias")->EMAIL;
	} else {
		$fname = '';
		$lname = '';
		$question_opt = '';
		$answer = '';
		$level = '';
		$password = '';
		$uname = '';
		$email = '';
	}
	//$processing_log[] = '<div class="alert alert-danger">Please all fields are Required</div>';
}

foreach($processing_log as $processing_log) {
	print $processing_log;
}