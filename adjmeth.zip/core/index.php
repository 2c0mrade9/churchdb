<?php
header('location: ../');
?>