<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class SupplierModel extends Models {
	
	public function supplierById($supname,$field,$optional=null) {

		$db = new Database;
		$models = new Models;
		$this->supname = $db->cleanData($supname);

		if($field == "name") {
			$field = "supplier_name";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "phone") {
			$field = "supplier_contact1";
		} elseif($field == "alias") {
			$field = "alias";
		} else {
			$field = "id";
		}
		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_supplier_details WHERE $field='{$this->supname}' and status='1' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->supname = ucwords($res['supplier_name']);
			$this->supid = $res['id'];
			$this->supadd = $res['supplier_address'];
			$this->supcont1 = $res['supplier_contact1'];
			$this->supcont2 = $res['supplier_contact2'];
		} else {
			if($optional == "create") {
				$nname = ucwords(str_replace('-', ' ', $this->supname));
				$ins = $db->insert("INSERT INTO adjmeth_supplier_details (supplier_name,alias,status) values ('{$nname}', '{$this->supname}','1')") or trigger_error($db->db_error());
				$insertid = $db->getInsertId();
				$search = $sql = $db->select("SELECT * FROM adjmeth_supplier_details WHERE id='{$insertid}'");
				$result  = $search->fetch_assoc();
				$this->supid = $insertid;

			} else {
				$this->catid = "0";
			}
		}


		return $this;
	}

	
	
}
?>
