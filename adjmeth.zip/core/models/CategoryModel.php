<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class CategoryModel extends Models {
	
	public function categoryById($catname,$field,$optional=null) {

		$db = new Database;
		$models = new Models;
		$this->catname = $db->cleanData($catname);

		if($field == "name") {
			$field = "category_name";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "alias") {
			$field = "category_alias";
		} else {
			$field = "id";
		}
		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_stock_category WHERE $field='{$this->catname}' and status='1' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->catname = ucwords($res['category_name']);
			$this->catid = $res['id'];
			$this->catdefid = $res['id'];
			$this->catdes = $res['category_description'];
			$this->catparent = $res['category_parent'];
			$this->catsparent = $res['category_sparent'];
			$this->catparentopt = $this->categoryParent($this->catparent)->option;
			$this->catparentopt_sub = $this->categoryParent($this->catsparent)->option;
		} else {
			if($optional == "create") {
				$nname = ucwords(str_replace('-', ' ', $this->catname));
				$ins = $db->insert("INSERT INTO adjmeth_stock_category 
					(category_name,category_alias,status) values ('{$nname}', '{$this->catname}','1')") or trigger_error($db->db_error());
				$insertid = $db->getInsertId();
				$search = $sql = $db->select("SELECT * FROM adjmeth_stock_category WHERE id='{$insertid}'");
				$result  = $search->fetch_assoc();
				$this->catid = $insertid;

			} if($optional== "parent") {
				$this->catname = "";
			} else {
				$this->catid = "0";
			}
		}


		return $this;
	}


	public function categoryParent($catid) {
		$db = new Database;
		$models = new Models;

		$this->catid = $db->cleanData($catid);

		$sql = $db->select("SELECT * FROM adjmeth_stock_category WHERE `id`='{$this->catid}' and status='1' LIMIT 1");

		if($db->scount($sql) == 1) {
			$this->cfound = true;
			
			$res = $sql->fetch_assoc();
			$this->option = "<option selected='selected' value='{$res['id']}'>{$res['category_name']}</option>";
		} else {
			$this->cfound = true;
			$this->option = '';
		}
		return $this;
	}

	
	
}
?>
