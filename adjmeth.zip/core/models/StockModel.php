<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class StockModel extends Models {
	
	public function stockById($stockid) {

		$db = new Database;
		$supplier = new SupplierModel;
		$category = new CategoryModel;
		$this->stockid = $db->cleanData($stockid);

		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_stock WHERE `stock_id`='{$this->stockid}' and status='1' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->stock_id = ucwords($res['stock_id']);
			$this->stock_name = $res['stock_name'];
			$this->stock_alias = $res['palias'];
			$this->stock_quant = $res['stock_quantity'];
			$this->stock_avail = $this->stockAvail($this->stock_id)->avail_quant;
			$this->stock_sprice = $res['selling_price'];
			$this->stock_cprice = $res['company_price'];
			$this->stock_supplier_id = $res['supplier_id'];
			$this->stock_supplier = $supplier->supplierById($this->stock_supplier_id, "id", null)->supname;			
			$this->stock_entry = $res['entry_by'];
			$this->stock_category_id = $res['category'];
			$this->stock_category = $category->categoryById($this->stock_category_id, "id", null)->catname;			
			$this->stock_date = $res['date'];
		} else {
			$this->found = false;
		}


		return $this;
	}

	public function stockAvail($stockid) {
		$db = new Database;
		$models = new Models;
		$this->stockid = $db->cleanData($stockid);

		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_stock_avail WHERE `palias`='{$this->stockid}' and status='1' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->avail_id = ucwords($res['id']);
			$this->avail_alias = $res['palias'];
			$this->avail_quant = $res['quantity'];
		} else {
			$this->found = false;
		}


		return $this;

	}
	
}
?>
