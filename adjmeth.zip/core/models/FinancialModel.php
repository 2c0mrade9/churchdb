<?php

class FinancialModel extends Models {
	
	public function FinanceList($type, $page, $id=null, $limit=null, $where_clause=null,$del_show=null){
		$db = new Database;
		$users = new UserModel;
		$this->found = false;
		
		$typeid = '';
		$page = $this->Types("single", $page)->tslug;
		$typeid = $this->Types("single", $page)->tyid;
		
		if($id != null)	{
			$add = "`trancid`='$id' AND ";
		} else {
			$add = '';
		}
		
		if($type != null) {
			
			if($_SESSION['User_Role'] == 1)
				$where = "WHERE $add `tran_type`='$typeid' $where_clause AND `status`='1' AND `admin_status`='1' AND `super_status`='1'";
			elseif($_SESSION['User_Role'] == 2)
				$where = "WHERE $add `tran_type`='$typeid' $where_clause AND `status`='1' AND `admin_status`='1' AND `super_status`='1'";
			elseif($_SESSION['User_Role'] == 4)
				$where = "WHERE $add `tran_type`='$typeid' $where_clause AND `status`='1' AND `super_status`='1'";
			
			$sql = $db->select("SELECT * FROM `adjmeth_finances` $where ORDER BY `id` DESC $limit");
			
			if($db->scount($sql)>0){
				$this->found = true;
				
				if($type=="list") {
					
					while($res=$sql->fetch_assoc()){
						
						$date_recorded = $res['year']."-".$res['month']."-".$res['day'];
						$cur = $this->Currency('single',$res['currency'])->curname;
						$this->recorder = $users->getUserDetails($res['user_id'])->funame;
						
						if($res['tran_type2'] == 1)
							$tran_type2 = 'Main Harvest';
						else
							$tran_type2 = 'Mini Harvest';
						
						$display = "<tr class='gradeU' id='financial_record_id_{$res['trancid']}'>";
						$display .= "<td>{$res['trancid']}</td>";
						if($page=="harvest") {
							$display .= "<td>$tran_type2</td>";
						}
						//<a href='".SITE_URL."/admin/financial-$page-edit/{$res['trancid']}?edit' class='btn btn-'></a> 
						if($page!="harvest") {
							$display .= "<td>".ucwords($res['username'])."</td>";
						}
						$display .= "<td>".date("D dS M Y", strtotime($date_recorded))."</td>";
						$display .= "<td>$cur {$res['amount']}</td>";
						if($page=="harvest") {
							$display .= "<td>{$this->recorder}</td>";
						}
						if($del_show == null) {
							$display .= "<td><a href='".SITE_URL."/admin/financial-$page-edit/{$res['trancid']}?edit' class='btn btn-success'>";
							$display .= "<i class='fa fa-edit fa-fw'></i>Edit</a> ";
							if($_SESSION['User_Role'] == 1 || $_SESSION['User_Role'] == 4) {
								$display .= "<a href='javascript:deleteFinancialRecord(\"{$res['trancid']}\",\"Are you sure you want to delete this $page financial record?\")' class='btn btn-danger'>";
								$display .= "<i class='fa fa-trash-o fa-fw'></i>Delete</a>";
							}
							$display .= "</td>";
						}
						$display .= "</tr>";
						
						print $display;
					}
				} else {
					$row = $sql->fetch_assoc();
					$this->tid = $row["trancid"];
					$this->tname = ucwords($row["username"]);
					$this->mem_id = $row["mem_id"];
					$this->tran_type2 = $row["tran_type2"];
					$this->recorder = $users->getUserDetails($row['user_id'])->funame;
					$this->date_recorded = date("D dS F Y", strtotime($row['date']));
					$this->edited = $users->getUserDetails($row['editor_id'])->funame;
					$this->date_edited = date("D dS F Y, H:ia", strtotime($row['date_modified']));
					$this->rfull = $row['fulldate'];
					$this->rec_fulldate = date("D dS F Y", strtotime($row['fulldate']));
					$this->dayo = "<option selected value='{$row["day"]}'>{$row["day"]}</option>";
					$this->montho = "<option selected value='{$row["month"]}'>{$row["month"]}</option>";
					$this->yearo = "<option selected value='{$row["year"]}'>{$row["year"]}</option>";
					if($row["tran_type2"] == 1)
						$this->htypeo = "<option selected value='1'>Main Harvest</option>";
					else
						$this->htypeo = "<option selected value='2'>Mid Year Harvest</option>";
					
					$this->curo = $this->Currency('single',$row['currency'])->coptsel;
					$this->year = $row["year"];
					$this->ddate = $row["date"];
					$this->amount = $row["amount"];
					$this->comments = $row["comments"];
					$this->typeo = $this->Types("single",$row["tran_type"])->typeopt;
					
				}
			} else {
				$this->found = false;
			}
		}
		return $this;
	}
	
	public function FinanceListCollection($type, $where_clause=null, $limit=null) {
		$db = new Database;
		$users = new UserModel;
		
		$this->found = false;
		$typeid = $this->Types("single", "silver-collection")->tyid;
		
		$sql = $db->select("
			SELECT id, user_id, trancid, fulldate, currency, SUM( amount ) AS total_amount, amount 
			FROM `adjmeth_finances` 
			WHERE tran_type = '6' AND `status`='1'
			GROUP BY user_id, fulldate, currency
			ORDER BY id DESC 
			$limit
		");
		
		if($db->scount($sql)>0){
			$this->found = true;
			
			if($type="list"){
				while($res = $sql->fetch_assoc()){
					
					$date_recorded = date("D dS M Y", strtotime($res['fulldate']));
					$admin_uname = $users->getUserDetails($res['user_id'])->uname;
					$admin_name = $users->getUserDetails($res['user_id'])->funame;
					$admin_id = $users->getUserDetails($res['user_id'])->adid;
					
					$currency = $res['currency'];
					$amount = $res['total_amount'];
					
					$cur = $this->Currency('single',$res['currency'])->curname;
					
					
					$display = "<tr class='gradeU'>";
					//$display .= "<td>{$res['id']}</td>";
					$display .= "<td>{$date_recorded}</td>";
					$display .= "<td>$cur $amount</td>";
					$display .= "<td><a href='".SITE_URL."/admin/users/{$admin_uname}/$admin_id?edit'>{$admin_name}</a></td>";
					$display .= "<td><a href='".SITE_URL."/admin/financial-silver-collection-edit/{$res['trancid']}?edit' class='btn btn-success'>";
					$display .= "<i class='fa fa-edit fa-fw'></i>Edit</a> ";
					if($_SESSION['User_Role'] == 1 || $_SESSION['User_Role'] == 4) {
						$display .= "<a href='".SITE_URL."/admin/delete/financial-silver-collection/{$res['trancid']}' class='btn btn-danger'>";
						$display .= "<i class='fa fa-trash-o fa-fw'></i>Delete</a>";
					}
					$display .= "</td>";
					$display .= "</tr>";
						
					print $display;
				}
			} else {
				
			}	
		} else {
			$this->found = false;
		}
			
		return $this;
	}
	
	public function Types($type, $id=null){
		$db = new Database;
		$this->found = false;
		
		if($id != null) {
			if(is_numeric($id))
				$wh = 'id';
			else
				$wh = 'slug';
			$where = "WHERE `$wh`='$id'"; 
		}
		else $where='';
		
		$sql = $db->select("SELECT * FROM `adjmeth_finance_type` $where");
		
		if($db->scount($sql)>0){
			
			$this->found = true;
			
			if($type=="list") {
				while($row = $sql->fetch_assoc()){
					$this->display = "";
					
					print $this->display;
				}
			} else {
				$row = $sql->fetch_assoc();
				$this->tyid = $row["id"];
				$this->tyname = $row["name"];
				$this->tslug = $row["slug"];
				$this->status = $row["status"];
				$this->typeopt = "<option selected value='{$row["id"]}'>{$row["name"]}</option>";
			}
		} else {
			$this->found = false;
		}
		return $this;
	}
	
	public function ConfirmTransaction($tid) {
		$db = new Database;
		
		$this->found == false;
		
		$sql = $db->select("SELECT * FROM `adjmeth_finances` WHERE `trancid`='$tid' LIMIT 1");
		
		if($db->scount($sql) == 1)
			$this->found = true;
		else
			$this->found == false;
		
		return $this;
	}
	
	public function Pledge($type, $id=null){
		$db = new Database;
		$this->found = false;
		
		if($id != null) $id = "WHERE `trancid`='$id'"; else $id='';
		
		$sql = $db->select("SELECT * FROM `adjmeth_finance_pledge` $id");
		
		if($db->scount($sql)>0){
			$this->found = true;
			if($type=="list") {
				while($row=$sql->fetch_assoc()){
					$this->display ='';
					$this->display = "";
					
					print $this->display;
				}
			} else {
				$row = $sql->fetch_assoc();
				$this->tid = $row["trancid"];
				$this->pevent = $row["event_name"];
				$this->peventid = $row["event_id"];
				$this->peventdate = $row["event_date"];
				$this->preddate = $row["redeem_date"];
				$this->pcur = $row["currency"];
				$this->pamt = $row["amount"];
				$this->padmin_id = $row["admin_id"];
				$this->pdate = $row["date"];
				$this->pstatus = $row["status"];
			}
		} else {
			$this->found = false;
		}
		return $this;
		
	}
	
	public function Currency($type, $id=null){
		$db = new Database;
		$this->found = false;
		
		if($id != null) $id = "WHERE `id`='$id'"; else $id='';
		
		$sql = $db->select("SELECT * FROM `adjmeth_finance_currency` $id");
		
		if($db->scount($sql)>0){
			$this->found = true;
			if($type=="list") {
				while($row=$sql->fetch_assoc()){
					$this->display ='';
					$this->display = "";
					
					print $this->display;
				}
			} else {
				$row = $sql->fetch_assoc();
				$this->id = $row["id"];
				$this->curname = $row["name"];
				$this->cslug = $row["slug"];
				$this->exchange = $row["exchange"];
				$this->coptsel = "<option selected value='{$row["id"]}'>{$row["name"]}</option>";
			}
		} else {
			$this->found = false;
		}
		return $this;
	}
	
	public function AddCurrency($name,$slug,$exchange){
		$db = new Database;
		
		$sql = $db->insert("INSERT INTO `adjmeth_finance_currency` (name,slug,exchange)
						VALUES ('$name','$slug','$exchange')");
						
		if($sql)
			return true;
		else
			return false;
	}
	
	public function UpdateCurrency($id,$name,$slug,$exchange){
		$db = new Database;
		
		$sql = $db->update("UPDATE `adjmeth_finance_currency` SET `name`='$name',`slug`='$slug',`exchange`='$exchange' WHERE `id`='$tid' LIMIT 1");
			
		if($sql)
			return true;
		else
			return false;
	}
	
	public function AddPledge($tid,$ename,$eid,$edate,$reddate,$cur,$amt,$admin,$date){
		$db = new Database;
		
		$sql = $db->insert("INSERT INTO `adjmeth_finance_pledge` (trancid,event_name,event_id,event_date,redeem_date,currency,amount,admin_id,date)
						VALUES ('$tid','$ename','$eid','$edate','$reddate','$cur','$amt','$admin','".time()."')");
		if($sql)
			return true;
		else
			return false;
	}
	
	public function UpdatePledge($tid,$ename,$eid,$edate,$reddate,$cur,$amt,$admin,$date) {
		$db = new Database;
		
		$sql = $db->update("UPDATE `adjmeth_finance_pledge` SET `event_name`='$ename',`event_id`='$eid',`event_date`='$edate',`redeem_date`='$reddate',
				`currency`='$cur',`amount`='$amt',`editor_id`='$admin',`mod_date`='".time()."' 
				WHERE `trancid`='$tid' LIMIT 1");
				
		if($sql)
			return true;
		else
			return false;
	}
	
	public function DeleteFinance($table, $id){
		$delete = new DeleteModel;
		if($delete->Delete("$table","`id`='$id'")) {
			return true;
		} else {
			return false;
		}
	}
	
	
}
?>