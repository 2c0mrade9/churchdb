<?php
// determine if the database connection configuration is available
// if not, include the connection information
//if(!defined("DB_HOST")) { include '../index.php'; die(); }


/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */

class RequestsModel {

	public $display_submenu;
	public $data = NULL;
	public $found = false;

	public function ListRequests($limit,$where_clause=null,$del_show=null) {
		$db = new Database();
		$enc = new Encryption('reQuestsCrypting.');
		
		$sql = $db->select("SELECT * FROM `adjmeth_requests` WHERE `type`='photocopy' $where_clause $limit");
		
		if($db->scount($sql) > 0) {			
			while($res = $sql->fetch_assoc()) {
				$stat = $res["status"];
				if($stat=='Pending')
					$stat='<span style="color:red">Pending</span>';
				else
					$stat='<span style="color:green">Approved</span>';
				
				if(isset($_SESSION['chUser_Role']) and $_SESSION['chUser_Role'] == 1 || $_SESSION['chUser_Role'] == 4)
					$txt = "Edit";
				else
					$txt = "View";
					

				$display = "<tr class='gradeU'  id='request_id_{$res['rid']}'>";
				$display .= "<td>{$res['rid']}</td>";
				$display .= "<td>{$res['name']}</td>";
				$display .= "<td>".$res['subject']."</td>";
				$display .= "<td>".date("D dS M Y", strtotime($res['date']))."</td>";
				$display .= "<td>{$stat}</td>";
				if($del_show == null) {
				$display .= "<td>";
				$display .= "<a class='btn btn-success' href='".SITE_URL."/admin/requests-edit/{$res['rid']}?edit'><i class='fa fa-edit fa-fw'></i>$txt</a> ";
				if($_SESSION['chUser_Role'] == 1 || $_SESSION['chUser_Role'] == 4) {
					$display .= "<a href='javascript:deleteRequest(\"{$res['rid']}\",\"Are you sure you want to delete this request?\");' class='btn btn-danger'>";
					$display .= "<i class='fa fa-trash-o fa-fw'></i>Delete</a>";
				}
				$display .= "</td>";
				}
				$display .= "</tr>";

				print $display;
			}
		}
	}
	
	public function RequestById($rid,$super=null) {
		$db = new Database;
		
		$this->found = false;
		if($super==null)
			$type='original';
		else
			$type="photocopy";
		
		$sql = $db->select("SELECT * FROM adjmeth_requests WHERE `rid`='$rid' AND `type`='photocopy' LIMIT 1");
		
		if($db->scount($sql) == 1) {
			
			$res = $sql->fetch_assoc();
			$this->found = true;
			
			$this->rid = $res['rid'];
			//$this->UpdateStatus($this->rid);
			$this->suject = $res['subject'];
			$this->comments = $res['comments'];
			$this->purpose = $res['purpose'];
			$this->name = $res['name'];
			$this->userid = $res['user_id'];
			$this->hod = $res['hod'];
			$this->hodid = $res['hod_id'];
			//$this->hodorg = $orgn->GetOrgById($res['organization'])->optsel;
			$this->amount = $res['amount'];
			$this->rdate = $res['date'];
			$this->mdate = $res['mod_date'];
			$this->status = $res['status'];
			//$this->optcur = $finance->Currency($res["currency"])->coptsel;
			$this->statusopt = "<option selected value='{$res["status"]}'>{$res["status"]}</option>";
			$this->deleted = $res['deleted'];
		} else {
			$this->found = false;
		}
		
		return $this;

	}
	
	public function VerifyUserSeen($id,$mem_id) {
		$db = new Database;
		$type="photocopy";
		$sql = $db->select("SELECT * FROM `adjmeth_requests` WHERE `rid`='$id' AND `type`='$type' LIMIT 1");
		
		while($row = $sql->fetch_assoc()) { 
			$seen_array = $row["seen_uid"]; 
		}
		
		$in_array = explode(",", $seen_array);
		
		if (in_array($id, $in_array))
			return true;
		else
			return false;
	}
	
	public function AddUserSeen($id, $mem_id){
		$db = new Database();
		
		if($this->VerifyUserSeen($id, $mem_id) == false) {
			$ins = $this->ProcessUserSeen($id, $mem_id);
			return $ins;
		} else 
			return false;
	}
	
	public function ProcessUserSeen($id, $mem_id) {
		
		$db = new Database();
		$sql = $db->select("SELECT * FROM `adjmeth_requests` WHERE `rid`='$id' LIMIT 1"); 
		
		while($row = $sql->fetch_assoc()) { $seen_array = $row["seen_uid"]; }
		
		$in_array = explode(",", $seen_array);

		if (in_array($id, $in_array)) { print 'This member is already a member of the organization.';}
		else {
			if ($seen_array != "") { $seen_array = "$seen_array,$id"; } else { $seen_array = "$id"; }

			$upd = $db->update("UPDATE `adjmeth_requests` SET `seen_array`='$seen_array' WHERE `rid`='$id'");
			
			if($upd)
				return true;
			else
				return false;
		}
	}
	
	public function ListUsersSeen($id){
		
		$db = new Database;
		$mem = new MembersModel;
		
		
		$sql = $db->select("SELECT * FROM `adjmeth_requests` WHERE `rid`='$id' AND `type`='photocopy' LIMIT 1");
		
		while($row = $sql->fetch_assoc()) { 
			$seen_array = $row["seen_uid"]; 
		}
		
		$in_array = explode(",", $seen_array);
		$uid = $in_array[1];
		$uname = $mem->GetMemberDetails($uid)->fullname;
	}
	
	public function InsertRequest($id,$uid,$com,$name,$nid,$hod,$hodid,$org,$sub,$pur,$cur,$amt,$adminid){
		$db = new Database;
		$enc = new Encryption('reQuestsCrypting.');
		
		$ins = $db->insert("INSERT INTO `adjmeth_requests` 
				(`rid`,`type`,`recorder_id`,`comments`,`name`,`user_id`,`hod`,`hod_id`,`organization`,`subject`,`purpose`,`currency`,`amount`,`date`,`time`,`adminid`)
				VALUES ('$id','original','$uid','".$enc->encrypt($com)."','$name','$nid','$hod','$hodid','$org','".$enc->encrypt($sub)."','".$enc->encrypt($pur)."','$cur','$amt',now(),'".time()."','$adminid')
			") or trigger_error($db->db_error());
		
		if($ins) {
			$db->insert("INSERT INTO `adjmeth_requests` 
				(`rid`,`type`,`recorder_id`,`comments`,`name`,`user_id`,`hod`,`hod_id`,`organization`,`subject`,`purpose`,`currency`,`amount`,`date`,`time`,`adminid`)
				VALUES ('$id','photocopy','$uid','".$enc->encrypt($com)."','$name','$nid','$hod','$hodid','$org','".$enc->encrypt($sub)."','".$enc->encrypt($pur)."','$cur','$amt',now(),'".time()."','$adminid')
			");
			
			return true;
		}
		else
			return false;
	}
	
	public function UpdateRequest($id,$com,$name,$nid,$hod,$hodid,$orgs,$sub,$pur,$cur,$amt,$status=null,$deleted=null,$uid){
		$enc = new Encryption('reQuestsCrypting.');
		$db = new Database;
		
		$upd = $db->update(
			"UPDATE `adjmeth_requests` SET `comments`='".$enc->encrypt($com)."',`name`='$name',`user_id`='$nid',`hod`='$hod',`hod_id`='$hodid',
			`organization`='$orgs',`subject`='".$enc->encrypt($sub)."',`purpose`='".$enc->encrypt($pur)."',`currency`='$cur',`amount`='$amt',
			`mod_date`=now(),`mod_time`='".time()."',`adminid`='$uid',`status`='$status'
			WHERE `rid`='$id' AND `type`='photocopy'"
		);
		
		if($upd) {
			$this->UpdateRequestHistory($id,$com,$name,$nid,$hod,$hodid,$orgs,$sub,$pur,$cur,$amt,$status=null,$deleted=null,$uid);
			return true;
		} else
			return false;
	}
	
	public function UpdateRequestHistory($id,$com,$name,$nid,$hod,$hodid,$orgs,$sub,$pur,$cur,$amt,$status=null,$deleted=null,$uid){
		$enc = new Encryption('reQuestsCrypting.');
		$db = new Database;
		
		$db->insert("INSERT INTO `adjmeth_requests_history` 
				(`rid`,`type`,`recorder_id`,`comments`,`name`,`user_id`,`hod`,`hod_id`,`organization`,`subject`,`purpose`,`currency`,`amount`,`date`,`time`,`adminid`)
				VALUES ('$id','updated','$uid','".$enc->encrypt($com)."','$name','$nid','$hod','$hodid','$orgs','".$enc->encrypt($sub)."','".$enc->encrypt($pur)."','$cur','$amt',now(),'".time()."','$uid')
			") or trigger_error($db->db_error());
			
	}
	
	public function UpdateStatus($rid,$sta=null) {
		$db = new Database;
		if($sta!=null) {
			$sql = $db->select("SELECT * FROM `adjmeth_requests` WHERE `rid`='$rid' LIMIT 1"); 
			while($row = $sql->fetch_assoc()) { 
				$stat = $row["status"]; 
				if($stat == 'Pending')
					$db->update("UPDATE `adjmeth_requests` SET `status`='Approved' WHERE `rid`='$rid'");
				else
					$db->update("UPDATE `adjmeth_requests` SET `status`='Pending' WHERE `rid`='$rid'");
			}
		} else 
			$db->update("UPDATE `adjmeth_requests` SET `status`='Approved' WHERE `rid`='$rid'");
	}
	
	public function DeleteRequest($id){
		$delete = new DeleteModel;
		if($delete->Delete("adjmeth_requests","`rid`='$id'")) {
			return true;
		} else {
			return false;
		}
	}
	
	
}