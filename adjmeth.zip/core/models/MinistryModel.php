<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class MinistryModel extends Models {
	
	public function MinistryById($mid,$field,$optional=null) {

		$db = new Database;
		$models = new Models;
		$this->mid = $db->cleanData($mid);

		if($field == "name") {
			$field = "name";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "alias") {
			$field = "slug";
		} else {
			$field = "id";
		}
		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_ministry WHERE $field='{$this->mid}' LIMIT 1") or trigger_error($db->db_error());
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->mname = ucwords($res['name']);
			$this->mid = $res['id'];
			$this->mslug = $res['slug'];
		} else {
			if($optional == "create") {
				if(strlen($this->mid) > 3) {
					$mname = ucwords(str_replace('-', ' ', $this->mid));
					$ins = $db->insert("INSERT INTO adjmeth_ministry 
						(name,slug) values ('{$mname}', '{$this->mid}')");
					$insertid = $db->getInsertId();
					$search = $sql = $db->select("SELECT * FROM adjmeth_ministry WHERE id='{$insertid}'");
					$result  = $search->fetch_assoc();
					$this->mname = $result['name'];
					$this->mid = $insertid;
				} else {
					$this->mname = '';
					$this->mid = '0';
				}

			}elseif($optional== "parent") {
				$this->mname = "";
			} else {
				$this->mid = "0";
				$this->mname= "";
			}
		}


		return $this;
	}
	
}
?>
