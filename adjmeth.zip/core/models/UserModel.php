<?php

/**
*@check if the user wanted to access the file directly
*@if so display a forbidden page
**/
if( !defined('DB_HOST')) die('Access Denied');

class UserModel extends Models {
	   
	public function send_activation_link($to, $sub, $uname, $pass, $email, $unique_key) {
		
		$site = new Options();
		
		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

		// Additional headers
		$headers .= "To: $uname <$to>" . "\r\n";
		$headers .= 'From: '.SITE_NAME.' <emmallob14@gmail.com>' . "\r\n";
		$headers .= 'CC: emmallob14@gmail.com' . "\r\n";

		
		$msg = 'Thanks for registering with '.$site->getSiteName();
		$msg .= '<br>The following are your login details:<br>';
		$msg .= '<strong>Username:</strong> '.$uname;
		$msg .= '<br><strong>Password:</strong> '.$pass;
		$msg .= '<br>Before you can use your account please first activate it.<br>';
		$msg .= 'Please follow the link below to activate your account.<br>';
		$msg .= '<a href="'.SITE_URL.'/private/activate/'.$email.'/'.$unique_key.'/">Click Here to Activate</a>';
		$msg .= '<br>If it does not work please copy this link and place it in your browser url.<br>';
		$msg .= SITE_URL.'/private/activate/'.$email.'/'.$unique_key;
			
		// use wordwrap() if lines are longer than 70 characters
		$msg = wordwrap($msg,70);

		mail($to, $SUB, $msg, $headers);
	}
	
	public function getAdminUsers() {
		$db = new Database();
		
		if($_SESSION['chUser_Role'] == 1)
			$sql = $db->select("SELECT * FROM `".ADMIN_TABLE."` WHERE `status`='1' AND `Role`!='4' AND `admin_deleted`='0'");
		elseif($_SESSION['chUser_Role'] == 4)
			$sql = $db->select("SELECT * FROM `".ADMIN_TABLE."` WHERE `status`='1' AND `Role`!='4'");
		
		while($res = $sql->fetch_assoc()) {
			
			$name_alias = str_ireplace(' ', '-', strtolower($res['FullName']));
			
			$linked = "<i class='fa fa-edit fa-fw'></i>Edit ";
			$linked_url = "";
			$linked_del = "success";
			$linked_del2 = "";
			if($res['admin_deleted']==1 and $res['super_deleted']==0) {
				$linked = "<i class='fa fa-power-off fa-fw'></i>Admin Deleted";
				$linked_url = "onclick='return false;'";
				$linked_del = "danger";
				$linked_del2 = "style='display:block;width:80px;'";
			} elseif($res['admin_deleted']==1 and $res['super_deleted']==1) {
				$linked = "<i class='fa fa-power-off fa-fw'></i>Super Deleted";
				$linked_url = "onclick='return false;'";
				$linked_del = "danger";
				$linked_del2 = "style='display:none;width:80px;'";
			}
			
			if($_SESSION['chCMS_Username'] != $res['Username'])
				$msg = 'Are you sure you want to delete this Administrator?';
			else 
				$msg = 'Are you sure you want to delete your account from the database? NOTE: You will be automatically Logged Out.';
			
			if($res['Role']==1)
				$rank = "Administrator";
			elseif($res['Role']==2)
				$rank = "Finance Administrator";
			elseif($res['Role']==3)
				$rank = "Registry";
				
			$display = "<tr class='gradeU' id='admin_id_{$res['Username']}'>";
			$display .= "<td>{$res['FullName']}</td>";
			$display .= "<td><a href='".SITE_URL."/admin/profiles/{$res['Username']}/{$res['id']}?edit'>{$res['Username']}</a></td>";
			$display .= "<td>{$rank}</td>";
			$display .= "<td>".date("dS M Y H:i:s a", strtotime($res['LastAccess']))."</td>";
			$display .= "<td><a $linked_url href='".SITE_URL."/admin/users/{$res['Username']}/{$res['id']}?edit' class='btn btn-$linked_del'>$linked</a>";
			if($_SESSION['chUser_Role'] == 1 || $_SESSION['chUser_Role'] == 4) {
				$display .= "<a $linked_del2 href='javascript:deleteAdminUser(\"{$res['Username']}\", \"".$_SESSION['chCMS_Username']."\",\"$msg\");' class='btn btn-warning'>";
				$display .= "<i class='fa fa-trash-o fa-fw'></i>Delete</a>";
			}
			$display .= "</td>";
			$display .= "</tr>";

			print $display;
		}

	}
	
	public function getSiteUsersList() {
		$db = new Database();

		$sql = $db->select("SELECT * FROM `adjmeth_users`");

		while($res = $sql->fetch_assoc()) {
			
			if($res['status'] == 1)
				$status = '<font color="green">status</font>';
			else
				$status = '<font color="red">Pending</font>';
			$display = "<tr class='gradeU'>";
			$display .= "<td>{$res['unique_key']}</td>";
			$display .= "<td>{$res['username']}</td>";
			$display .= "<td>{$res['fullname']}</td>";
			$display .= "<td>".$this->RelativeTimeCommented($res['lastlogin'])."</td>";
			$display .= "<td>{$status}</td>";
			$display .= "<td><a href='site-users/{$res['unique_key']}/{$res['id']}?edit' class='btn btn-success'>";
			$display .= "<i class='fa fa-edit fa-fw'></i>Edit</a> ";
			$display .= "<a href='delete/site-users/{$res['unique_key']}' class='btn btn-danger'>";
			$display .= "<i class='fa fa-trash-o fa-fw'></i>Delete</a>";
			$display .= "</td>";
			$display .= "</tr>";

			print $display;
		}

	}
	
	public function get_userDetails($user_id) {
		$db = new Database();
		$sql = $db->select("SELECT * FROM `adjmeth_users` WHERE `id`='$user_id' OR `mem_id`='$user_id' LIMIT 1");
		
		
		if($db->scount($sql) == 1) {
			//set the user found status
			$this->found = true;
			//using the while loop to get the data and set it in an array
			while($res = $sql->fetch_assoc()) {
				$this->id = $res['id'];
				$this->unq = $res['mem_id'];
				$this->stime = $res['sessiontimeout'];
				$this->uname = $res['username'];
				$this->imageid = $res['image_id'];
				$this->fname = ucwords($res['fullname']);
				$this->email = $res['email'];
				$this->llogin = $res['lastlogin'];
				$this->djoin = $res['date_joined'];
				$this->ago = $this->RelativeTimeCommented($res['lastlogin']);
				$this->djoined = date("D dS M Y", strtotime($res['date_joined']));
				$this->lstatus = $res['loginstatus'];
			}
		} else {
			$this->found = false;
			$this->llogin = 'Unknown';
			$this->id = '0';
			$this->unq = '0';
			$this->uname = 'Unknown';
			$this->stime = time();
			$this->fname = 'Unknown';
			$this->email = '';
			$this->lstatus = '0';
			$this->djoin = '';
		}
		
		return $this;
	}
	
	public function getUserDetails($id) {
		$db = new Database();
		
		$this->found = false;
		
		if(is_numeric($id))
			$field = "id";
		else
			$field = "Username";
			
		$sql = $db->select("SELECT * FROM `adjmeth_admin` WHERE `$field`='$id' OR 'Mem_ID'='$id' AND `status`='1'");
		if($db->scount($sql) == 1) {
			$this->found = true;
			while($res = $sql->fetch_assoc()) {
				$this->adid = $res['id'];
				$this->fname = $res['FirstName'];
				$this->lname = $res['LastName'];
				$this->uname = $res['Username'];
				$this->memb_id = $res['Mem_ID'];
				$this->funame = $res['FullName'];
				$this->ulinked = "<a href='".SITE_URL."/admin/profiles/".$this->uname."'>".$this->funame."</a>";
				$this->email = $res['Email'];
				$this->role = $res['Role'];
				$this->lacs = strftime(date("D d M Y, H:i:a", strtotime($res['LastAccess'])));
				
				return $this;
			}
		}
		$this->found = false;
		$this->funame = 'Error';
		return $this;
	}	
	
	public function getUserLastPostDetials($user_id) {
		$db = new Database();
		$this->found = false;
		$sql = $db->select("SELECT * FROM `ch_articles` WHERE `ArticleType`='_opinions' AND `user_id`='$user_id' AND `Published` = '1' ORDER BY `id` DESC LIMIT 1");
		
		if($db->scount($sql) > 0) {
			$this->found = true;
			while($res = $sql->fetch_assoc()) {
				$this->ldate = strftime(date("D d M, Y", strtotime($res["PostDate"])));
			}
		} else {
			$this->found = false;
		}
		return $this;
	}
	
	public function confirmIPAddress($value,$type,$username) {
		$db = new Database();
		
		$sql = "SELECT 
			attempts, 
				(CASE when lastlogin is not NULL and DATE_ADD(LastLogin, INTERVAL ".TIME_PERIOD." MINUTE) 
					> 
				NOW() then 1 else 0 end) as Denied 
			FROM 
				`ch_attempts_logs` WHERE `usrn`='$username' AND `ip` = '$value' AND `type`='$type'";
	 
	   $result = $db->select($sql);
	   $data = $result->fetch_assoc();
	 
	   //Verify that at least one login attempt is in database

	   if (!$data) {
		 return 0;
	   } 
	   if ($data["attempts"] >= ATTEMPTS_NUMBER) {
		  if($data["Denied"] == 1) {
			 return 1;
		  }
		 else
		 {
			$this->clearLoginAttempts($value,$type,$username);
			return 0;
		 }
	   }
	   return 0;  
	}
	
	public function addLoginAttempt($value,$type,$username) {
	   $db = new Database();
	   // increase number of attempts
	   // set last login attempt time if required    
		$sql = "SELECT * FROM `ch_attempts_logs` WHERE `usrn`='$username' AND `ip` = '$value' AND `type`='$type'"; 
		
		$result = $db->select($sql);
		$data = $result->fetch_assoc();
		
		if($data) {
			$attempts = $data["attempts"]+1;

			if($attempts==3) {
			 $q = "UPDATE `ch_attempts_logs` SET attempts=".$attempts.", lastlogin=NOW() WHERE `usrn`='$username' AND `ip` = '$value' AND `type`='$type'";
			 $result = $db->update($q);
			}
			else {
			 $q = "UPDATE `ch_attempts_logs` SET attempts=".$attempts." WHERE `usrn`='$username' AND `ip` = '$value' AND `type`='$type'";
			 $result = $db->update($q);
			}
		}
		else {
		   $q = "INSERT INTO `ch_attempts_logs` (usrn,ip,type,attempts,lastlogin) values ('$username','$value','$type',1,NOW())";
		   $result = $db->insert($q);
		}
    }
	
	function clearLoginAttempts($value,$type,$username) {
		$db = new Database();
		$q = "UPDATE `ch_attempts_logs` SET attempts = 0 WHERE `usrn`='$username' AND `ip` = '$value' AND `type`='$type'"; 
		return $db->update($q);
   }
   
}
?>