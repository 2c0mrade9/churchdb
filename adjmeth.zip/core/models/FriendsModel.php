<?php

class FriendsModel extends MemberModel {
	
	public function CheckUserFriend($userid, $memid) {
		
		$db = new Database();
		
		$sql = $db->select("SELECT * FROM `ch_members` WHERE `mem_id`='$userid' LIMIT 1"); 
		
		while($row = $sql->fetch_assoc()) { 
			$frnd_arry_mem1 = $row["friends_array"]; 
		}
		
		$frndArryMem1 = explode(",", $frnd_arry_mem1);
		
		if (in_array($memid, $frndArryMem1))
			return true;
		else
			return false;

	}
	
	public function AddFriendToList($userid, $memid) {
		$db = new Database();
		
		if($this->CheckUserFriend($userid, $memid) == false) {
			$ins = $this->CheckPendingState($userid, $memid);
			return $ins;
		} else 
			return 'You are already friends with the user.';
	}
	
	public function AcceptFriendRequest($userid, $memid, $reqID) {
		//$userid :: This is the user accepting the others friend request
		//$memid :: This is the user who sent the friend request.
		
		$db = new Database();
		$sql = $db->select("SELECT * FROM `ch_members` WHERE `mem_id`='$userid' LIMIT 1"); 
		$sql2 = $db->select("SELECT * FROM `ch_members` WHERE `mem_id`='$memid' LIMIT 1");
		
		while($row = $sql->fetch_assoc()) { $frnd_arry_mem1 = $row["friends_array"]; }
		while($row = $sql2->fetch_assoc()) { $frnd_arry_mem2 = $row["friends_array"]; }
		
		$frndArryMem1 = explode(",", $frnd_arry_mem1);
		$frndArryMem2 = explode(",", $frnd_arry_mem2);
		if (in_array($memid, $frndArryMem1)) { print   'This member is already your Friend'; }
		elseif (in_array($userid, $frndArryMem2)) { print   'This member is already your Friend'; }
		
		else {
			if ($frnd_arry_mem1 != "") { $frnd_arry_mem1 = "$frnd_arry_mem1,$memid"; } else { $frnd_arry_mem1 = "$memid"; }
			if ($frnd_arry_mem2 != "") { $frnd_arry_mem2 = "$frnd_arry_mem2,$userid"; } else { $frnd_arry_mem2 = "$userid"; }
	
			$UpdateArrayMem1 = $db->update("UPDATE `ch_members` SET `friends_array`='$frnd_arry_mem1' WHERE `mem_id`='$userid'");
			$UpdateArrayMem2 = $db->update("UPDATE `ch_members` SET `friends_array`='$frnd_arry_mem2' WHERE `mem_id`='$memid'");
			$deleteThisPendingRequest = $db->update("DELETE FROM `ch_members_requests` WHERE `id`='$reqID' LIMIT 1"); 
		}
	}
	
	public function DeleteFriendRequest($reqID){
		$db = new Database();
		if($db->update("DELETE FROM `ch_members_requests` WHERE `id`='$reqID' LIMIT 1")){
			print "Request Denied";
		}
	}
	
	public function CheckPendingState($userid, $mem_id){
		$db = new Database();
		
		$sql = $db->select("SELECT * FROM `ch_members_requests` WHERE `mem_id`='$userid' AND `req_id`='$mem_id' LIMIT 1"); 
		$sql2 = $db->select("SELECT * FROM `ch_members_requests` WHERE `mem_id`='$mem_id' AND `req_id`='$userid' LIMIT 1"); 
		
		if($db->scount($sql) > 0)
			return 'You have a Friend request pending for this member. Please be patient.';
		elseif($db->scount($sql2) > 0)
			return 'This user has requested you as a Friend already! Check your Requests on your profile.';
		else {
			if($db->insert("INSERT INTO ch_members_requests (mem_id, req_id, timedate) VALUES('$userid','$mem_id','".time()."')"))
				return "Friend request sent successfully. This member must approve the request";
			else
				return 'There was an error with your request';
		}
	}
	
	
}
?>