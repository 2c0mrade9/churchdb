<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class EventsModel {
	
	public function EventById($cid,$field,$optional=null) {

		$db = new Database;
		$models = new Models;
		$member = new MemberModel;
		
		$this->cid = $db->cleanData($cid);

		if($field == "name") {
			$field = "name";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "alias") {
			$field = "slug";
		} else {
			$field = "id";
		}
		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_events WHERE $field='{$this->cid}' and status='1' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->ename = ucwords($res['name']);
			$this->eid = $res['id'];
			$this->eslug = $res['slug'];
			$this->esdate = $res['start_date'];
			$this->eedate = $res['end_date'];
			$this->estime = date("H:i",strftime($res['start_time']));
			$this->eetime = date("H:i",strftime($res['end_time']));
			$this->eministry = $res['ministry'];
			$this->eministry_slug = $res['ministry_slug'];
			$this->eministry_opt = "<option selected='selected' value='{$this->eministry}'>{$this->eministry}</option>";
			$this->estatus = $res['e_status'];
			$this->edetails = $res['details'];
			$this->etotal = $res['total'];
			$this->emembers = $res['members'];
			$this->evisitors = $res['visitors'];
			$this->estatus_opt = "<option selected='selected' value='{$this->estatus}'>{$this->estatus}</option>";
		} else {
			$this->eid = "0";
			$this->ename = "";
		}


		return $this;
	}
	
}
?>
