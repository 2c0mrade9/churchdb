<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class MemberModel extends Models {
	
	public function MemberById($uniqueid,$link=null,$optional=null,$field=null) {

		$db = new Database;
		$org = new OrganizationModel;
		$cla = new ClassModel;
		$this->uniqueid = $db->cleanData($uniqueid);
		
		if($field == "slug") {
			$field = "slug";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "uniqueid") {
			$field = "uniqueid";
		} else {
			$field = "uniqueid";
		}

		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_members WHERE `$field`='{$this->uniqueid}' and status='1' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->mem_id = ucwords($res['uniqueid']);
			$this->mem_fname = $res['fname'];
			$this->mem_title = $res['title'];
			$this->mem_lname = $res['lname'];
			$this->mem_fulln = $res['fullname'];
			$this->mem_res = $res['residence'];
			$this->mem_dob = $res['dob'];
			$this->mem_dob1 = date("l d M Y", strtotime($this->mem_dob));
			$this->mem_join = $res['date_join'];
			$this->mem_join1 = date("l d M Y", strtotime($this->mem_join));
			$this->mem_add = $res['address'];
			$this->mem_gender = ucwords($res['gender']);
			$this->mem_phone = $res['phone'];
			$this->mem_image = $res['image'];
			
			$this->mem_image_path = "assets/images/members/".$this->mem_image;
			if(is_file($this->mem_image_path) && file_exists($this->mem_image_path))
				$this->mem_image = "<img width=\"150px\" src=\"".SITE_URL."/{$this->mem_image_path}\" alt=\"\"/>";
			else
				$this->mem_image = "<img width=\"150px\" src=\"".SITE_IMAGE_PATH."/default.png\" alt=\"\"/>";
			
			$this->mem_phone1 = $res['phone1'];
			$this->mem_occup = $res['occupation'];
			$this->mem_email = $res['email'];
			$this->mem_slug = $res['slug'];
			$this->mem_class = $res['m_class'];
			$this->mem_org = $res['orgname'];
			$this->mem_noofchild = $res['no_of_children'];
			$this->mem_marstat=$res['marital_status'];
			$this->mem_sorg = $res['orgsub'];
			$this->mem_org1 = $res['organization'];
			$this->mem_sorg1 = $res['suborganization'];
			$this->mem_nclass = $cla->ClassById($this->mem_class, "id", null)->cname;			
			
		} else {
			if($optional == "create") {
				if(strlen($this->uniqueid) > 2) {
					$nname = ucwords(str_replace('-', ' ', $this->uniqueid));	
					$max = $db->maxOfAll("id", "adjmeth_members");
					$max=$max+rand(1, 9999);
					$autoid=$max;
					
					$explode = explode(" ",$nname);
					$fname = $explode[0];
					if(isset($explode[1])) {
						$lname = $explode[1];
					}
					if(isset($explode[2])) {
						$lname .= " ".$explode[2];
					}
					if(isset($explode[3])) {
						$lname .= " ".$explode[3];
					}
					
					$ins = $db->insert("INSERT INTO adjmeth_members 
						(uniqueid,fname,lname,fullname,slug) values ('AMC$autoid','$fname','$lname','$nname','{$this->uniqueid}')");
					$insertid = $db->getInsertId();
					$search = $sql = $db->select("SELECT * FROM adjmeth_members WHERE id='{$insertid}'");
					$result  = $search->fetch_assoc();
					$this->found = true;
					$this->mem_fulln = $result['fullname'];
					$this->mem_id = ucwords($result['uniqueid']);
				} else {
					$this->found = false;
					$this->mem_id = '0';
					$this->mem_fulln = "";
				}

			} elseif($optional== "parent") {
				$this->found = false;
				$this->mem_id = '0';
				$this->mem_fulln = "";
			} else {
				$this->found = false;
				$this->mem_id = '0';
				$this->mem_fulln = "";
			}
		}


		return $this;
	}
	
	
	public function MonthById($mid,$field=null) {
		
		$db = new Database;
		$this->mid = $db->cleanData($mid);
		
		$this->found = false;
		
		if($field == "slug") {
			$field = "slug";
		} elseif($field == "mid") {
			$field = "mid";
		} else {
			$field = "id";
		}
		$this->mid;

		$sql = $db->select("SELECT * FROM adjmeth_months WHERE `$field`='{$this->mid}' LIMIT 1") or trigger_error($db->db_error());
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->m_id = $res['id'];
			$this->m_name = $res['name'];
		} else {
			$this->found = false;
			$this->m_id = '0';
			$this->m_name = "";
		}
		
		return $this;
	}
	
}
?>
