<?php
class ChatModel extends MemberModel {
	
	public $found = false;
	
	public function __construct() {
		$this->db = new Database;
		$this->enc = new Encryption('chatCrypted');
		$this->users = new UserModel;
		$this->dbmembers = new MemberModel;
	}
	
	public function loadSingleUserMessages($sid) {
		
		$models = new Models;
		
		$sql = $this->db->select("
			SELECT * FROM `ch_chats` WHERE 
				(`sender_id`='$sid' AND `sender_deleted`='0') OR 
				(`receiver_id`='$sid' AND `receiver_deleted`='0')
				ORDER BY `id` LIMIT 50
		");
		
		if($this->db->scount($sql) > 0) {
			$this->found = true;
			while($res = $sql->fetch_assoc()) {
			
				$msg = '';
				
				//$msg .= "SENDER: {$res['sender_id']}, RECEIVER: {$res['receiver_id']} - ". $this->addlinks($this->add_n_smilies($this->no_magic_quotes(strip_tags($this->enc->decrypt($res['message'])))))."<br>";
				
				$sender = $this->users->getUserDetails($res['sender_id'])->uname;
				$receiver = $this->users->getUserDetails($res['receiver_id'])->uname;
				
				if($sender == $_SESSION['chCMS_Username'])
					$senderf = "You";
				else
					$senderf = $this->users->getUserDetails($res['sender_id'])->funame;
				if($receiver == $_SESSION['chCMS_Username'])
					$receiverf = "You";
				else
					$receiverf = $this->users->getUserDetails($res['receiver_id'])->funame;
				
				if($sender == $_SESSION['chCMS_Username'])
					$sender1 = $receiver;
				else
					$sender1 = $sender;
				

				$style = '';
				$deepen = '';
				if($res['r_seen'] == 0) {
					$status = '<span style="color:#ff0000;font-weight:bolder;">Unread</span>';
					$deepen = '.deepen{color:#ff0000!Important;}';
					$class = 'deepen';
				} else {
					$time = date("D M y, H:ia", strftime($res['r_time']));
					$status = '<span style="color:green;font-size:12px;font-weight:normal">Seen: '.$time.'</span>';
					$class = '';
				}
				
				print "<style>$deepen</style>";
					
				$display = "<tr id='msgrow_{$res['id']}' class='$class'>";
				$display .= "<td>{$res['id']}</td>";
				$display .= "<td><a href='".URL_ADMIN."/profiles/$sender' class='btn btn-'>".ucwords($senderf)."</a></td>";
				$display .= "<td><a href='".URL_ADMIN."/profiles/$sender1' class='btn btn-'>".ucwords($receiverf)."</a></td>";
				$display .= "<td><a title='Read Message Details' href='".URL_ADMIN."/messages/{$res['msg_id']}/$sender1?read' class='btn btn-'>".$this->enc->decrypt($res['subject'])."</a></td>";
				$display .= "<td>".$models->RelativeTimeCommented($res['time'])."</td>";
				$display .= "<td>{$status}</td>";
				$display .= "<td><a href='".URL_ADMIN."/messages/{$res['msg_id']}/$sender1?read' class='btn btn-success'>";
				$display .= "<i class='fa fa-edit fa-fw'></i>Read</a> ";
				$display .= "<a href='javascript:deleteMessage(\"{$res['id']}\",\"Are you sure you want to delete this message?\")' class='btn btn-danger'>";
				$display .= "<i class='fa fa-trash-o fa-fw'></i>Delete</a>";
				$display .= "</td>";
				$display .= "</tr>";
				
				print $display;

			}
		} else {
			$this->found = false;
		}
		
		return $this;
	}
	
	public function loadUserMessages($sid, $rid) {
		$sql = $this->db->select("
			SELECT * FROM `ch_chats` WHERE 
				(`sender_id`='$sid' AND `receiver_id`='$rid' AND `sender_deleted`='0') OR 
				(`receiver_id`='$sid' AND `sender_id`='$rid' AND `receiver_deleted`='0')
				ORDER BY `id` DESC
		");
		
		if($this->db->scount($sql) > 0) {
			$this->found = true;
			while($res = $sql->fetch_assoc()) {
				$msg = '';
				$msg .= "SENDER: {$res['sender_id']}, RECEIVER: {$res['receiver_id']} - ". $this->addlinks($this->add_n_smilies($this->no_magic_quotes(strip_tags($this->enc->decrypt($res['message'])))))."<br>";
				
				print $msg;
			}
		} else {
			$this->found = false;
		}
		
		return $this;
	}
	
	public function loadUserMessagesLimit($sid, $rid) {
		$sql = $this->db->select("
			SELECT * FROM `ch_chats` WHERE 
				(`sender_id`='$sid' AND `receiver_id`='$rid' AND `sender_deleted`='0') OR 
				(`receiver_id`='$sid' AND `sender_id`='$rid' AND `receiver_deleted`='0')
				ORDER BY `id` DESC LIMIT 1
		");
		
		if($this->db->scount($sql) > 0) {
			$this->found = true;
			while($res = $sql->fetch_assoc()) {
				$this->msgid = $res["msg_id"];
			}
		} else {
			$this->found = false;
		}
		
		return $this;
	}
	
	public function countUnreadMessages($userid) {
		return "<span style='color:#ff0000;font-weight:bold'>".$this->db->scount($this->db->select("SELECT * FROM `ch_chats` WHERE `receiver_id`='$userid' AND `r_seen`='0' AND receiver_deleted='0'"))." Unread Messages</span>";
	}
	
	public function loadUserMessagesById($msgid,$type=null,$sid=null,$rid=null){
		
		$models = new Models;
		
		$this->db->update("UPDATE `ch_chats` SET `r_seen` = '1', `r_time`='".time()."' WHERE `receiver_id`='".$_SESSION["chCMS_Username"]."' AND `msg_id`='$msgid' AND `r_seen`='0'");
		
		if($sid==null and $rid==null) {
			$sql = $this->db->select("
				SELECT * FROM `ch_chats` WHERE `msg_id`='$msgid' ORDER BY `id` DESC LIMIT 10
			");
		} else if($sid!=null and $rid!=null){
			$sql = $this->db->select("
				SELECT * FROM `ch_chats` WHERE 
					(`sender_id`='$sid' AND `receiver_id`='$rid' AND `sender_deleted`='0') OR
					(`receiver_id`='$sid' AND `sender_id`='$rid' AND `receiver_deleted`='0')
					ORDER BY `id` DESC LIMIT ".MESSAGE_DISPLAY_LIMIT."
			");
		}
		if($this->db->scount($sql) > 0) {
			
			
			$this->found = true;
			if($type != null) {
				while($res = $sql->fetch_assoc()) {
			
					$this->sender = $this->users->getUserDetails($res['sender_id'])->funame;
					$sender_uid = $this->users->getUserDetails($res['sender_id'])->memb_id;
					$last_cid = strip_tags($res["id"]);
					
					if($res['r_seen'] == 0) {
						$status = '<span style="color:#ff0000;font-weight:bolder;">Unread by Party</span>';
					} else {
						$time = date("D d M y, @ H:ia", strftime($res['r_time']));
						$status = '<span style="color:green;font-size:12px;font-weight:normal">Seen on '.$time.'</span>';
					}
					?>
					<li class="comment odd alt thread-odd thread-alt depth-1" id="message_id-<?php print $res['id']; ?>">
						<div class="comment-author">
							<?php
							//get the image of this user
							$image_file = $this->dbmembers->Extract('')->image_id;
							//check if it exists
							if(is_file($image_file) && file_exists($image_file)) {
							?>
							<p class="article-image">
								<img class="article-left" alt="" src="<?php print SITE_URL; ?>/<?php print $this->dbmembers->Extract($res['sender_id'])->image_id; ?>" align="left">
							</p>
							<?php } else { ?>
							<img alt="" src="<?php print SITE_IMAGE_PATH; ?>/avatar.png" itemprop="image" class="avatar avatar-36 photo" height="36" width="36">
							<?php } ?>
 							<cite><?php print $this->sender; ?>: 
							<span style="color:green;font-weight:normal;">
							<em><?php print "(".strip_tags($this->enc->decrypt($res['subject'])).")"; ?></em></span>
							
							<a style="float:right;" href='javascript:deleteMessage("<?php print $res['id']; ?>","Are you sure  you want to delete this message?")' class='btn btn-danger'>
							<i class='fa fa-trash-o fa-fw'></i></a>
							
							</cite><br>
							<small class="comment-time">
								<strong>
									<?php print $models->RelativeTimeCommented($res['time']); ?>
								</strong> 
								<?php print $status; ?>
								
								</small>
						</div>
						<div class="commententry">		
							<p><?php print $this->addlinks(nl2br(strip_tags($this->enc->decrypt($res['message'])))); ?></p>
						</div>
						
						
						<div  id="loadplace<?php print strip_tags($res["id"]); ?>"></div>
						<div id="flash<?php print strip_tags($res["id"]); ?>" class='flash_load'></div>      
					</li>
					<?php 
					
				}
				print "<input type=\"hidden\" id=\"_displayed_message_id\" value=\"$last_cid\"/>";
				print "<input type=\"hidden\" id=\"_message_id\" value=\"$msgid\"/>";
				print "<input type=\"hidden\" id=\"_sid_id\" value=\"$sid\"/>";
				print "<input type=\"hidden\" id=\"_rid_id\" value=\"$rid\"/>";
			} else {
				$res = $sql->fetch_assoc();
				if($res['sender_id'] == $_SESSION["chCMS_Username"])
					$this->receiver = $this->users->getUserDetails($res['receiver_id'])->funame;
				elseif($res['receiver_id'] == $_SESSION["chCMS_Username"])
					$this->receiver = $this->users->getUserDetails($res['sender_id'])->funame;
			}
		} else {
			$this->found = false;
		}
		
		return $this;
	}
	
	public function confirmUsers($sid, $rid) {
		$sql = $this->db->select("
				SELECT * FROM `ch_chats` WHERE 
					(`sender_id`='$sid' AND `receiver_id`='$rid' AND `sender_deleted`='0') OR
					(`receiver_id`='$sid' AND `sender_id`='$rid' AND `receiver_deleted`='0')
					ORDER BY `id` DESC
			");
		if($this->db->scount($sql) >0)
			return true;
		else
			return false;
	}
	
	public function InsertNewMessage($sid, $rid, $sub, $msg) {
		$time=time();
		$model=new Models();
		//check if the users have a unique msg id
		if($this->loadUserMessagesLimit($sid,$rid)->found==true)
			$msgid=$this->loadUserMessagesLimit($sid,$rid)->msgid;// take the same msg id 
		else
			$msgid="MSG".$model->generateRandomMsgPin(); //generate a new message id
		
		if(strlen($sub) < 1)
			$sub = 'No Subject';
		$sub = $this->enc->encrypt($sub);
		$msg = $this->enc->encrypt($msg);
		//insert the data
		$ins = $this->db->insert("
			INSERT INTO 
				`ch_chats` (`msg_id`,`sender_id`,`receiver_id`,`subject`,`message`,`time`,`mod_date`,`mod_time`)
			VALUES
				('$msgid','$sid','$rid','$sub','$msg','$time',now(),'$time')
		");
		//get the new inserted ID
		$insertid = $this->db->getInsertId();
		//put the inserted id into a session
		$_SESSION['getInsertId'] = $insertid;
		if($ins) {
			$this->updateMessageSeen($sid, $rid);
			return true;
		} else
			return false;
	}
	
	public function getUnreadMessages($sid) {
		$sql = $this->db->select("SELECT * FROM `ch_chats` WHERE `receiver_id`='$sid' AND `r_seen`='0' AND `receiver_deleted`='0'");
		if($this->db->scount($sql) == 1) { 
			$row = $sql->fetch_assoc();
			print "<blink><a href='".SITE_URL."/admin/messages/{$row['msg_id']}/{$row['sender_id']}'>
                        <i class=\"fa fa-envelope fa-fw\"></i> New Message
                    </a></blink>";
		} else if($this->db->scount($sql) > 1){
			print "<blink><a href='".SITE_URL."/admin/myprofile/messages/'>
                        <i class=\"fa fa-envelope fa-fw\"></i> New Messages
                    </a></blink>";
		} else {
			print "<blink><a href='".SITE_URL."/admin/myprofile/send-message/'>
                        <i class=\"fa fa-envelope fa-fw\"></i> Send Message
                    </a></blink>";
		}
	}
	
	public function updateMessageSeen($sid, $rid) {
		return $this->db->update("UPDATE `ch_chats` SET `r_seen` = '1', `r_time`='".time()."' WHERE `receiver_id`='$sid' AND `sender_id`='$rid'");
	}
	
	public function addlinks($text = '') {
		
		$text = preg_replace('#(script|about|applet|activex|chrome):#is', "\\1:", $text);
		$ret = ' ' . $text;
		$ret = preg_replace("#(^|[\n ])([\w]+?://[\w\#$%&~/.\-;:=,?@\[\]+]*)#is", "\\1<span class='ccc'><a href=\"\\2\" target=\"_blank\"><font style='font-family: Verdana, Geneva, sans-serif;color: blue;font-size:11px;'>\\2</font></a></span>", $ret);
		
		$ret = preg_replace("#(^|[\n ])((www|ftp)\.[\w\#$%&~/.\-;:=,?@\[\]+]*)#is", "\\1<span class='ccc'><a href=\"http://\\2\" target=\"_blank\"><font style='font-family: Verdana, Geneva, sans-serif;color: blue;font-size:11px;'>\\2</font></a></span>", $ret);
		$ret = preg_replace("#(^|[\n ])([a-z0-9&\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)*[\w]+)#i", "\\1<span class='ccc'><a href=\"mailto:\\2@\\3\"><font style='font-family: Verdana, Geneva, sans-serif;color: blue;font-size:11px;'>\\2@\\3</font></a></span>", $ret);
		$ret = substr($ret, 1);
		
		return $ret;
	}
	 
	public function no_magic_quotes($clean_description) {
		$vpb_data = explode("\\",$clean_description);
		$text = implode("",$vpb_data);
		return $text;
	}

	public function add_n_smilies($text) {
			$convert_text = array(
				':)'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/smilea.png" title="Smile" align="absmiddle">',
				':-)'   =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/smileb.png" title="Smile" align="absmiddle">',
				':D'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/laughc.png" title="Laugh" align="absmiddle">',
				':-D'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/laughc.png" title="Laugh" align="absmiddle">',
				':d'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/laughd.png" title="Laugh" align="absmiddle">',
				';)'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/winke.png" title="Wink" align="absmiddle">',
				';-)'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/winke.png" title="Wink" align="absmiddle">',
				':P'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/toungef.png" title="Tongue" align="absmiddle">',
				':-P'   =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/toungeg.png" title="Tongue" align="absmiddle">',
				':-p'   =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/toungeh.png" title="Tongue" align="absmiddle">',
				':p'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/toungei.png" title="Tongue" align="absmiddle">',
				':('    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/sadj.png" title="Sad" align="absmiddle">',
				':-('    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/sadj.png" title="Sad" align="absmiddle">',
				':o'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/shockk.png" title="Shock" align="absmiddle">',
				':-o'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/shockk.png" title="Shock" align="absmiddle">',
				':O'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/shockL.png" title="Shock" align="absmiddle">',
				':-0'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/shockm.png" title="Shock" align="absmiddle">',
				':|'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/straightn.png" title="Straight" align="absmiddle">',
				'lol'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/smilea.png" title="Smile" align="absmiddle">',
				':-*'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/kiss.png" title="Kiss" align="absmiddle">',
				':*'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/kiss.png" title="Kiss" align="absmiddle">',
				":'("    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/cry.png" title="Cry" align="absmiddle">',
				'<3'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/heart.png" title="Heart" align="absmiddle">',
				'^_^'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/kiki.png" title="Kiki" align="absmiddle">',
				'<(")'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/penguin.gif" title="Penguin" align="absmiddle">',
				'O:)'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/angel.png" title="Angel" align="absmiddle">',
				'O:-)'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/angel.png" title="Angel" align="absmiddle">',
				'(^^^)'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/shark.gif" title="Shark" align="absmiddle">',
				'3:)'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/devil.png" title="Devil" align="absmiddle">',
				'3:-)'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/devil.png" title="Devil" align="absmiddle">',
				':42:'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/42.gif" title="42" align="absmiddle">',
				':putnam:'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/putnam.gif" title="Chris Putnam (Face)" align="absmiddle">',
				':v'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/pacman.png" title="Pacman" align="absmiddle">',
				'o.O'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/confused.png" title="Confused" align="absmiddle">',
				'O.o'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/confused.png" title="Confused" align="absmiddle">',
				':['    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/frown.png" title="Frown" align="absmiddle">',
				'=('    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/frown.png" title="Frown" align="absmiddle">',
				'>:O' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/upset.png" title="Upset" align="absmiddle">',
				'>:-O' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/upset.png" title="Upset" align="absmiddle">',
				'>:o' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/upset.png" title="Upset" align="absmiddle">',
				'>:-o' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/upset.png" title="Upset" align="absmiddle">',
				':3'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/curlylips.png" title="Curlylips" align="absmiddle">',
				'^_^'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/happy.gif" title="Happy" align="absmiddle">',
				'8-|'    =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/cool.gif" title="Cool" align="absmiddle">',
				'8-|' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/sunglasses.png" title="Sunglasses" align="absmiddle">',
				'8|' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/sunglasses.png" title="Sunglasses" align="absmiddle">',
				'B-|' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/sunglasses.png" title="Sunglasses" align="absmiddle">',
				'B|' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/sunglasses.png" title="Sunglasses" align="absmiddle">',
				'>:(' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/grumpy.png" title="Grumpy" align="absmiddle">',
				'>:-(' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/grumpy.png" title="Grumpy" align="absmiddle">',
				//':/' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/unsure.png" title="Unsure" align="absmiddle">',
				':-/' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/unsure.png" title="Unsure" align="absmiddle">',
				'=D' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/grin.gif" title="Grin" align="absmiddle">',
				']' =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/robot.gif" title="Robot" align="absmiddle">',
				':-|'   =>  '<img src="'.SITE_IMAGE_PATH.'/smileys/straighto.png" title="Straight" align="absmiddle">'
				
			   );
			return (strtr($text, $convert_text));

		}
}
?>