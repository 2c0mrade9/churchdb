<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class HometownModel {
	
	public function HometownById($rid,$field,$optional=null) {

		$db = new Database;
		$models = new Models;
		$this->rid = $db->cleanData($rid);

		if($field == "name") {
			$field = "name";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "alias") {
			$field = "slug";
		} else {
			$field = "id";
		}
		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_hometown WHERE $field='{$this->rid}' LIMIT 1") or trigger_error($db->db_error());
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->rname = ucwords($res['name']);
			$this->rid = $res['id'];
			$this->rslug = $res['slug'];
		} else {
			if($optional == "create") {
				if(strlen($this->rid) > 2) {
					$nname = ucwords(str_replace('-', ' ', $this->rid));
					$ins = $db->insert("INSERT INTO adjmeth_hometown 
						(name,slug) values ('{$nname}', '{$this->rid}')");
					$insertid = $db->getInsertId();
					$search = $sql = $db->select("SELECT * FROM adjmeth_hometown WHERE id='{$insertid}'");
					$result  = $search->fetch_assoc();
					$this->rname = $result['name'];
					$this->rid = $insertid;
				} else {
					$this->rname = '';
					$this->rid = '';
				}

			} elseif($optional== "parent") {
				$this->rname = "";
			} else {
				$this->rid = "0";
				$this->rname= "";
			}
		}


		return $this;
	}
	
}
?>
