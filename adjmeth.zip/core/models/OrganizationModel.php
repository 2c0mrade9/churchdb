<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class OrganizationModel {
	
	public function OrganizationById($gid,$field,$optional=null) {

		$db = new Database;
		$models = new Models;
		$ministry = new MinistryModel;
		
		$this->gid = $db->cleanData($gid);

		if($field == "name") {
			$field = "name";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "alias") {
			$field = "slug";
		} else {
			$field = "id";
		}
		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_groups WHERE $field='{$this->gid}' and status='1' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->gname = ucwords($res['name']);
			$this->gid = $res['id'];
			$this->gslug = $res['slug'];
			$this->gdesc = $res['description'];
			$this->gabbrev = $res['abbrev'];
			$this->gparent = $res['parent'];
			$this->gmi = $res['ministry'];
			$this->gparentopt = $this->OrganizationParent($this->gparent)->option;
			$this->gmin = $ministry->MinistryById($this->gmi, "id", null)->mname;
		} else {
			if($optional == "create") {
				if(strlen($this->gid) > 3) {
					$nname = ucwords(str_replace('-', ' ', $this->gid));
					$ins = $db->insert("INSERT INTO adjmeth_groups 
						(name,slug) values ('{$nname}', '{$this->gid}')");
					$insertid = $db->getInsertId();
					$search = $sql = $db->select("SELECT * FROM adjmeth_groups WHERE id='{$insertid}'");
					$result  = $search->fetch_assoc();
					$this->gid = $insertid;
				} else {
					$this->gid = '0';
				}

			} elseif($optional== "parent") {
				$this->gname = "";
				$this->gid = "0";
			} else {
				$this->gid = "0";
				$this->gname = "";
			}
		}


		return $this;
	}


	public function OrganizationParent($catid) {
		$db = new Database;
		$models = new Models;

		$this->catid = $db->cleanData($catid);

		$sql = $db->select("SELECT * FROM adjmeth_groups WHERE `id`='{$this->catid}' and status='1' LIMIT 1");

		if($db->scount($sql) == 1) {
			$this->cfound = true;
			
			$res = $sql->fetch_assoc();
			$this->option = "<option selected='selected' value='{$res['id']}'>{$res['name']}</option>";
		} else {
			$this->cfound = true;
			$this->option = '';
		}
		return $this;
	}

	
	
}
?>
