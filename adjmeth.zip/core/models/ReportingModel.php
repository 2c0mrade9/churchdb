<?php
// determine if the database connection configuration is available
// if not, include the connection information
//if(!defined("DB_HOST")) { include '../index.php'; die(); }


/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */

class ReportingModel extends Models {

	public $display_submenu;
	public $data = NULL;
	public $found = false;

	public function ListReports($limit,$where_clause=null) {
		$db = new Database();
		$users = new UserModel;
		
		$enc = new Encryption('reQuestsCrypting.');
		
		$sql = $db->select("SELECT * FROM `".REPORT_TABLE."` WHERE $where_clause  $limit");
		
		if($db->scount($sql) > 0) {			
			while($res = $sql->fetch_assoc()) {
				$stat = $res["seen_status"];
				if($stat==0)
					$stat='<span style="color:red">Unseen</span>';
				else
					$stat='<span style="color:green">Seen</span>';
				
				if(isset($_SESSION['chUser_Role']) and $_SESSION['chUser_Role'] == 1 || $_SESSION['chUser_Role'] == 4)
					$txt = "Edit";
				else
					$txt = "View";
					

				$display = "<tr class='gradeU'  id='report_id_{$res['id']}'>";
				$display .= "<td>{$res['id']}</td>";
				$display .= "<td>".$users->getUserDetails($res['sent_by'])->ulinked."</td>";
				$display .= "<td>".$enc->decrypt($res['subject'])."</td>";
				$display .= "<td>".date("D dS M Y", strtotime($res['sent_date']))."</td>";
				$display .= "<td>{$stat}</td>";
				$display .= "<td>";
				$display .= "<a class='btn btn-success' href='".SITE_URL."/admin/reporting-edit/{$res['repid']}?edit'><i class='fa fa-edit fa-fw'></i>$txt</a> ";
				if($_SESSION['chUser_Role'] == 1 || $_SESSION['chUser_Role'] == 4) {
					$display .= "<a href='javascript:deleteReport(\"{$res['id']}\",\"Are you sure you want to delete this reportage?\");' class='btn btn-danger'>";
					$display .= "<i class='fa fa-trash-o fa-fw'></i>Delete</a>";
				}
				$display .= "</td>";
				$display .= "</tr>";

				print $display;
			}
		}
	}
	
	public function ReportById($rid,$super=null) {
		$db = new Database;
		$orgn=new OrganizationModel;
		$finance = new FinancialModel;

		$this->found = false;
		if($super==null)
			$type='original';
		else
			$type="photocopy";
		
		$sql = $db->select("SELECT * FROM `".REPORT_TABLE."` WHERE `repid`='$rid' LIMIT 1");
		
		if($db->scount($sql) == 1) {
			
			$res = $sql->fetch_assoc();
			$this->found = true;
			
			$this->rid = $res['repid'];
			$this->r_suject = $res['subject'];
			$this->url = $res['url'];
			$this->comment = $res['comments'];
			$this->sentby = $res['sent_by'];
			$this->rpage = $res['page'];
			$this->seen_status = $res['seen_status'];
			$this->sent_date = $res['sent_date'];
			$this->seen_date = $res['seen_date'];
			$this->deleted = $res['deleted'];
		} else {
			$this->found = false;
		}
		
		return $this;

	}
	
	
	public function DeleteRequest($id){
		$delete = new DeleteModel;
		if($delete->Delete("".REPORT_TABLE."","`rid`='$id'")) {
			return true;
		} else {
			return false;
		}
	}
	
	
}