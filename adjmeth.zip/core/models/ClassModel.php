<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class ClassModel {
	
	public function ClassById($cid,$field,$optional=null) {

		$db = new Database;
		$models = new Models;
		$member = new MemberModel;
		
		$this->cid = $db->cleanData($cid);

		if($field == "name") {
			$field = "name";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "alias") {
			$field = "slug";
		} else {
			$field = "id";
		}
		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_class WHERE $field='{$this->cid}' and status='1' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->cname = ucwords($res['name']);
			$this->cid = $res['id'];
			$this->cslug = $res['slug'];
			$this->cleader = $res["class_leader"];
			$this->acleader = $res["class_leader_assist"];
			$this->csecretary = $res["class_secretary"];
		} else {
			if($optional == "create") {
				if(strlen($this->cid) > 2) {
					$nname = ucwords(str_replace('-', ' ', $this->cid));
					$ins = $db->insert("INSERT INTO adjmeth_class 
						(name,slug) values ('{$nname}', '{$this->cid}')");
					$insertid = $db->getInsertId();
					$search = $sql = $db->select("SELECT * FROM adjmeth_class WHERE id='{$insertid}'");
					$result  = $search->fetch_assoc();
					$this->cid = $insertid;
				} else {
					$this->cid = '';
				}

			}elseif($optional== "parent") {
				$this->cname = "";
			} else {
				$this->cid = "0";
				$this->cname = "";
			}
		}


		return $this;
	}
	
}
?>
