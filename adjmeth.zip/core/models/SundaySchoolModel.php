<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
    return;
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
 
class SundaySchoolModel {
	
	public function SchoolById($gid,$field,$optional=null) {

		$db = new Database;
		$models = new Models;

		$this->gid = $db->cleanData($gid);

		if($field == "name") {
			$field = "name";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "alias") {
			$field = "slug";
		} else {
			$field = "id";
		}
		$this->found = false;

		$sql = $db->select("SELECT * FROM adjmeth_sunday_school_schools WHERE $field='{$this->gid}' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$res = $sql->fetch_assoc();
			$this->sname = ucwords($res['name']);
			$this->sid = $res['id'];
			$this->sslug = $res['slug'];
		} else {
			if($optional == "create") {
				if(strlen($this->gid) > 2) {
					$nname = ucwords(str_replace('-', ' ', $this->gid));
					$ins = $db->insert("INSERT INTO adjmeth_sunday_school_schools 
						(name,slug) values ('{$nname}', '{$this->gid}')");
					$insertid = $db->getInsertId();
					$search = $sql = $db->select("SELECT * FROM adjmeth_sunday_school_schools WHERE id='{$insertid}'");
					$result  = $search->fetch_assoc();
					$this->gid = $insertid;
					$this->sname = $result["name"];
				} else {
					$this->gid = '0';
				}

			} elseif($optional== "parent") {
				$this->gname = "";
				$this->gid = "0";
			} else {
				$this->gid = "0";
				$this->gname = "";
			}
		}


		return $this;
	}
	
	public function MemberById($memberid,$field) {
		
		$db = new Database;
		$models = new Models;

		$this->gid = $db->cleanData($memberid);

		if($field == "full") {
			$field = "fullname";
		} elseif($field == "id") {
			$field = "id";
		} elseif($field == "alias") {
			$field = "studentid";
		} else {
			$field = "id";
		}
		$this->found = false;
		
		$sql = $db->select("SELECT * FROM adjmeth_sunday_school_members WHERE $field='{$this->gid}' LIMIT 1");
		if($db->scount($sql) == 1) {
			$this->found = true;
			$result = $sql->fetch_assoc();
			
			$this->surname=$result["surname"];
			$this->firstname=$result["firstname"];
			$this->lastname=$result["surname"];
			$this->fullname=$this->lastname. " ". $this->firstname;
			$this->dob=$result["dob"];
			$this->day_born=$result["day_born"];
			$this->month_born=$result["month_born"];
			$this->year_born=$result["year_born"];
			$this->gender=$result["gender"];
			$this->m_class=$result["m_class"];
			$this->date_join=$result["date_join"];
			$this->phone=$result["phone"];
			$this->hometown=$result["hometown"];
			$this->schoollocation=$result["schoollocation"];
			$this->region=$result["region"];
			$this->remarks=$result["remarks"];
			$this->schclass=$result["schclass"];
			$this->edulevel=$result["edulevel"];
			$this->address=$result["address"];
			$this->c_parent=$result["parent"];
			$this->c_parent_id=$result["parent_id"];
			$this->pcontact=$result["pcontact"];
			$this->presidence=$result["presidence"];
			$this->paddress=$result["paddress"];
			$this->school=$result["school"];
			$this->residence=$result["residence"];
			
		} else {
			$this->found = false;
		}
		
		return $this;
	}
	
}
?>
