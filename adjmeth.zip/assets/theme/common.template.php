<?php
//Include the various contant files inside the website
require 'core/constants.php';
//require 'core/checkaccess';
//automatically load all the models and classes
//that is needed in the website
function __autoload($class) {
	include("core/models/" . ($class) . ".php");
}
//@params pageTitle
//@params pageDescription
function template_header($pageTitle = '', $pageDescription) {
	//create a new object of the Options Class
	$site = new Options();
	global $ACTION;
	$list = array(
			"print_members",
			"print_class",
			"print_organization",
			"print_product",
			"print"
		);
	
	$finance_list = array(
			'finance','add_harvests',
			'view_tithes','add_harvests_pledges',
			'view_collection','add_pledge',
			'view_harvests','view_pledges',
			'view_thanksgiving','view_harvest',
			'view_welfare','redeem_pledge',
			'add_welfare','update_pledges',
			'update_welfare','update_harvests'
		);
	
?>
<!DOCTYPE html>

<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<?php print $pageDescription; ?>">
	<?php
		echo '<title> '.( empty($pageTitle) ? '' : $pageTitle . ' | ').''.$site->getSiteName().'</title>';
	?>
	
	<link rel="stylesheet" href="<?php print SITE_CSS_PATH; ?>/style.css">
	<link rel="stylesheet" href="<?php print SITE_CSS_PATH; ?>/paginate.css">
	<link rel="stylesheet" href="<?php print SITE_CSS_PATH; ?>/cmxform.css">
	<link rel="stylesheet" href="js<?php print SITE_JS_PATH; ?>/lib/validationEngine.jquery.css">
	<!-- Scripts -->
	<script src="<?php print SITE_JS_PATH; ?>/lib/jquery.min.js" type="text/javascript"></script>
	<script src="<?php print SITE_JS_PATH; ?>/lib/jquery.validate.min.js" type="text/javascript"></script>
	<?php if(isset($_SESSION['theKwintAdminLoggedIn'])) { ?>	
	<script src="<?php print SITE_JS_PATH; ?>/script.js"></script>
	<?php } ?>
	<script>
	function logMeOut() {
		window.location.href='login?logout';
	}
	</script>
</head>
<body class="white-bg-login" style="background:url(<?php print SITE_IMAGE_PATH; ?>/loginbg.jpg) repeat scroll #1A2229;">
	<div id="top-bar">
		<div class="page-full-width">
			<!--<a href="#" class="round button dark ic-left-arrow image-left ">See shortcuts</a>-->
		</div> <!-- end full-width -->	
	</div>
	<?php if(!isset($_SESSION['theAdjMethAdminLoggedIn'])) {?>
	<div id="header">
		<div class="page-full-width cf" style="color:#fff">
			<div id="login-intro" class="fl">
				<h1>Login to Dashboard</h1>
				<h5>Enter your credentials below</h5>
			</div> <!-- login-intro -->
			<!-- Change this image to your own company's logo -->
			<!-- The logo will automatically be resized to 39px height. -->
			<a href="<?php print SITE_URL; ?>" id="company-branding" class="fr"
				style="font-size:30px;font-family:courier;font-weight:bolder;color:#fff">
				<?php print SITE_NAME; ?>, <?php print SITE_SOCIETY; ?>
			</a>
		</div> <!-- end full-width -->	
	</div> <!-- end header -->
	<?php } ?>

	<?php if(isset($_SESSION['theAdjMethAdminLoggedIn'])) { ?>
	<!-- TOP BAR -->
	<?php if(!in_array($ACTION[0], $list)) { ?>
	<div id="top-bar">
		
		<div class="page-full-width cf">

			<ul id="nav" class="fl">
	
				<!--<li class="v-sep"><a href="javascript:void(0);" onclick="javascript:window.open('shortcuts.html','myNewWinsr','width=600,height=110,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no,scrollbars=yes');" class="round button dark ic-info image-left">Show Shortcuts</a></li>-->
				<li class="v-sep"><a href="#" class="round button dark menu-user image-left">Logged in as <strong><?php echo $_SESSION['AdjMethUsername'] ?></strong></a>
					<ul>
				
						<li><a href="<?php print SITE_URL; ?>/change_password">Change Password</a></li>
						
						<li><a href="<?php print SITE_URL; ?>/login?logout&reload">Log out</a></li>
					</ul> 
				</li>
				<li><a href="<?php print SITE_URL; ?>/update_details" class="round button dark menu-settings image-left">Update System Details</a></li>
				<li><a href="<?php print SITE_URL; ?>/update_admins" class="round button dark menu-user image-left">Administrators</a></li>
				
			</ul> <!-- end nav -->

					
			<form action="#" method="POST" id="search-form" class="fr">
				<fieldset>
					<a href="<?php print SITE_URL; ?>/login?logout&reload" class="round button dark menu-logoff image-left" style="background-color: #cc0000">Log out</a>
				</fieldset>
				
				
			</form>

		</div> <!-- end full-width -->	
	
	</div> <!-- end top-bar -->
	<?php } ?>
	<!-- HEADER -->
	<?php if(!in_array($ACTION[0], $list)) { ?>
	
	<div id="header-with-tabs" style="background:url(<?php print SITE_IMAGE_PATH; ?>/banner.jpg) no-repeat scroll #1A2229;">
		
		<div class="page-full-width cf">
	
			<ul id="tabs" class="fl">
				<li><a href="<?php print SITE_URL; ?>/dashboard" class="<?php if($ACTION[0]=="" || $ACTION[0]=="dashboard") print 'active-tab'; ?>  dashboard-tab">HOME</a></li>
				<li><a href="<?php print SITE_URL; ?>/view_members" class="<?php if($ACTION[0]=="view_members" || $ACTION[0]=="add_member" || $ACTION[0]=="update_member") print 'active-tab'; ?> supplier-tab">Members</a></li>
				<li><a href="<?php print SITE_URL; ?>/view_organizations" class="<?php if($ACTION[0]=="view_organizations" || $ACTION[0]=="add_organization" || $ACTION[0]=="update_organization") print 'active-tab'; ?> purchase-tab">Organization</a></li>
				<li><a href="<?php print SITE_URL; ?>/view_class" class="<?php if($ACTION[0]=="view_class" || $ACTION[0]=="add_class" || $ACTION[0]=="update_class") print 'active-tab'; ?>  supplier-tab">Class</a></li>
				<li><a href="<?php print SITE_URL; ?>/view_events" class="<?php if($ACTION[0]=="view_events" || $ACTION[0]=="add_event" || $ACTION[0]=="update_event") print 'active-tab'; ?>  sales-tab">Events</a></li>
				<li><a href="<?php print SITE_URL; ?>/view_sunday_school" class="<?php if($ACTION[0]=="add_sunday_school_teacher" || $ACTION[0]=="confirm_teacher" || $ACTION[0]=="view_sunday_school_class" || $ACTION[0]=="view_sunday_school_teachers" || $ACTION[0]=="add_sunday_school_class" || $ACTION[0]=="view_sunday_school" || $ACTION[0]=="add_sunday_school_member" || $ACTION[0]=="update_sunday_school_member") print 'active-tab'; ?>  customers-tab">Sunday School</a></li>
				<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==4 || $_SESSION["Level"]==3) { ?>
				<li><a href="<?php print SITE_URL; ?>/finance" class="<?php if(in_array($ACTION[0], $finance_list)) print 'active-tab'; ?> payment-tab">Finance</a></li>
				<?php } ?>
				<li><a href="<?php print SITE_URL; ?>/calendar" class="<?php if($ACTION[0]=="" || $ACTION[0]=="calendar") print 'active-tab'; ?>  dashboard-tab">Calendar</a></li>
				<li><a href="<?php print SITE_URL; ?>/reports" class="<?php if($ACTION[0]=="reports") print 'active-tab'; ?> report-tab">Reports</a></li>
				<!--<li><a href="<?php print SITE_URL; ?>/view_requests" class="<?php if($ACTION[0]=="update_requests" || $ACTION[0]=="add_requests" || $ACTION[0]=="view_requests") print 'active-tab'; ?> payment-tab">Requests</a></li>-->
				<li><a href="<?php print SITE_URL; ?>/view_product" class="<?php if($ACTION[0]=="view_product") print 'active-tab'; ?>  stock-tab">Assets</a></li>
			</ul> <!-- end tabs -->
			
			<!-- Change this image to your own company's logo -->
			<!-- The logo will automatically be resized to 30px height. -->
			<a href="<?php print SITE_URL; ?>" onclick="return true" id="company-branding" class="fr"
				style="background:#fff;padding:3px;border-radius:5px;
					font-size:35px;font-family:arial;font-weight:bolder">
				<img src="<?php print SITE_IMAGE_PATH; ?>/churchLogo.jpg">
			</a>
			
		</div> <!-- end full-width -->	

	</div> <!-- end header -->
	
	<?php } ?>
<?php } ?>

<?php if(!isset($_SESSION['theAdjMethAdminLoggedIn']) || $ACTION[0]=="login") { ?>
<br clear="both">
<center>
	<a align="center" onclick="return false;" href="<?php print SITE_URL; ?>" id="company-branding"
		style="font-size:40px;font-family:courier;color:#fff;text-transform:uppercase;
		font-weight:bolder;margin-bottom:20px;">
		Church Management System
	</a>
</center>
<br clear="both">
<?php } ?>
	
<div id="content">

    
<?php } ?>
    


<?php function template_footer() { 
	global $ACTION;
?>
</div>

<?php if(!isset($_SESSION['theAdjMethAdminLoggedIn']) || $ACTION[0]=="login") { ?>
	<?php print DEVELOPER; ?>
<?php } ?>

<div id="footer">

</div> <!-- end footer -->
        
       
</body>
</html> 
<?php } ?>

<?php function die404() {
	$site = new Options();
	global $ACTION;
	require('pages/error.php');
} ?>

<?php function pageNotFound() { ?>


<?php } ?>
<?php function notFoundMessage($message,$class="MainZone") { ?>
	<div style="margin-bottom:15px;" align="center">
	<article style="width:65%;" align="center">
		<!-- Post content -->
		<div id="MainContent">
			<div style="font-size:35px;">Page Not Found</div><br clear="all">
			<div style="font-size:20px;"><?php print $message; ?></div>
		</div>	
	</article>
	</div>
<?php } 

function template_sidebar() {
?>
	<li><a href="<?php print SITE_URL; ?>/view_members">Members</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_class">Classes</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_organizations">Organizations</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_events">Events</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_sunday_school">Sunday School</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_product">Assets</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_requests">Requests</a></li>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==4 || $_SESSION["Level"]==3) { ?>
	<li><a href="<?php print SITE_URL; ?>/finance">Financial Panel</a></li>
	<?php } ?>
	<li><a href="<?php print SITE_URL; ?>/reports">Generate Reports</a></li>
<?php } function template_sidebar2() { ?>

	<li><a href="<?php print SITE_URL; ?>/add_Member">Add Member</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_members">View Members</a></li>
	<li><a href="<?php print SITE_URL; ?>/add_organization">Add Organization</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_organizations">View Organizations</a></li>

<?php } function template_sidebar3() { ?>
	
	<li><a href="<?php print SITE_URL; ?>/add_class">Add Class</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_class">View Class</a></li>
	<li><a href="<?php print SITE_URL; ?>/add_Member">Add Member</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_members">View Members</a></li>

<?php } function template_sidebar4() { ?>
	<li><a href="<?php print SITE_URL; ?>/reports">Reporting</a></li>
	<li><a href="<?php print SITE_URL; ?>/reports_members">Membership Reporting</a></li>
	<li><a href="<?php print SITE_URL; ?>/reports_class">Class Reporting</a></li>
	<li><a href="<?php print SITE_URL; ?>/reports_organizations">Organization Reporting</a></li>
	<li><a href="<?php print SITE_URL; ?>/reports_events">Events Reporting</a></li>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==4 || $_SESSION["Level"]==3) { ?>
	<li><a href="<?php print SITE_URL; ?>/reports_finance">Finance Reporting</a></li>
	<?php } ?>
<?php } function template_sidebar5() { ?>
	<li><a href="<?php print SITE_URL; ?>/add_stock">Add Asset</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_product">View Assets</a></li>
	<li><a href="<?php print SITE_URL; ?>/add_category">Add Asset Category</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_category">View Asset Category</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_stock_availability">View Assets Available</a></li>

<?php } function template_sidebar6() { ?>
	<li><a href="<?php print SITE_URL; ?>/add_sunday_school_member">Add Member</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_sunday_school">View Members</a></li>
	<li><a href="<?php print SITE_URL; ?>/confirm_teacher">Add Teacher</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_sunday_school_teachers">View Teachers</a></li>
	<li><a href="<?php print SITE_URL; ?>/add_sunday_school_class">Add Class</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_sunday_school_class">View Classes</a></li>
	
<?php } function template_sidebar7() { ?>
	<li><a href="<?php print SITE_URL; ?>/finance">Finances Panel</a></li>
	<li><a href="<?php print SITE_URL; ?>/finance_thanksgiving">Thanksgiving</a></li>
	<li><a href="<?php print SITE_URL; ?>/finance_tithes">Tithes</a></li>
	<li><a href="<?php print SITE_URL; ?>/finance_collection">Collection</a></li>
	<li><a href="<?php print SITE_URL; ?>/finance_harvest">Harvest</a></li>
	
<?php } function template_sidebar8() { ?>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==4 || $_SESSION["Level"]==3) { ?>
	<li><a href="<?php print SITE_URL; ?>/view_welfare">Welfare</a></li>
	<li><a href="<?php print SITE_URL; ?>/add_welfare">Make Payment</a></li>
	<li><a href="<?php print SITE_URL; ?>/finance">Financial Panel</a></li>
	<?php } ?>
<?php } function template_sidebar9() { ?>
	<li><a href="<?php print SITE_URL; ?>/view_requests">Requests</a></li>
	<li><a href="<?php print SITE_URL; ?>/add_request">Add Request</a></li>
	
<?php } function template_sidebar10() { ?>
	<?php 
	//fetch income generators
	global $db;
	//fetch all
	$ft_db=$db->select("select * from adjmeth_finance_type");
	if($db->scount($ft_db)>0) {
		while($ft_res=$ft_db->fetch_assoc()){
		?>
		<li>
			<a href="<?php print SITE_URL; ?>/view_<?php print $ft_res["slug"]; ?>">
				<?php print $ft_res["name"]; ?>
			</a>
		</li>
		<?php
		}
	}
	?>
	
<?php } function template_sidebar11() { ?>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==4 || $_SESSION["Level"]==3) { ?>
	<li><a href="<?php print SITE_URL; ?>/view_tithes">Tithes</a></li>
	<li><a href="<?php print SITE_URL; ?>/add_tithes">Record Tithe Payment</a></li>
	<li><a href="<?php print SITE_URL; ?>/finance">Financial Panel</a></li>
	<?php } ?>
<?php } function harvest_sidebar() { ?>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==4 || $_SESSION["Level"]==3) { ?>
	<li><a href="<?php print SITE_URL; ?>/finance">FINANCIAL PANEL</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_harvest">All Harvest Records</a></li>
	<li><a href="<?php print SITE_URL; ?>/add_harvests">Add Harvest Record</a></li>
	<li><a href="<?php print SITE_URL; ?>/redeem_pledge">Redeem Harvest Pledges</a></li>
	<?php } ?>
<?php } function pledges_sidebar() { ?>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==4 || $_SESSION["Level"]==3) { ?>
	<li><a href="<?php print SITE_URL; ?>/finance">FINANCIAL PANEL</a></li>
	<li><a href="<?php print SITE_URL; ?>/view_pledges">View Pledges</a></li>
	<li><a href="<?php print SITE_URL; ?>/redeem_pledge">Redeem Pledges</a></li>
	<li><a href="<?php print SITE_URL; ?>/add_pledge">Record new Pledge</a></li>
	<?php } ?>
<?php } ?>
