<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

$db = new Database;
$q = ucwords($_GET["q"]);
$q = $db->cleanData($q);
if (!$q) return;
$row = $db->select("SELECT * FROM adjmeth_members where status='1'");
  while ($res = $row->fetch_assoc()) {
  
  	if (strpos(ucwords($res['fullname']), $q) !== false) {
		echo "".ucwords($res['fullname'])."\n";
	
 }
 }

?>
