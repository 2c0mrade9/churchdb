<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Prepare Report", $pageDescription);
$tbl_count = new CountModel;
?>

<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Quick Links</h3>
	<ul>
		<?php template_sidebar4(); ?>
	</ul>                   
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Report Preparation</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">

	<div style="margin-bottom:15px;" align="left">
	
	<article style="width:99%;">
		<!-- Post content -->
		<div id="MainContent">
			<div style="font-size:35px;">Reporting - Members</div><br clear="all">
			<div style="font-size:18px;font-family:Times New Roman;line-height:25px">
			<input type="submit" style="padding:5px;height:35px;cursor:pointer" onclick="return singleshow();" name="Search" class="my_button round blue  text-upper" value="Single Member">
			<input type="submit" style="padding:5px;height:35px;cursor:pointer" onclick="return multipleshow();" name="Search" class="my_button round blue  text-upper" value="Multiple Members">
			<input type="submit" style="padding:5px;height:35px;cursor:pointer" onclick="return addressshow();" name="Search" class="my_button round blue  text-upper" value="Print Contact Details">
			<input type="submit" style="padding:5px;height:35px;cursor:pointer" onclick="return severalshow();" name="Search" class="my_button round blue  text-upper" value="Print All Members">
			<br style="height:20px"><br>
			<style>
			h3 {font-family:arial;font-size:18px;font-weight:bold;color:green}
			</style>
			<hr>
			<br>
				<div id="single-user">
					<h3>PRINTING SINGLE MEMBER DETAILS</h3>
					Single Member
					<input id="searchtxt" onkeyup="return fetch_members();" name="searchtxt" style="width:300px;padding:5px" type="text" class="round my_text_box" placeholder="Search by Name of Phone Number"> 
					&nbsp;&nbsp;<input name="Search" type="submit" class="my_button round blue   text-upper" style="cursor:pointer" value="Filter">
					<div class="list_members"></div>
					<script>
					function fetch_members() {
						var searchtxt = $("#searchtxt").val();
						if(searchtxt.length > 2) {
							$.ajax({
								type: "POST",  
								url: "<?php print SITE_URL; ?>/z_fetch_members",  
								data: "list_members&search="+searchtxt,
								beforeSend: function() {
									$('.list_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
								},  success: function(response){
									$('.list_members').html(response);
								}
							});
						} else {
							$('.list_members').html("");
						}
					}
					</script>
				</div>
				<div id="multiple-user"><h3>PRINTING MULTIPLE MEMBER DETAILS</h3><strong>Filter By: </strong><hr style="margin-bottom:20px;">
					<select id="mclass" class="round my_text_box" style="padding:5px;width:110px;height:35px">
						<option value="0">Class</option>
						<?php
						$sql = $db->select("SELECT * FROM adjmeth_class WHERE status='1'");
						if($db->scount($sql) > 0) {
						while($res = $sql->fetch_assoc()) { ?>
						<option value="<?php print $res['id']; ?>"><?php print $res['name']; ?></option>
						<?php
							}
						}
						?>
					</select>
					<select id="morg" class="round my_text_box" style="padding:5px;width:170px;height:35px">
						<option value="0">Organization</option>
						<?php
						$sql = $db->select("SELECT * FROM adjmeth_groups WHERE status='1'");
						if($db->scount($sql) > 0) {
						while($res = $sql->fetch_assoc()) { ?>
						<option value="<?php print $res['id']; ?>"><?php print $res['name']; ?></option>
						<?php
							}
						}
						?>
					</select>
					<select id="mday" class="round my_text_box" style="padding:5px;width:100px;height:35px">
						<option value="0">Day Born</option>
						<?php
						$sql = $db->select("SELECT * FROM adjmeth_days");
						if($db->scount($sql) > 0) {
						while($res = $sql->fetch_assoc()) { ?>
						<option value="<?php print $res['name']; ?>"><?php print $res['name']; ?></option>
						<?php
							}
						}
						?>
					</select>
					<select id="mmon" class="round my_text_box" style="padding:5px;width:110px;height:35px">
						<option value="0">Month Born</option>
						<?php
						$sql = $db->select("SELECT * FROM adjmeth_months");
						if($db->scount($sql) > 0) {
						while($res = $sql->fetch_assoc()) { ?>
						<option value="<?php print $res['name']; ?>"><?php print $res['name']; ?></option>
						<?php
							}
						}
						?>
					</select>
					<select id="mgen" class="round my_text_box" style="padding:5px;width:80px;height:35px">
						<option value="0">Gender</option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select>
					<select id="mcol" class="round my_text_box" style="padding:5px;width:130px;height:35px">
						<option value="id">Select Order</option>
						<option value="fullname">Fullname</option>
						<option value="lname">Surname</option>
						<option value="fname">Firstname</option>
						<option value="day_born">Day Born</option>
						<option value="month_born">Month Born</option>
						<option value="year_born">Year Born</option>
					</select>
					<select id="morder" class="round my_text_box" style="padding:5px;width:110px;height:35px">
						<option value="ASC">ASCENDING</option>
						<option value="DESC">DECENDING</option>
					</select>
					<select id="mformat" class="round my_text_box" style="padding:5px;width:90px;height:35px">
						<option value="HTML">HTML</option>
						<option value="PDF">PDF</option>
						<option value="EXCEL">EXCEL</option>
					</select>
					<input style="padding:5px;width:90px;height:35px;cursor:pointer" name="Filter" type="submit" onclick="return fetch_multiple_members();" class="my_button round blue text-upper" value="Filter">
					<div class="list_multiple_members"></div>
					<script>
					function fetch_multiple_members() {
						var c = $("#mclass").val();
						var o = $("#morg").val();
						var f = $("#mformat").val();
						var or = $("#morder").val();
						var co = $("#mcol").val();
						var d = $("#mday").val();
						var m = $("#mmon").val();
						var g = $("#mgen").val();
						
						window.open("<?php print SITE_URL; ?>/print_members?print&c="+c+"&o="+o+"&f="+f+"&or="+or+"&co="+co+"&d="+d+"&m="+m+"&g="+g);
					}
					</script>
				</div>
				<div id="address-user"><h3>PRINTING CONTACT / ADDRESS DETAILS</h3><strong>Filter By: </strong><hr style="margin-bottom:20px;">
					<select id="aclass" class="round my_text_box" style="padding:5px;width:110px;height:35px">
						<option value="0">Class</option>
						<?php
						$sql = $db->select("SELECT * FROM adjmeth_class WHERE status='1'");
						if($db->scount($sql) > 0) {
						while($res = $sql->fetch_assoc()) { ?>
						<option value="<?php print $res['id']; ?>"><?php print $res['name']; ?></option>
						<?php
							}
						}
						?>
					</select>
					<select id="aorg" class="round my_text_box" style="padding:5px;width:170px;height:35px">
						<option value="0">Select Organization</option>
						<?php
						$sql = $db->select("SELECT * FROM adjmeth_groups WHERE status='1'");
						if($db->scount($sql) > 0) {
						while($res = $sql->fetch_assoc()) { ?>
						<option value="<?php print $res['id']; ?>"><?php print $res['name']; ?></option>
						<?php
							}
						}
						?>
					</select>
					<select id="acol" class="round my_text_box" style="padding:5px;width:130px;height:35px">
						<option value="id">Select Order</option>
						<option value="fullname">Fullname</option>
						<option value="lname">Surname</option>
						<option value="fname">Firstname</option>
						<option value="day_born">Day Born</option>
						<option value="month_born">Month Born</option>
						<option value="year_born">Year Born</option>
					</select>
					<select id="aorder" class="round my_text_box" style="padding:5px;width:110px;height:35px">
						<option value="ASC">ASCENDING</option>
						<option value="DESC">DECENDING</option>
					</select>
					<select id="aformat" class="round my_text_box" style="padding:5px;width:90px;height:35px">
						<option value="HTML">HTML</option>
						<option value="PDF">PDF</option>
						<option value="EXCEL">EXCEL</option>
					</select>
					<input style="padding:5px;width:90px;height:35px;cursor:pointer" name="Filter" type="submit" onclick="return fetch_address_user();" class="my_button round blue text-upper" value="Filter">
					<script>
					function fetch_address_user() {
						var c = $("#aclass").val();
						var o = $("#aorg").val();
						var f = $("#aformat").val();
						var or = $("#aorder").val();
						var co = $("#acol").val();
						window.open("<?php print SITE_URL; ?>/print_members?print&address&c="+c+"&o="+o+"&f="+f+"&or="+or+"&co="+co);
					}
					</script>
				</div>
			</div>
		</div>	
		<script>
		$("#single-user").slideUp();
		$("#address-user").slideUp();
		$("#multiple-user").show();
		function singleshow() {$("#address-user").slideUp();$("#multiple-user").slideUp();$("#single-user").toggle(500);$('.list_members').html("");$("#searchtxt").val("");$("#searchtxt").focus();}
		function multipleshow() {$("#single-user").slideUp();$("#address-user").slideUp();$("#multiple-user").toggle(500);$('.list_members').html("");$("#searchtxt").val("");$("#searchtxt").focus();}
		function addressshow() {$("#single-user").slideUp();$("#address-user").toggle();$("#multiple-user").slideUp(500);$('.list_members').html("");$("#searchtxt").val("");$("#searchtxt").focus();}
		
		function severalshow() {
			window.open("<?php print SITE_URL; ?>/print_members?print&");
		}
		</script>
	</article>
	</div>	
</div>
</div>
</div>
</div>
<?php
template_footer();
?>
