<?php
//include the checkaccess file
//include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Calendar", $pageDescription);
$tbl_count = new CountModel;
?>
<script src="<?php print SITE_ASSETS_PATH; ?>/js/fullcalendar.min.js"></script> 

<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Calendar</h3>
	<ul>
		<?php template_sidebar(); ?>
	</ul>                   
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
		
		<div class="content-module-heading cf">
		<h3 class="fl">Calendar</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
		<div class="content-module-main cf">
			
			<div id="calendar" class="span9">
				<?php
				//fetch the months of the year
				$msql=$db->select("select * from adjmeth_months order by id desc");
				//using while loop
				if($db->scount($msql)>0) {
					while($results=$msql->fetch_assoc()) {
						//print "<div class='month-number'>{$results["name"]}</div>";
					}
				}
				//get the previous and next date
				$currentMonth=date("m");
				$currentYear=date("Y");
				//if the month and year is set_
				if(isset($_GET["mon"]) and is_numeric($_GET["mon"]))
					$currentMonth=$_GET["mon"];
				if(isset($_GET["yr"]) and is_numeric($_GET["yr"]))
					$currentYear=$_GET["yr"];
				
				//reset the month
				if($currentMonth==1)
					$currentMonth=13;
				
				$previousMonth=$currentMonth-1;
				$nextMonth=$currentMonth+1;
				
				if($currentMonth==12){
					$currentYear=$currentYear+1;
					$nextMonth=1;
				}
				
				print "<div class='month-number'>
					<a href='?mon=$nextMonth&yr=$currentYear'> >> Next Month</a>
					</div>";
				print "<div class='month-number'>
					<a href='?mon=$previousMonth&yr=$currentYear'><< Previous Month</a>
					</div>";
				
				print "<br clear='both'><br clear='both'>";
				//call the calendar model
				$calendar=new Calendar; 
				/* sample usages */
				echo $calendar->draw_calendar($currentMonth,$currentYear);
				?>
			</div>
		
		</div>
	</div>
	</div>
</div>
<?php
template_footer();
?>
