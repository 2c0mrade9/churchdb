<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();
$sunday_school = new SundaySchoolModel;

template_header("Update Member", $pageDescription);
$tbl_count = new CountModel;

?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		
		$('#dob').jdPicker();
		$('#datejoin').jdPicker();
		
		$("#stuclass").autocomplete("<?php print SITE_URL; ?>/z_fetch_sunday_school_class_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#school").autocomplete("<?php print SITE_URL; ?>/z_fetch_sunday_school_schools", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#parent").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#occupation").autocomplete("<?php print SITE_URL; ?>/z_fetch_occupation_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#residence").autocomplete("<?php print SITE_URL; ?>/z_fetch_residence_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#presidence").autocomplete("<?php print SITE_URL; ?>/z_fetch_residence_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#schoollocation").autocomplete("<?php print SITE_URL; ?>/z_fetch_residence_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#hometown").autocomplete("<?php print SITE_URL; ?>/z_fetch_hometown_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#region").autocomplete("<?php print SITE_URL; ?>/z_fetch_region_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				gender: {
					required: true,
					minlength: 1
				},
				lname: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				fname: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				memberid: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				residence: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				stuclass: {
					required: true,
					minlength: 3,
					maxlength: 200
				}
			},
			messages: {
				gender: {
					required: "Please Select Gender",
					minlength: "Select one option"
				},
				lname: {
					required: "Please Enter Lastname",
					minlength: "Lastname must consist of at least 3 characters"
				},
				fname: {
					required: "Please Enter Firstname",
					minlength: "Firstname must consist of at least 3 characters"
				},
				memberid: {
					required: "Please Enter Member ID"
				},
				residence: {
					required: "Please Enter Place of Residence",
					minlength: "Place of Residence must consist of at least 3 characters"
				},
				stuclass: {
					required: "Please Enter Class",
					minlength: "Place of Class must consist of at least 3 characters"
				}
			}
		});
	});
	function numbersonly(e){
		var unicode=e.charCode ? e.charCode : e.keyCode
		if (unicode!=8 && unicode!=46 && unicode!=37 && unicode!=38 && unicode!=39 && unicode!=40 && unicode!=9) { 
		//if the key isn't the backspace key (which we should allow)
		if (unicode<48||unicode>57)
			return false
		}
	}
</script>


<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>SUNDAY SCHOOL Management</h3>
	<ul>
		<?php template_sidebar6(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Update Member</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf" >
		<?php if(isset($ACTION[1]) and $sunday_school->MemberById($ACTION[1],"alias")->found == true) { ?>

		<?php include_once('core/controllers/update_sunday_school_member.php'); ?>
		<form name="form1" method="post" id="form1" action="">
                  
					<style>
					.form tr td {
						padding:5px!important;
						font-weight:bold;
					}
					</style>
                  <table class="form" border="0" width="100%" cellspacing="10px" cellpadding="5px">
                     <tr>
                      <td colspan="4" align="center">
						<strong style="color:blue"><hr>PERSONAL DETAILS<hr></strong></td>
                    </tr>
					<tr>
                      <td><span class="man">*</span>Member ID:</td>
                      <td><input name="memberid" type="text" readonly id="memberid" maxlength="200"  class="round default-width-input" value="<?php if(isset($_POST['memberid'])) print $memberid; else print $ACTION[1]; ?>" /></td>
                      
					  <td>Gender: </td>
					  <td><select name="gender" required="required" class="round my_text_box" style="padding:5px;width:120px;height:35px;cursor:pointer;">
						<option value="<?php print $sunday_school->MemberById($ACTION[1],"alias")->gender; ?>"><?php print $sunday_school->MemberById($ACTION[1],"alias")->gender; ?></option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select></td>
                      
                    </tr>
                   
					<tr>
                      <td><span class="man">*</span>Lastname:</td>
                      <td><input name="lname" placeholder="ENTER LASTNAME" type="text" id="lname"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->lastname; ?>" /></td>
                       
                      <td><span class="man">*</span>Firstname:</td>
                      <td><input name="fname" placeholder="ENTER FIRSTNAME" type="text" id="fname" maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->firstname; ?>" /></td>
                       
                    </tr>
					 <tr>
                      
                      <td>Date of Birth</td>
                      <td><input name="dob" placeholder="ENTER DATE OF BIRTH" type="text" id="dob"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->dob; ?>" /></td>
						<td>Phone 1:</td>
                      <td><input name="phone1" onkeypress="return numbersonly(event)" placeholder="ENTER PHONE NUMBER 1" type="text" id="phone1"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->phone; ?>" /></td>
                        
					</tr>
					<tr>
                      <td>Class:</td>
                      <td><input name="stuclass" placeholder="ENTER CLASS" type="text" id="stuclass"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->m_class; ?>" /></td>
                        <td valign="top">Date Joining:</td>
                      <td  valign="top"><input name="datejoin" placeholder="ENTER DATE JOINING" type="text" id="datejoin"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->date_join; ?>" /></td>
                      
                    </tr>
					<tr>
                      <td colspan="4" align="center">
					  <strong style="color:blue"><hr>CONTACT DETAILS<hr></strong></td>
                    </tr>
					<tr>
						<td valign="top">Place of Abode:</td>
                      <td  valign="top"><input name="residence" placeholder="ENTER AREA OF RESIDENCE" type="text" id="residence"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->residence; ?>" /></td>
                      <td valign="top">Hometown:</td>
                      <td  valign="top"><input name="hometown" placeholder="ENTER YOUR HOMETOWN" type="text" id="hometown"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->hometown; ?>" /></td>
                      
                    </tr>
					<tr>
						
                     <td valign="top">Region:</td>
                      <td  valign="top"><input name="region" placeholder="ENTER YOUR REGION" type="text" id="region"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->region; ?>" /></td>
                     <td valign="top">Address</td>
                      <td><textarea style="border-radius:3px;width:95%;height:50px;" name="address" id="address"><?php print $sunday_school->MemberById($ACTION[1],"alias")->address; ?></textarea></td>
					 
                     </tr>
					 <tr>
                      <td colspan="4" align="center">
						<strong style="color:blue"><hr>EDUCATIONAL DETAILS<hr></strong></td>
                    </tr>
					 <tr>
						<td>Name of School:</td>
                      <td><input name="school" placeholder="ENTER SCHOOL" type="text" id="school"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->school; ?>" /></td>
                       <td valign="top">Location of School:</td>
                      <td  valign="top"><input name="schoollocation" placeholder="ENTER YOUR SCHOOL LOCATION" type="text" id="schoollocation"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->schoollocation; ?>" /></td>
                   
                     </tr>
					 <tr>
					 <td>Education Level: </td>
					  <td><select name="edulevel" class="round my_text_box" style="padding:5px;width:250px;height:35px;cursor:pointer;">
						<option value="Ghana">Select Level</option>
						<?php
						$edul=$sunday_school->MemberById($ACTION[1],"alias")->edulevel;
						$selected="";
						
						$fetch_edu_level=$db->select("select * from adjmeth_education_level");
						if($db->scount($fetch_edu_level)>0) {
							while($cr=$fetch_edu_level->fetch_assoc()){
								if($cr["name"]==$edul):
								?>
								<option selected='selected' <?php print $selected; ?> value="<?php print $cr["name"]; ?>"><?php print $cr["name"]; ?></option>
								<?php
								else:
								?>
								<option <?php print $selected; ?> value="<?php print $cr["name"]; ?>"><?php print $cr["name"]; ?></option>
								<?php
								endif;
							}
						}
						?>
					</select></td>
					<td valign="top">Class:</td>
                      <td  valign="top"><input name="schclass" placeholder="ENTER YOUR CLASS" type="text" id="schclass"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->schclass; ?>" /></td>
                   </tr>
					 <tr>
                      <td colspan="4" align="center">
						<strong style="color:blue"><hr>GUARDIAN DETAILS<hr></strong></td>
						 
                    </tr>
					<tr>
						<td valign="top">Parent:</td>
                      <td  valign="top"><input name="parent" placeholder="ENTER PARENT NAME" type="text" id="parent"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->c_parent; ?>" /></td>
                      <td valign="top">Contact:</td>
                      <td  valign="top"><input onkeypress="return numbersonly(event)" name="pcontact" placeholder="ENTER PARENT CONTACT NUMBER" type="text" id="pcontact"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->pcontact; ?>" /></td>
                     
					 
					</tr>
					<tr>
						<td valign="top">Parent Residence:</td>
                      <td  valign="top"><input name="presidence" placeholder="ENTER PARENT RESIDENCE" type="text" id="presidence"  maxlength="200"  class="round default-width-input" value="<?php echo $sunday_school->MemberById($ACTION[1],"alias")->presidence; ?>" /></td>
                      <td valign="top">Address</td>
                      <td><textarea style="border-radius:3px;width:95%;height:50px;" name="paddress" id="paddress"><?php print $sunday_school->MemberById($ACTION[1],"alias")->paddress; ?></textarea></td>
					 
					 
					</tr>
					 <tr>
                      <td colspan="4" align="center">
						<strong style="color:blue"><hr>REMARKS<hr></strong></td>
                    </tr>
					<tr>
					
                      <td valign="top">Remarks</td>
                      <td colspan="2"><textarea style="border-radius:3px;width:95%;height:100px;" name="remarks" id="remarks"><?php print $sunday_school->MemberById($ACTION[1],"alias")->remarks; ?></textarea></td>
					  
                    </tr>
					<tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
					  <td>&nbsp;</td>
					  <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
                        <input  class="button round blue image-right text-upper" type="submit" name="Submit" value="Update">
			<td align="right"><input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    </tr>
                  </table>
                </form>
		
		<?php if(isset($_GET['success'])) { ?>
		<script type="text/javascript">
		jConfirm('Member Information Successfully Updated. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
			window.location.href="<?php print SITE_URL; ?>/update_sunday_school_member/<?php print $ACTION[1]; ?>/update_members";
		} else {
			window.location.href="<?php print SITE_URL; ?>/update_sunday_school_member/<?php print $ACTION[1]; ?>/update_members";
		}
		});
		</script>
		<?php } ?>
		
		<?php } else { ?>
		<?php notFoundMessage("The Sunday School Member you are trying to view does not exist on this server. Please contact Website Administrator"); ?>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
