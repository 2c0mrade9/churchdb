<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Add Category", $pageDescription);
?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				name: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				address: {
					minlength: 3,
					maxlength: 500
				}
			},
			messages: {
				name: {
					required: "Please enter a Category Name",
					minlength: "Category Name must consist of at least 3 characters"
				},
				address: {
					minlength: "Category Discription must be at least 3 characters long",
					maxlength: "Category Discription must be at least 3 characters long"
				}
			}
		});
	
	});
	$(".counter").text("150 characters left");
	function remainingText() {		
		var text = $("#address").val();
		var num = text.length;
		var remain = 150 - num;
		$(".counter").text(remain + " characters left");
	}
	</script>
<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Category Management</h3>
	<ul>
		<?php template_sidebar5(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Add Category</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">
	<?php include_once('core/controllers/insert_category.php'); ?>
	<form name="form1" method="post" id="form1" action="">
                  
                  <p><strong>Add New Category </strong></p>
                  <table class="form"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="15%"><span class="man">*</span>Name:</td>
                      <td><input name="name" placeholder="ENTER CATEGORY NAME" type="text" id="name" maxlength="200"  class="round default-width-input" value="<?php echo $name; ?>" /></td>
                       
                    </tr>
			<tr>
                      <td><span class="man">*</span>Parent Category:</td>
                      <td><select name="parent_category" id="parent_category" onchange="return fetch_subcat();" style="padding:5px;width:200px;height:30px;cursor:pointer;">
			<?php print $cparent; ?>
			<option value="0">Select Parent Category</option>			
			<?php
			$sql = $db->select("SELECT * FROM adjmeth_stock_category WHERE category_parent='0' AND status='1'") or trigger_error($db->db_error());
			if($db->scount($sql) > 0) {
			while($res = $sql->fetch_assoc()) { ?>
			<option value="<?php print $res['id']; ?>"><?php print $res['category_name']; ?></option>
			<?php
				}
			}
			?>
			</select>
			</td>
                       
                    </tr>
			<tr>
                      <td><div class="sub_header"></div></td>
                      <td><div class="sub_body"></div></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>Description</td>
                      <td><textarea name="address" id="address" onkeyup="return remainingText();" placeholder="ENTER DESCRIPTION" cols="8" maxlength="150" class="round full-width-textarea"><?php echo $address; ?></textarea><div class="counter"></div></td>
                      
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    
                    
                    <tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
                        <input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Add">
			<td align="right"><input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    </tr>
                  </table>
            </form>
	<script>
	//$("#subcatdiv").hide();
	function fetch_subcat() { 
		var parentid = $("#parent_category").val();
		//$(".sub_header").html('Sub Category:');

		$.ajax({
			type: "POST",
			data: "parent_id="+parentid,
			url: "<?php print SITE_URL; ?>/z_fetch_product_subcat",
			success: function(response) {
				$(".sub_body").html(response);
			}
		});
	}
	</script>
	<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Category Successfully Inserted. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
			window.location.href="<?php print SITE_URL; ?>/add_category";
		} else {
			window.location.href="<?php print SITE_URL; ?>/add_category";
		}
		});
		</script>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
