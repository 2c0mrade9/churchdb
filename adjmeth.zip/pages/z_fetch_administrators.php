<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

include_once 'core/utils/TimeStamp.php';
include_once 'core/utils/SimplePager.php';

//create new ago instance
$db = new Database();
$org = new OrganizationModel;
$display_news_headlines = '';

//check if the form has been sent
if(isset($_POST['list_administrators'])) {
	//check if the current page number has been sent
	if(isset($_POST['cpage']))
		$current_page = $_POST['cpage'];
	else
		$current_page = '1';
	
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$fquery = $db->select("SELECT * FROM `adjmeth_admin` 
			WHERE FullName LIKE '%$search%' AND status='1'");
	}else {
		$fquery = $db->select("SELECT * FROM `adjmeth_admin` WHERE status='1'");
	}
	$counter = $db->scount($fquery);
		
	//This is the number of contents to display on each page
	if(isset($_POST['limit']) and $_POST['limit'] > 0) {
		$rowsPerPage = $db->cleanData($_POST['limit']);
	} else {
		$rowsPerPage = 60;
	}
	
	include_once 'core/utils/PagerController.php';
	
	//query the database based on the category parsed
	//by the administrator and limit the query by 10
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$query = $db->select("SELECT * FROM `adjmeth_admin` 
					WHERE FullName LIKE '%$search%' AND status='1'
				ORDER BY `id` asc LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	} else {
		$query = $db->select("SELECT * FROM `adjmeth_admin` WHERE status='1' ORDER BY `id` asc LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	}
?>
<table style="margin-top:10px">
		<tr>
			<th>ID</th>
			<th>FirstName</th>
			<th>LastName</th>
			<th>Username</th>
			<th>LastAccess</th>
			<th>Edit /Delete</th>
			<th>Select</th>
		</tr>
		<?php
	if($db->scount($query)) {
?>

	
<?php 		
	//using the while loop to display the data
	while($row = $query->fetch_assoc()) {
	
?>

<tr>
   <td> <?php echo $row['id']; ?></td>

   <td><?php echo $row['FirstName']; ?></td>
   <td><?php echo $row['LastName']; ?></td>
	<td><?php echo $row['Username']; ?></td>
	<td><?php print strftime(date("D d M Y, H:i:a", strtotime($row['LastAccess']))); ?></td>
    <td width="10%" align="center">
	<a href="<?php print SITE_URL; ?>/update_admins/mem/<?php echo $row['Username'];?>/"	class="table-actions-button ic-table-edit"></a>
	<?php if($row['Username']==$_SESSION['AdjMethUsername']) { ?>
	<a href="#" onclick="javascript:confirmSubmit(<?php echo $row['id'];?>,'adjmeth_admin','update_admins')" href="" class="table-actions-button ic-table-delete"></a>
	<?php } else { ?>
	<a href="#" onclick="javascript:confirmSubmit(<?php echo $row['id'];?>,'adjmeth_admin','update_admins')" href="" class="table-actions-button ic-table-delete"></a>
	<?php } ?>
	</td>
	<td align="center" width="5%"><input type="checkbox" value="<?php echo $row['id']; ?>" name="checklist[]" id="check_box" /></td>

</tr>

<?php
	}

?>
</table>
<?php
	print '<br clear="all" />';
	print '<div style="color:#ff0000;font-size:15px;"><strong>'.$counter;
	print '</strong> Administrators Found. Showing Page <strong>'.$page.'</strong> of <strong>'.$pager->getTotalPages().'</strong></div>';
	print '<br clear="all" />';
?>
	<br clear="all" />
	<div class="row">
	<div style="" align="left"><?php print $paginate; ?></div>
	<br clear="all" />
	</div>
<?php	} else {
	?>
	<tr><td colspan="5" style="font-size:18px;">No results found</td></tr>
<?php
}

}	
?>
