<?php
$db = new Database;
$model = new Models;
$user = new UserModel;
$member = new MemberModel;
$groups = new OrganizationModel;

if(isset($_GET['check'])) { 
	if(isset($_GET['fname'])) {
		$fname = $_GET['fname'];
		
		$sql = $db->select("SELECT * FROM `adjmeth_members` WHERE `fullname` LIKE '%$fname%' LIMIT 10");
		print '<ul class="nav" id="side-menu">';
		if($db->scount($sql) > 0){
			while($row = $sql->fetch_assoc()){
				print '<li><a class="autolist" href="javascript:confirmed_uname(\''.$row['uniqueid'].'\',\''.ucwords($row['fullname']).'\',\''.ucwords($row['lname']).'\');">'.ucwords($row["fullname"]).'</a></li>';
			}
		}
		print '</ul>';
	}
} else if(isset($_GET['check_admin_user'])) { 
	if(isset($_GET['fname'])) {
		$fname = $_GET['fname'];
		
		$sql = $db->select("SELECT * FROM `adjmeth_members` WHERE `fullname` LIKE '%$fname%' LIMIT 10");
		print '<ul class="nav" id="side-menu">';
		if($db->scount($sql) > 0){
			while($row = $sql->fetch_assoc()){
				print '<li><a class="autolist" href="javascript:confirmed_uname(\''.$row['uniqueid'].'\',\''.ucwords($row['fname']).'\',\''.ucwords($row['lname']).'\');">'.ucwords($row["fullname"]).'</a></li>';
			}
		}
		print '</ul>';
	}
} else if(isset($_GET['record_session'])) { 
	if(isset($_GET['memid'])) {
		$memid = $_GET['memid'];
		
		$_SESSION['newMemID'] = $memid;
	}
} else if(isset($_GET['check_user_contribusions'])) { 
	if(isset($_GET['fname'])) {
		$fname = $_GET['fname'];
		
		$sql = $db->select("SELECT * FROM `adjmeth_members` WHERE `fullname` LIKE '%$fname%' LIMIT 10");
		print '<ul class="nav" id="side-menu">';
		if($db->scount($sql) > 0){
			while($row = $sql->fetch_assoc()){
				print '<li><a class="autolist" href="javascript:confirmed_uname(\''.$row['uniqueid'].'\',\''.ucwords($row['fname']).'\',\''.ucwords($row['lname']).'\',\''.ucwords($row['lname']).'\');">'.ucwords($row["fullname"]).'</a></li>';
			}
		}
		print '</ul>';
	}
} 
?>
<style>
.autosuggestions {
	position:absolute;
	z-index:999999999!important;
	max-width:250px;
	overflow:hidden;
	min-width:250px;
	background:#fff!important;
	border:solid 2px #f4f4f4;
	float:right;
}
.autosuggestions ul li:hover {
	background:#fff!important;
}
</style>