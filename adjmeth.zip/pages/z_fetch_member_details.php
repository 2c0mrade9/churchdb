<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

$models = new Models;
$lname = $models->create_slug($_POST['membername']);

$line = $db->select("SELECT * FROM adjmeth_members  WHERE lname='$lname'");
$result=$line->fetch_assoc();
$lname=$result["lname"];
$fname=$result["fname"];
$phone=$result["phone"];


if($line!=NULL) {
	$arr = array ("lname"=>"$lname","fname"=>"$fname","phone"=>"$phone");
	echo json_encode($arr);
} else {
	$arr1 = array ("no"=>"no");
	echo json_encode($arr1);
}
?>