<?php
/********************************************************************************
* This script is written by Emmaneul Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//create new ago instance
$db = new Database;

//display the latest article based on its categories
if(isset($_POST['subcat_id'])) {
	$pid = $db->cleanData($_POST['subcat_id']);
	$sql = $db->select("SELECT * FROM `adjmeth_stock_category` WHERE `category_sparent`='$pid' AND `status`='1'");
	if($db->scount($sql) > 0) { 
?>	
	
	<select class="form-control" style="padding:5px;width:200px;height:30px;cursor:pointer;" name="subsubcat" id="subsubcat">
	<option value="0">Select Sub Category</option>
		<?php while($res = $sql->fetch_assoc()) { ?>	
		<option value="<?php print $res['id']; ?>"><?php print $res['category_name']; ?></option>
		<?php } ?>
	</select>
	<?php } ?>
<?php							
}
?>

