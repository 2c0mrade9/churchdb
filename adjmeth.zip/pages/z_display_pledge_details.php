<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";
$addname = "";
$_SESSION["BalanceState"]=NULL;
//include the checkaccess file
if(isset($_POST["display_pledge_details"])) {
	if(isset($_POST["uid"])) {
		//clean name
		$uid=$db->cleanData($_POST["uid"]);
		$type=$db->cleanData($_POST["type"]);
		$eid=$db->cleanData($_POST["sub"]);
		//continue;
		?>
		<table style="margin-top:10px">
		<tr>
			<th>Event Name</th>							
			<th>Amount Pledged</th>
			<th>Amount Paid</th>
			<?php 
			if($_SESSION["BalanceState"]==true)
				print "<th>Overpaid</th>";
			else
				print "<th>Owing</th>";
			?>
		</tr>
		<?php
		if($eid=="0") {
			print "<tr><td colspan='4'>
				There are no pledge records for this member for this event.
			</td></tr>";
		} else {
			//fetch the details
			$pdet=$db->select("select * from 
				adjmeth_finance_pledge where 
				trancid='$eid' and mem_uid='$uid'");
			//harvest names
			$ffsql = $db->select("SELECT * FROM `adjmeth_finance` WHERE `trancid`='$eid'");
			if($db->scount($pdet)==1) {
				$pfres=$ffsql->fetch_assoc();
				//addname
				$addname='';
			}
			//using the while loop
			if($db->scount($pdet)>0) {
				while($pres=$pdet->fetch_assoc()) {
					//check if there was an overdraft
					if($pres["overdraft"]>0)
						$_SESSION["BalanceState"]=true;
					else
						$_SESSION["BalanceState"]=false;
					?>
					<tr>
						<td width="50%"><?php print $pres["event_name"]." ".$addname; ?></td>
						<td align="center"><?php print $pres["amount"]; ?></td>
						<td align="center"><?php print $pres["amount"]-$pres["balance"]+$pres["overdraft"]; ?></td>
						<td align="center">
						<?php
							if(($pres["amount"]-$pres["balance"]+$pres["overdraft"]) > $pres["amount"])
								print $pres["overdraft"];
							else
								print $pres["balance"];
						?>
						</td>
					</tr>
					<?php
				}
			} else {
				print "<tr><td colspan='4'>
					There are no pledge records for this member for this event.
				</td></tr>";
			}
		}
		?>
		</table>
		<?php
	}
}
?>
