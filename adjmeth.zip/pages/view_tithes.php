<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Financial Panel: Tithes", $pageDescription);

?>

<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Tithes Management</h3>
	<ul>
		<?php template_sidebar11(); ?>
	</ul>                   
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Tithes Panel:</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">

	<div style="margin-bottom:15px;" align="center">
	
	<article style="width:65%;">
		<!-- Post content -->
		<div id="MainContent">
			
			<table width="100%" class="table table-striped table-bordered table-hover" id="MembersT">
			<tr>
				<td valign="top" width="30%">
					<div class="form-group">
					<label>Filter By Payee Name</label>
					<br clear="all">
					<input onclick="clearfield_3();" onkeyup="check_user();" value="<?php if(isset($_GET['unqname'])) print $_GET['unqname']; ?>" type="text" placeholder="Enter Name of Payee / Unique ID" class="round default-width-input round my_text_box" id="unqname">
					<input value="" style="width:250px;margin-bottom:10px;" type="hidden" class="form-control" id="query_uid">
					<div style="float:left; width:300px;" align="left">
						<div id="hide_or_show_search_results_box" style="margin-top:0px;float:left; width:350px;background:#F6F6F6; border: 1px solid #E1E1E1;display:none;position: absolute;" align="left"><span style="text-align:left; " id="response_brought"></span></div>
					</div>
					<a href='javascript:return false;' onclick="javascript:filter_unqname();" class='btn btn-success'><i class='fa fa-filter fa-fw'></i>Retrieve</a>
					</div>
				</td>
				<td valign="top" width="30%">
					<div class="form-group">
					<label>Filter By Tithe Month/Year</label>
					<br clear="all">
					
					<select style="max-width:150px" onchange="clearfield_2();" id="dobmonth">
						<option value="null">Select Month</option>
						<option value="null">--------------------------------------</option>
						<?php if(isset($ACTION[2])) { ?>
						<?php
						$sql = $db->select("SELECT * FROM `adjmeth_months_copy` WHERE `mid`='{$ACTION[2]}'");
						while($res=$sql->fetch_assoc()){
							if(strlen($res["id"]) == 1)
								$res["id"] = '0'.$res["id"];
						?>
						<option selected="selected" value="<?php print $res['id']; ?>"><?php print $res['name']; ?></option>
						<option value="null">--------------------------------------</option>
						<?php } ?>
						<?php } ?>
						<?php
						$sql = $db->select("SELECT * FROM `adjmeth_months_copy`");
						while($res=$sql->fetch_assoc()){
							if(strlen($res["id"]) == 1)
								$res["id"] = '0'.$res["id"];
						?>
						<option value="<?php print $res['id']; ?>"><?php print $res['name']; ?></option>
						<?php } ?>
					</select>
					<select  onchange="clearfield_2();" style="max-width:130px" id="dobyear">
						<option value="null">Select Year</option>
						<option value="null">--------------------------------------</option>
						<option <?php if(isset($ACTION[3])) print 'selected="selected"'; ?> value="<?php if(isset($ACTION[3])) print $ACTION[3]; else print  'null'; ?>"><?php if(isset($ACTION[3])) print $ACTION[3]; else print  'Year'; ?></option>
						<option value="null">--------------------------------------</option>
						<?php
						$cyear = date("Y");
						$tmon = 31;
						for($i=$cyear;$i>1900;$i--){
						?>
						<option value="<?php print $i; ?>"><?php print $i; ?></option>
						<?php } ?>
					</select>
					<br clear="all" style="margin-bottom:15px;">
					<a href='javascript:return false;' onclick="javascript:filter_mon_year();" class='btn btn-success'><i class='fa fa-filter fa-fw'></i>Retrieve</a>
					</div>
				</td>
				<td valign="top" width="30%">
					<div class="form-group">
					<label>Filter By Date eg: <em><?php print date("Y-m-d"); ?></em></label>
					<br clear="all">
					<input onclick="clearfield_1();" value="<?php if(isset($_GET['insdate'])) print $_GET['insdate']; ?>" style="width:250px;margin-bottom:10px" type="date" placeholder="Date Format: yyyy-mm-dd" class="round default-width-input round my_text_box" id="insdate">
					<a href='javascript:return false;' onclick="javascript:filter_fulldate();" class='btn btn-success'><i class='fa fa-filter fa-fw'></i>Retrieve</a>
					</div>
				</td>
			</tr>
			
		</table>
			
			
		</div>	
	</article>
	</div>	
</div>
</div>
</div>
</div>
<?php
template_footer();
?>
