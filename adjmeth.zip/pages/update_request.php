<?php
//include the checkaccess file
//include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Update Requests", $pageDescription);
$request = new RequestsModel;
?>

<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Requests Management</h3>
	<ul>
		<?php template_sidebar9(); ?>
	</ul>                   
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
		
		<div class="content-module-heading cf">
		<h3 class="fl">Update Requests</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
		<div class="content-module-main cf">
		<?php if($request->RequestById($ACTION[1])->found == true) { ?>
		
			<form role="form" action="javascript:update();" method="post">
				<div class="col-lg-6">
					<div class="form-group">
						<label>Subject</label>
						<input value="<?php print $request->RequestById($ACTION[2])->suject; ?>" required style="width:350px" class="form-control" id="rsub" type="text">
					</div>
					<div class="form-group">
						<label>Request Name</label>
						<input value="<?php print $request->RequestById($ACTION[2])->name; ?>" required style="width:350px" class="form-control" id="rname" type="text">
					</div>
					<div class="form-group">
						<label>Head of Department</label>
						<input value="<?php print $request->RequestById($ACTION[2])->hod; ?>" required style="width:350px" class="form-control" id="hod" type="text">
					</div>
					<div class="form-group">
						<label>Admin Comments:</label>
						<div style="display:<?php if($_SESSION['chUser_Role'] == 2 || $_SESSION['chUser_Role'] == 1 || $_SESSION['chUser_Role'] == 4) { print "block"; } else { print "none";  } ?>">
							<textarea style="height:130px;" <?php if($_SESSION['chUser_Role'] != 1 and $_SESSION['chUser_Role'] != 4) { ?> readonly <?php } ?> id="comments" name="message" class="form-control" rows="3"><?php print $request->RequestById($ACTION[2])->comments; ?></textarea>
						</div>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">
						<label>Amount Currency</label><br clear="all">
						<select style="max-width:100px" id="rcur">
							<?php print $request->RequestById($ACTION[2])->optcur; ?>
							<?php
							$sql = $db->select("SELECT * FROM `adjmeth_finance_currency`");
							while($res=$sql->fetch_assoc()){
							?>
							<option value="<?php print $res['id']; ?>"><?php print $res['name']; ?></option>
							<?php } ?>
						</select>
					</div>
					<div class="form-group">
						<label>Amount</label>
						<input value="<?php print $request->RequestById($ACTION[2])->amount; ?>" style="width:350px" class="form-control" id="ramt" type="text">
					</div>
					<div class="form-group">
						<label>Department</label><br clear="all">
						<select style="max-width:250px" id="orgs">
							<?php print $request->RequestById($ACTION[2])->hodorg; ?>
							<option value="NULL">Please Select</option>
							<?php
							$sql = $db->select("SELECT * FROM `adjmeth_groups`");
							while($res=$sql->fetch_assoc()){
							?>
							<option value="<?php print $res['name']; ?>"><?php print $res['name']; ?></option>
							<?php } ?>
						</select>
					</div>
					<hr>
					<div class="form-group">
						<label>Request Status</label><br clear="all">
						<select <?php if($_SESSION['chUser_Role'] == 1 || $_SESSION['chUser_Role'] == 4) { print ""; } else { print "disabled='disabled'";  } ?> style="max-width:100px" id="stat">
							<?php print $request->RequestById($ACTION[2])->statusopt; ?>
							<option value="Pending">Pending</option>
							<option value="Approved">Approved</option>
							<option value="Declined">Declined</option>
						</select>
					</div>
				</div>
				<br clear="all">
				
				<hr>
				<div class="form-group">
					<label>Purpose of Request:</label>
					 <textarea style="width:;height:250px;" id="pagecontent" name="message" class="form-control" rows="3">
						<?php print $request->RequestById($ACTION[2])->purpose; ?>
					 </textarea>
				</div>
				
				<?php if($_SESSION['chUser_Role'] == 1 || $_SESSION['chUser_Role'] == 4) { ?>

				<input type="hidden" id="user_id" value="<?php print $_SESSION['chUserID']; ?>">
				<input type="hidden" id="requid" value="<?php print $ACTION[2]; ?>">
				<button type="submit" id="btn-success" class="btn btn-success">Update Record Request</button>
				<button type="reset" id="cancel_update" title="requests" class="btn btn-danger">Cancel</button>
				
				<?php } ?>

			</form>
			
		<?php } ?>
		
		
		</div>
	</div>
	</div>
</div>
<?php
template_footer();
?>
