<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Dashboard", $pageDescription);
$tbl_count = new CountModel;
?>
<div class="page-full-width cf">

	<div class="side-menu fl border">
		<h3>Quick Links</h3>
		<ul>
			<?php template_sidebar(); ?>
		</ul>                           
	</div> <!-- end side-menu -->
	<div class="side-content fr border">	
		<div class="content-module">
			<div class="content-module-heading cf">
				<h3 class="fl">Statistics</h3>
				<span class="fr expand-collapse-text">Click to collapse</span>
				<span class="fr expand-collapse-text initial-expand">Click to expand</span>
			</div> <!-- end content-module-heading -->
			
			<div class="content-module-main cf">
			<table border="0">
			<tr>
				<td valign="top" align="center" style="border-right:solid #ff4000 2px;padding:5px;border-bottom:solid #ff4000 2px;">
					<div style="font-size:35px;">DASHBOARD</div><br clear="all">
					<div style="font-size:18px;font-family:Times New Roman;line-height:25px">
						You are welcomed to the this Church Management System.<br>
						You are free to go through the various options that are available to your disposal 
						in order to insert, view, update and also generate reports that suite your need and requirement.<hr>
						<span style="color:green">
						The Developer of this System has made all things very simple and at the click of a button you will
						be able to carry out whatever be it that the system has been designed to perform.
						<hr>
						As such if any additional functionality is desired, do well to contact the programmer on +233 (0) 554 947764 or 
						<a onclick="return false" href="email:emmallob14@gmail.com">emmallob14@gmail.com</a> so he can help you.
						</span>
					</div>
				</td>
				<td valign="top" width="50%" style="border-right:solid #ff4000 2px;padding:5px;border-bottom:solid #ff4000 2px;">
				<div style="font-size:35px;" align="center">Membership Statistics</div><br clear="all">
				<table border="1" cellpadding="0" cellspacing="0">
					
					<tr>
						<td align="left" class="stats">Total Number of Members</td>
						<td align="left" class="stats"><?php print $tbl_count->TableCount("adjmeth_members", "WHERE status='1'")->table_count; ?>&nbsp;</td>
					</tr>
					<tr>
						<td align="left" class="stats">Total Number of Organizations </td>
						<td align="left" class="stats"><?php echo  $count = $tbl_count->TableCount("adjmeth_groups", "WHERE status='1'")->table_count;?></td>
					</tr>
					<tr>
						<td align="left" class="stats">Total number of Classes </td>
						<td align="left" class="stats"><?php echo $count = $tbl_count->TableCount("adjmeth_class", "WHERE status='1'")->table_count;?></td>
					</tr>
					<tr>
						<td align="left">
							<ul>
								<li class="stats">Total number of Events</li>
								<li class="stats">Total number of Pending Events</li>
								<li class="stats">Total number of Cancelled Events</li>
								<li class="stats">Total number of Past Events</li>
							<ul>
						</td>
						<td valign="top" align="left">
							<ul>
								<li class="stats"><?php echo $count = $tbl_count->TableCount("adjmeth_events", "WHERE status='1'")->table_count;?></li>
								<li class="stats"><?php echo $count = $tbl_count->TableCount("adjmeth_events", "WHERE e_status='Pending' and status='1'")->table_count;?></li>
								<li class="stats"><?php echo $count = $tbl_count->TableCount("adjmeth_events", "WHERE e_status='Cancelled' and status='1'")->table_count;?></li>
								<li class="stats"><?php echo $count = $tbl_count->TableCount("adjmeth_events", "WHERE e_status='Past' and status='1'")->table_count;?></li>
							</ul>
						</td>
					</tr>
				</table>
				</td>
			</tr>
			</table>
			<table style="width:100%; float:left;margin:auto auto;" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td width="250" align="left" style="font-weight:bold;
							font-size:20px;font-family:arial;">UPCOMING EVENTS:</td>
				</tr>
				<tr>
					<td align="left">
						<div class="list_events"></div>
					</td>
				</tr>
			</table>
			
			</div> <!-- end content-module-main -->		
				
		</div> <!-- end content-module -->
		<script>
		list_events();
		function list_events() {
			$.ajax({
				type: "POST",  
				url: "<?php print SITE_URL; ?>/z_fetch_events",  
				data: "dashboard&list_events&cpage=<?php if(isset($_GET['cpage'])) print $_GET['cpage']; else print 0; ?>",
				beforeSend: function() {
					$('.list_events').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
				},  success: function(response){
					$('.list_events').html(response);
				}
			});
		}
		</script>
	</div> <!-- end full-width -->
</div>
<?php
template_footer();
?>
