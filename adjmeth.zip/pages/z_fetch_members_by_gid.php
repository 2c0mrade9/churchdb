<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";
include_once 'core/utils/TimeStamp.php';
include_once 'core/utils/SimplePager.php';

//create new ago instance
$db = new Database();
$org = new OrganizationModel;
$res = new ResidenceModel;
$cla = new ClassModel;
$display_news_headlines = '';

//check if the form has been sent
if(isset($_POST['list_organizations'])) {
	
	if(isset($_POST['gid']) and is_numeric($_POST["gid"])) {
		$gid = $db->cleanData($_POST['gid']);
		$fquery = $db->select("SELECT * FROM `adjmeth_members` 
			WHERE 
				(organization='$gid' OR 
				suborganization='$gid') 
				and type='main' AND
				`status`='1' ORDER BY fullname ASC");
	}else {
		$fquery = "";
	}
	$counter = $db->scount($fquery);
		
	//This is the number of contents to display on each page
	if(isset($_POST['limit']) and $_POST['limit'] > 0) {
		$rowsPerPage = $db->cleanData($_POST['limit']);
	} else {
		$rowsPerPage = 1000;
	}
	
	include_once 'core/utils/PagerController.php';
	
	//query the database based on the category parsed
	//by the administrator and limit the query by 10
	if(isset($_POST['gid']) and is_numeric($_POST["gid"])) {
		$gid = $db->cleanData($_POST['gid']);
		$query = $db->select("SELECT * FROM `adjmeth_members`
					WHERE 
				(organization='$gid' OR 
				suborganization='$gid') 
				and type='main' AND	`status`='1' 
				ORDER BY `fullname` ASC 
				LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	} else {
		$query = "";
	}
?>
		<table style="margin-top:10px">
		<tr>
			<th>Fullname</th>
			<th>Contact</th>							
			<th style="text-align:left!important">Remove</th>
		</tr>
<?php 		
	if($db->scount($query)) {
?>

<?php 		
	//using the while loop to display the data
	while($row = $query->fetch_assoc()) {
			
?>
	<tr>
   <td width="50%">
		<a title="Update member details" href="<?php print SITE_URL; ?>/update_member/<?php echo $row['uniqueid'];?>/view_member">
			<?php echo $row['fullname']; ?>
		</a>
	</td>
    <td> <?php echo $row['phone'];?></td>
    <td width="10%">
	<center>
		<a  title="Remove Member from Group" href="#" onclick="javascript:removeFromGroup('<?php echo $row['id'];?>','<?php print $_POST['gid']; ?>')" class="table-actions-button ic-table-delete"></a>	
	</center>
	</td>
	
</tr>		
<?php
	}

?>
</table>
<?php if(isset($_POST["searchTeacher"])) { ?>
<hr>
<input name="Search" type="submit" onclick="return reload();" class="my_button addnew round blue text-upper" value="not in list?">
<hr>
<script>
function reload(){
	window.location.href="<?php print SITE_URL; ?>/add_member";
}
</script>
<?php } ?>

<?php
	print '<br clear="all" />';
	print '<div style="color:#ff0000;font-size:15px;"><strong>'.$counter;
	print '</strong> Members Found. Showing Page <strong>'.$page.'</strong> of <strong>'.$pager->getTotalPages().'</strong></div>';
	print '<br clear="all" />';
?>
	<br clear="all" />
	<div class="row">
	<div style="" align="left"><?php print $paginate; ?></div>
	<br clear="all" />
	</div>
<?php	} else {
	
	?>
	<tr><td colspan="5" style="font-size:18px;">No results found</td></tr>
	
	<?php
}
?>
</table>
<?php
}	
?>
