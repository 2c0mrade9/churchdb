<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();
$org = new OrganizationModel;

template_header("Update Organization Details", $pageDescription);
?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		$("#ministry").autocomplete("<?php print SITE_URL; ?>/z_fetch_ministry_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				name: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				description: {
					required: true,
					minlength: 3,
					maxlength: 250
				}
			},
			messages: {
				name: {
					required: "Please enter a Organization Name",
					minlength: "Organization Name must consist of at least 3 characters"
				},
				description: {
					required: "Please enter a Organization Description",
					minlength: "Organization Description must be at least 3 characters long",
					maxlength: "Organization Description must be at most 250 characters long"
				}
			}
		});
	
	});
	$(".counter").text("250 characters left");
	function remainingText() {		
		var text = $("#description").val();
		var num = text.length;
		var remain = 250 - num;
		if(remain < 1) {
			rem = "<span style='color:red'>"+(remain*-1)+" characters exceeded</span>";
		} else {
			rem = remain + " characters left";
		}
		$(".counter").html(rem);
	}
	</script>
<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Organization Management</h3>
	<ul>
		<?php template_sidebar2(); ?>
	</ul>                      
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Update Organization Details</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">
		<?php if(isset($ACTION[1]) and $org->OrganizationById($ACTION[1],"alias")->found == true) { ?>

		<?php include_once('core/controllers/update_organization.php'); ?>
		<form name="form1" style="border:solid #000 0px" method="post" id="form1" action="">
            <style>
					.table tr td {
						padding:5px!important;
						font-weight:bold;
					}
					</style>
                  <p><strong>Update Organization Informaton</strong></p>
                  <table class="table" border="0" style="margin:0px">
                    <tr>
						<td width="15%"><span class="man">*</span>Name:</td>
						<td><input name="name" placeholder="ENTER ORGANIZATION NAME" type="text" id="name" maxlength="200"  class="round default-width-input" value="<?php echo $org->OrganizationById($ACTION[1],"alias")->gname; ?>" /></td>
						<td valign="top" style="border-left:solid 1px #000" rowspan="4" valign="top">
							
							<div style="height:100px;">
							<strong>ADD MEMBER TO GROUP</strong>
							<div class="input-group custom-search-form">
								<form action="javascript:searchUser();" method="get">
								   <input style="width:400px;height:30px;font-size:18px;" onkeyup="return searchUser();" name="newmember" placeholder="ENTER MEMBER NAME" type="text" id="newmember"  maxlength="200"  class="round default-width-input" value="" />
									<span class="input-group-btn">
									</span>
								</form>
								<div class="autosuggestions"></div>
							</div>
							</div>
							
							<span style="font-weight:bold;font-size:20px;">
							Group Member List:</span><hr>
							
							<style>
								.list_members{
								max-height:350px!important;
								overflow:scroll;
								overflow-x:none;
							}
							</style>
							<div class="list_members">
								<div class="list_organizations_members"></div>
							</div>
							<script>
							orgs_by_id('<?php echo $org->OrganizationById($ACTION[1],"alias")->gid; ?>');
							function orgs_by_id(gid) {
								$.ajax({
									type: "POST",  
									url: "<?php print SITE_URL; ?>/z_fetch_members_by_gid",  
									data: "list_organizations&gid="+gid,
									beforeSend: function() {
										$('.list_organizations_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
									},  success: function(response){
										$('.list_organizations_members').html(response);
									}
								});
							}
							function removeFromGroup(memid,gid) {
								$.ajax({
									type: "POST",  
									url: "<?php print SITE_URL; ?>/z_process_group_member",  
									data: "removeMember&gid="+gid+"&memid="+memid,
									beforeSend: function() {
										$('.list_organizations_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
									},  success: function(response){
										orgs_by_id(gid);
									}
								});
							}
							function add_member_to_group(memid) {
								var gid = jQuery("#orgid").val();
								$.ajax({
									type: "POST",  
									url: "<?php print SITE_URL; ?>/z_process_group_member",  
									data: "addMember&gid="+gid+"&memid="+memid,
									beforeSend: function() {
										$('.list_organizations_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
									},  success: function(response){
										orgs_by_id(gid);
										$(".autosuggestions").html('');
										$("#newmember").val('');
										$("#newmember").focus();
									}
								});
							}
							function searchUser() {
								var fname = jQuery("#newmember").val();
								if(fname.length > 2) {
									jQuery.ajax({
										type: "POST",
										data: "list_users_by_name&fname="+fname,
										url: "<?php print SITE_URL; ?>/z_process_group_member",
										beforeSend: function() {},
										success: function(response) {
											$(".autosuggestions").html(response);
										}
									});
								} else {
									
								}
							}
							</script>
		
							<hr>
							
						</td>
						
					</tr>
					<tr>
                      <td width="15%">Abbreviation:</td>
                      <td><input name="abbrev" placeholder="ENTER ABBREVIATION" type="text" id="abbrev" maxlength="200"  class="round default-width-input" value="<?php echo $org->OrganizationById($ACTION[1],"alias")->gabbrev; ?>" /></td>
                    </tr>
					<tr>
                      <td>Ministry:</td>
                      <td><input name="ministry" placeholder="ENTER MINISTRY" type="text" id="ministry"  maxlength="200"  class="round default-width-input" value="<?php echo $org->OrganizationById($ACTION[1],"alias")->gmin; ?>" /></td>
                    </tr>
                    <tr valign="top">
                      <td valign="top">Description</td>
                      <td  width="35%"><textarea name="description" id="description" onkeyup="return remainingText();" placeholder="ENTER DESCRIPTION" cols="8" maxlength="265" class="round full-width-textarea"><?php echo $org->OrganizationById($ACTION[1],"alias")->gdesc; ?></textarea>
					  <div class="counter"></div>
					   <br clear="both">
					   <input type="hidden" id="orgid" name="orgid" value="<?php echo $org->OrganizationById($ACTION[1],"alias")->gid; ?>">
						<input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Update">
						<input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    
                    </tr>
                   
                  </table>     
                 
        </form>
		
		<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Organization Successfully Updated. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
			window.location.href="<?php print SITE_URL; ?>/update_organization/<?php print $ACTION[1]; ?>/";
		} else {
			window.location.href="<?php print SITE_URL; ?>/update_organization/<?php print $ACTION[1]; ?>/";
		}
		});
		</script>
		<?php } ?>
		<?php } else { ?>
		<?php notFoundMessage("The Organization you are trying to view does not exist on this server. Please contact Website Administrator"); ?>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
