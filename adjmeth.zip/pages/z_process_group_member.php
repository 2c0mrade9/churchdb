<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

//check if the admin wants to remove user
if(isset($_POST["removeMember"])) {
	//check if the gid and memid was parsed
	if(isset($_POST["memid"]) and isset($_POST["gid"])) {
		//check if both are numeric
		if(is_numeric($_POST["memid"]) and is_numeric($_POST['gid'])) {
			//assign variables
			$memid=$_POST["memid"];
			$gid=$_POST["gid"];
			//update the group information
			$db->update("update adjmeth_members set organization='0'
			where organization='$gid' and id='$memid'");
			//update the sub organization information
			$db->update("update adjmeth_members set suborganization='0'
			where suborganization='$gid' and id='$memid'");
		}
	}
}

if(isset($_POST["addMember"])) {
	//check if the gid and memid was parsed
	if(isset($_POST["memid"]) and isset($_POST["gid"])) {
		//check if both are numeric
		if(is_numeric($_POST["memid"]) and is_numeric($_POST['gid'])) {
			//assign variables
			$memid=$_POST["memid"];
			$gid=$_POST["gid"];
			$gidname="";
			//get the organization name
			$g=$db->select("select id, name from adjmeth_groups where id='$gid'");
			//count
			if($db->scount($g)==1) {
				$result=$g->fetch_assoc();
				$gidname=$result["name"];
			}
			//first check if the user is not joining any group
			$c=$db->select("select id,organization,suborganization from 
			adjmeth_members where id='$memid'");
			//count
			if($db->scount($c)==1) {
				//fetch results
				$results=$c->fetch_assoc();
				$group=$results["organization"];
				$sub=$results["suborganization"];
				//update the member details
				if($group!=0) {
					//update the group information
					$db->update("update adjmeth_members set
					suborganization='$gid',orgsub='$gidname'
					where id='$memid'");
				} else {
					//update the group information
					$db->update("update adjmeth_members set
					organization='$gid',orgname='$gidname'
					where id='$memid'");
				}
			} else {
				//update the group information
				$db->update("update adjmeth_members set
				organization='$gid',orgname='$gidname'
				where id='$memid'");
			}
			
		}
	}
}

//include the checkaccess file
if(isset($_POST["list_users_by_name"])) {
	if(isset($_POST["fname"])) {
		//clean name
		$fname=$db->cleanData($_POST["fname"]);
		
		$sql = $db->select("SELECT * FROM `adjmeth_members` WHERE `fullname` LIKE '%$fname%' LIMIT 10");
		print '<ul class="nav" id="side-menu">';
		if($db->scount($sql) > 0){
			while($row = $sql->fetch_assoc()){
				print '<li><a title="Add member to group" class="autolist" href="javascript:add_member_to_group(\''.$row['id'].'\');">'.ucwords($row["fullname"]).'</a></li>';
			}
		}
		print '</ul>';
	}
}
?>
