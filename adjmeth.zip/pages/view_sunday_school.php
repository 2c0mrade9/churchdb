<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("View Sunday School Members", $pageDescription);
$tbl_count = new CountModel;
?>
 <script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >

<script LANGUAGE="JavaScript">
<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==2) { ?>
<!--
// Nannette Thacker http://www.shiningstar.net
function confirmSubmit(id,table,dreturn) {
	jConfirm('You Want Delete Sunday School Member', 'Confirmation Dialog', function (r) {
       	if(r){ 
               $.ajax({
			type: "POST",  
			url: "<?php print SITE_URL; ?>/z_delete",  
			data: "pid="+id+"&table="+table+"&return="+dreturn,
  			success: function(response) {
    			jAlert('Sunday School Member Is Deleted', '<?php print SITE_NAME; ?>');
				window.location ='<?php print SITE_URL; ?>/view_sunday_school';
  			}
		});
            }
            return r;
        });
}


function confirmDeleteSubmit()
{
   var flag=0;
  var field=document.forms.deletefiles;
for (i = 0; i < field.length; i++){
    if(field[i].checked ==true){
        flag=flag+1;
        
    }
	
}
if (flag <1) {

  jConfirm('You must check one and only one checkbox', '<?php print SITE_NAME; ?>');
return false;
}else{
 jConfirm('You Want Delete Sunday School Members', 'Confirmation Dialog', function (r) {
           if(r){ 
	
document.deletefiles.submit();}
else {
	return false ;
   
}
});
}
}

<?php } ?>

function confirmLimitSubmit()
{
    if(document.getElementById('search_limit').value!=""){

document.limit_go.submit();

    }else{
        return false;
    }
}


function checkAll()
{

	var field=document.forms.deletefiles;
for (i = 0; i < field.length; i++)
	field[i].checked = true ;
}

function uncheckAll()
{
	var field=document.forms.deletefiles;
for (i = 0; i < field.length; i++)
	field[i].checked = false ;
}
// -->
</script>
<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Sunday School Management</h3>
	<ul>
		<?php template_sidebar6(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Sunday School Members</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">
<table style="width:600px" border="0">
<tr><td>
<form action="javascript:fetch_members_search();" method="post" name="search" >
    <input id="searchtxt" name="searchtxt" style="width:300px;" type="text" class="round my_text_box" placeholder="Search by Name of Phone Number"> 
&nbsp;&nbsp;<input name="Search" type="submit" class="my_button round blue   text-upper" value="Search">
</form></td><td>
<!-- <form action="" method="get" name="limit_go">
    Page per Record<input name="limit" type="text" class="round my_text_box" id="search_limit" style="margin-left:5px;" value="<?php if(isset($_GET['limit'])) echo $_GET['limit']; else echo "10"; ?>" size="3" maxlength="3">
    <input name="go"  type="button" value="Go" class=" round blue my_button  text-upper" onclick="return confirmLimitSubmit()">
</form>--></td>
</tr>
</table>

<div style="margin-bottom:15px;" align="right">
	<form name="deletefiles" action="<?php print SITE_URL; ?>/z_delete" method="post">
	<input type="hidden" name="table" value="adjmeth_members">
	<input type="hidden" name="return" value="view_members">
	<input type="button" name="selectall" value="SelectAll" class="my_button round blue   text-upper" onClick="checkAll()"  style="margin-left:5px;"/>
	<input type="button" name="unselectall" value="DeSelectAll" class="my_button round blue   text-upper" onClick="uncheckAll()" style="margin-left:5px;" />
	<input name="dsubmit" type="button" value="Delete Selected" class="my_button round blue   text-upper" style="margin-left:5px;" onclick="return confirmDeleteSubmit()"/>
	<div class="list_members"></div>
	</form>
	<script>
	fetch_members();
	function fetch_members() {
		$.ajax({
			type: "POST",  
			url: "<?php print SITE_URL; ?>/z_fetch_sunday_school",  
			data: "list_members&cpage=<?php if(isset($_GET['cpage'])) print $_GET['cpage']; else print 0; ?>",
			beforeSend: function() {
				$('.list_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
			},  success: function(response){
				$('.list_members').html(response);
			}
		});
	}
	function fetch_members_search() {
		var searchtxt = $("#searchtxt").val();
		if(searchtxt.length>1){
			$.ajax({
				type: "POST",  
				url: "<?php print SITE_URL; ?>/z_fetch_sunday_school",  
				data: "list_members&search="+searchtxt,
				beforeSend: function() {
					$('.list_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
				},  success: function(response){
					$('.list_members').html(response);
				}
			});
		} else {
			$('.list_members').html('<div class="alert alert-danger">Please enter a search term.</div>');
		}
	}

	</script>
</div>	</div></div>
</div></div>
<?php
template_footer();
?>
