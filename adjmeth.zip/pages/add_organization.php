<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Add Organization", $pageDescription);
?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		$("#ministry").autocomplete("<?php print SITE_URL; ?>/z_fetch_ministry_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				name: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				description: {
					required: true,
					minlength: 3,
					maxlength: 250
				}
			},
			messages: {
				name: {
					required: "Please enter a Organization Name",
					minlength: "Organization Name must consist of at least 3 characters"
				},
				description: {
					required: "Please enter a Organization Description",
					minlength: "Organization Description must be at least 3 characters long",
					maxlength: "Organization Description must be at most 250 characters long"
				}
			}
		});
	
	});
	$(".counter").text("250 characters left");
	function remainingText() {		
		var text = $("#description").val();
		var num = text.length;
		var remain = 250 - num;
		if(remain < 1) {
			rem = "<span style='color:red'>"+(remain*-1)+" characters exceeded</span>";
		} else {
			rem = remain + " characters left";
		}
		$(".counter").html(rem);
	}
	</script>
<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Organization Management</h3>
	<ul>
		<?php template_sidebar2(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Add Organization</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">
	<?php include_once('core/controllers/insert_organization.php'); ?>
			<form name="form1" method="post" id="form1" action="">
                  <style>
					.form tr td {
						padding:5px!important;
						font-weight:bold;
					}
					</style>
                  <p><strong>Add New Organization </strong></p>
                  <table class="form"  border="0" style="margin:5px">
                    <tr>
                      <td width="15%"><span class="man">*</span>Name:</td>
                      <td><input name="name" placeholder="ENTER ORGANIZATION NAME" type="text" id="name" maxlength="200"  class="round default-width-input" value="<?php echo $name; ?>" /></td>
                    </tr>
					<tr>
                      <td width="15%">Abbreviation:</td>
                      <td><input name="abbrev" placeholder="ENTER ABBREVIATION" type="text" id="abbrev" maxlength="200"  class="round default-width-input" value="<?php echo $abbrev; ?>" /></td>
                    </tr>
					<tr>
                      <td>Ministry:</td>
                      <td><input name="ministry" placeholder="ENTER MINISTRY" type="text" id="ministry"  maxlength="200"  class="round default-width-input" value="<?php echo $ministry; ?>" /></td>
                    </tr>
                    <tr>
                      <td valign="top">Description</td>
                      <td><textarea name="description" id="description" onkeyup="return remainingText();" placeholder="ENTER DESCRIPTION" cols="8" maxlength="265" class="round full-width-textarea"><?php echo $description; ?></textarea>
					  <div class="counter"></div></td>
                    </tr>
					
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    
                    
                    <tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
                        <input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Add">
			<td align="right"><input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    </tr>
                  </table>
            </form>
	<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Organization Successfully Inserted. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
			window.location.href="<?php print SITE_URL; ?>/add_organization";
		} else {
			window.location.href="<?php print SITE_URL; ?>/add_organization";
		}
		});
		</script>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
