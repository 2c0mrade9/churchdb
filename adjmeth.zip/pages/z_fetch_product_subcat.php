<?php
/********************************************************************************
* This script is written by Emmaneul Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//create new ago instance
$db = new Database;

//display the latest article based on its categories
if(isset($_POST['parent_id'])) {
	$pid = $db->cleanData($_POST['parent_id']);
	$sql = $db->select("SELECT * FROM `adjmeth_stock_category` WHERE `category_parent`='$pid' AND `status`='1'");
	if($db->scount($sql) > 0) { 
?>	
	
	<select class="form-control" style="padding:5px;width:200px;height:30px;cursor:pointer;" name="subcat" id="subcat" onchange="return sub_subcat(this.value);">
	<option value="0">Select Sub Category</option>
		<?php while($res = $sql->fetch_assoc()) { ?>	
		<option value="<?php print $res['id']; ?>"><?php print $res['category_name']; ?></option>
		<?php } ?>
	</select>
	<script>
	//$("#subsubcat").hide();
	function sub_subcat(subcat) { 
		$(".subsub_body").show();
		$.ajax({
			type: "POST",
			data: "subcat_id="+subcat,
			url: "<?php print SITE_URL; ?>/z_fetch_product_subsubcat",
			success: function(response) {
				$(".subsub_body").html(response);
			}
		});
	}
	</script>
	<?php } ?>
<?php							
}
?>

