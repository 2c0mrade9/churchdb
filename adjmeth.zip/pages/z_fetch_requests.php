<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

include_once 'core/utils/TimeStamp.php';
include_once 'core/utils/SimplePager.php';

//create new ago instance
$db = new Database();
$org = new OrganizationModel;
$display_news_headlines = '';

//check if the form has been sent
if(isset($_POST['list_requests'])) {
	//check if the current page number has been sent
	if(isset($_POST['cpage']))
		$current_page = $_POST['cpage'];
	else
		$current_page = '1';
	
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$fquery = $db->select("SELECT * FROM `adjmeth_requests` 
			WHERE name LIKE '%$search%' OR organization LIKE '%$search%' AND deleted='0' order by id");
	}else {
		$fquery = $db->select("SELECT * FROM `adjmeth_requests` WHERE deleted='0' order by id");
	}
	$counter = $db->scount($fquery);
		
	//This is the number of contents to display on each page
	if(isset($_POST['limit']) and $_POST['limit'] > 0) {
		$rowsPerPage = $db->cleanData($_POST['limit']);
	} else {
		$rowsPerPage = LIMIT;
	}
	
	include_once 'core/utils/PagerController.php';
	
	//query the database based on the category parsed
	//by the administrator and limit the query by 10
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$query = $db->select("SELECT * FROM `adjmeth_requests` 
					WHERE name LIKE '%$search%' OR organization LIKE '%$search%' AND deleted='0'
				ORDER BY `id` desc LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	} else {
		$query = $db->select("SELECT * FROM `adjmeth_requests` WHERE deleted='0' ORDER BY `id` desc LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	}
?>
<table style="margin-top:10px">
		<tr>
			<th>No</th>
			<th>Requester Name</th>
			<th>Subject</th>
			<th>Date Requested</th>
			<th>Status</th>
			<th>Action</th>
			<th>Select</th>
		</tr>
		<?php
	if($db->scount($query)) {
?>

	
<?php 		
	//using the while loop to display the data
	while($row = $query->fetch_assoc()) {
		$statcol="";
		
		if($row['status']=="Approved")
			$statcol="#1198a1";
		elseif($row['status']=="Pending")
			$statcol="#f0ad4e";
		else
			$statcol="#d9534f";
?>

<tr>
   <td valign="top"><?php echo $row['id']; ?></td>
   <td valign="top"><?php echo $row['name']; ?></td>
   <td valign="top"><?php echo $row['subject']; ?></td>
    <td align="justify"><?php echo date("l d F Y", strtotime($row['date'])); ?></td>
  <td  valign="top" style='color:<?php print $statcol; ?>'><?php echo $row['status']; ?></td>
   <td width="10%" valign="top" align="center">
   <a href="<?php print SITE_URL; ?>/update_request/<?php echo $row['rid'];?>/view_requests"	class="table-actions-button ic-table-edit"></a>
   <?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==2) { ?>
   <a href="#" onclick="javdescript:confirmSubmit(<?php echo $row['id'];?>,'adjmeth_requests','view_requests')" href="" class="table-actions-button ic-table-delete"></a>
   <?php } ?>
   </td>
   <td align="center" width="5%" valign="top">
   <input type="checkbox" value="<?php echo $row['id']; ?>" name="checklist[]" id="check_box" />
   </td>
   
</tr>

<?php
	}

?>
</table>
<?php if(!isset($_POST['dashboard'])) { ?>
<?php
	print '<br clear="all" />';
	print '<div style="color:#ff0000;font-size:15px;"><strong>'.$counter;
	print '</strong> Requests Found. Showing Page <strong>'.$page.'</strong> of <strong>'.$pager->getTotalPages().'</strong></div>';
	print '<br clear="all" />';
?>
	<br clear="all" />
	<div class="row">
	<div style="" align="left"><?php print $paginate; ?></div>
	<br clear="all" />
	</div>
<?php } ?>
<?php	} else {
	?>
	<tr><td colspan="5" style="font-size:18px;">No results found</td></tr>
<?php
}

}	
?>
