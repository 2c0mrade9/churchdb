<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Stock Available", $pageDescription);
$tbl_count = new CountModel;
?>
 <script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >


<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Stock Management</h3>
	<ul>
		<?php template_sidebar5(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Stock/Product</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">
		<table style="width:600px" border="0">
	<tr><td>
	<form action="javascript:fetch_stock_available_search();" method="post" name="search" >
	    <input id="searchtxt" name="searchtxt" style="width:300px;" type="text" class="round my_text_box" placeholder="Search" > 
	&nbsp;&nbsp;<input name="Search" type="submit" class="my_button round blue   text-upper" value="Search">
	</form></td><td>
	<!-- <form action="" method="get" name="limit_go">
	    Page per Record<input name="limit" type="text" class="round my_text_box" id="search_limit" style="margin-left:5px;" value="<?php if(isset($_GET['limit'])) echo $_GET['limit']; else echo "10"; ?>" size="3" maxlength="3">
	    <input name="go"  type="button" value="Go" class=" round blue my_button  text-upper" onclick="return confirmLimitSubmit()">
	</form>--></td>
	</tr>
	</table>

	<div class="list_stock_available"></div>


	<script>
	fetch_stock_available();
	function fetch_stock_available() {
		$.ajax({
			type: "POST",  
			url: "<?php print SITE_URL; ?>/z_fetch_stock_available",  
			data: "list_stock_available&cpage=<?php if(isset($_GET['cpage'])) print $_GET['cpage']; else print 0; ?>",
			beforeSend: function() {
				$('.list_stock_available').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
			},  success: function(response){
				$('.list_stock_available').html(response);
			}
		});
	}
	function fetch_stock_available_search() {
		var searchtxt = $("#searchtxt").val();
		$.ajax({
			type: "POST",  
			url: "<?php print SITE_URL; ?>/z_fetch_stock_available",  
			data: "list_stock_available&search="+searchtxt,
			beforeSend: function() {
				$('.list_stock_available').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
			},  success: function(response){
				$('.list_stock_available').html(response);
			}
		});
	}
	</script>
</div></div></div></div>
<?php
template_footer();
?>
