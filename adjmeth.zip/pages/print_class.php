<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();
//call the template header function
template_header("Print", $pageDescription);
$tbl_count = new CountModel;
$member = new MemberModel;
$class = new ClassModel;
$org = new OrganizationModel;
?>
<link href="<?php print SITE_CSS_PATH; ?>/print.css" rel="stylesheet">
<link href="<?php print SITE_CSS_PATH; ?>/inilabs.css" rel="stylesheet">

<div>
	<div class="side-content border" style="width:95%;margin:auto auto">			
	<div class="content-module">
		<div class="content-module-heading cf">
		<span class="expand-collapse-text initial-expand">
			<a href="<?php print SITE_URL; ?>">HOME</a>
		</span>	
		<span class="fr expand-collapse-text initial-expand">
			<?php print SITE_NAME; ?> |
			<?php print date("l d M Y"); ?>
		</span>
		</div> <!-- end content-module-heading -->
		<div class="content-module-main cf">
			<h1 align="center" style="font-family:arial;font-size:26px;font-weight:bold;">
				<?php print SITE_NAME; ?></h1>
				<h1 align="center" style="font-family:arial;font-size:26px;font-weight:bold;">
				Accra North Circuit, Adjiringanor Society</h1>
				<h1 align="center" style="font-family:arial;font-size:20px;font-weight:bold;">CLASS DETAILS</h1>
			<?php 
			//initial values
			$query = "";
			$filter = "";
			//call the fetch data info from the database
			if(isset($_GET)) {
				//check if the class was set
				if(isset($_GET['print'])){
					//fetch every single file
					$exp = "/^[a-zA-Z]+$/";
					//set the initial query 
					$query = "select * from adjmeth_class where ";
					//call the status column
					$query .="and status='1' ";
					//call other parameters
					//check if the class was queried
					if(isset($_GET['co']) and preg_match($exp, $_GET['co']) and strlen($_GET['co']) > 3) {
						$query .= "order by {$_GET['co']} ";
						$filter .= "<strong>Order By: </strong>".strtoupper($_GET['co'])." | ";
					} else {
						$query .= "order by id ";
						$filter .= "<strong>Order By: </strong>Surname | ";
					}
					if(isset($_GET['or']) and preg_match($exp, $_GET['or']) and strlen($_GET['or']) > 3) {
						$query .= "{$_GET['or']}";
					} else {
						$query .= "asc";
					}
					//FILTER THE QUERY STRING
					$query = str_replace("where and", "where", $query);	
					//process the query parse
					$sql = $db->select($query);
					?>
					<table style="margin-top:10px">	
					<tr align="left" style="background:#fff;color:#000">
						<th>ID</th>
						<th>Name</th>
						<th>Class Leader</th>
						<th>Assistant Class Leader</th>
						<th>Class Secretary</th>
						<th>Members</th>
					</tr>
					<?php if($db->scount($sql) > 0) { ?>
					<?php 		
						//using the while loop to display the data
						while($row = $sql->fetch_assoc()) {
								
					?>
					<tr align="left">
						<td> <?php echo $row['id']; ?></td>
					   <td><?php echo $row['name']; ?></td>
					   <td><?php echo $member->MemberById($row['class_leader'])->mem_fulln; ?></td>
					   <td><?php echo $member->MemberById($row['class_leader_assist'])->mem_fulln; ?></td>
					   <td><?php echo $member->MemberById($row['class_secretary'])->mem_fulln; ?></td>
					   <td><?php echo $tbl_count->TableCount("adjmeth_members", "WHERE m_class='{$row['id']}'")->table_count;?></td>
					</tr>
					<?php
						}
					?>
					<?php }	?>
					</table>
					
					<?php 
						print '<br clear="all" />';
						print '<div style="color:#ff0000;font-size:15px;"><strong>'.$db->scount($sql);
						print '</strong> Class found for the above filtration</div>';
						print '<br clear="all" />';
					?>
					<?php
				}
			}
			?>
			
			<script>
				//window.print();
				//window.close();
			</script>
			<div style="margin-bottom:15px;" align="center">
			<hr style="margin-top:20px;">
			<div style="margin-top:20px;" align="right">
				<?php print SITE_NAME ." - ". $_SERVER['REQUEST_URI'] ." - ". date("l d M Y, H:ia"); ?>
			</div>
		</div>
		
		</div>
	</div>
	</div>
</div>
<?php
template_footer();
?>
