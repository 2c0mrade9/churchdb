<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

include_once 'core/utils/TimeStamp.php';
include_once 'core/utils/SimplePager.php';

//create new ago instance
$db = new Database;
$org = new OrganizationModel;
$tbl_count = new CountModel;
$display_news_headlines = '';

//check if the form has been sent
if(isset($_POST['list_organizations'])) {
	//check if the current page number has been sent
	if(isset($_POST['cpage']))
		$current_page = $_POST['cpage'];
	else
		$current_page = '1';
	
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$fquery = $db->select("SELECT * FROM `adjmeth_groups` 
			WHERE name LIKE '%$search%' OR description LIKE '%$search%' AND status='1'");
	}else {
		$fquery = $db->select("SELECT * FROM `adjmeth_groups` WHERE status='1'");
	}
	$counter = $db->scount($fquery);
		
	//This is the number of contents to display on each page
	if(isset($_POST['limit']) and $_POST['limit'] > 0) {
		$rowsPerPage = $db->cleanData($_POST['limit']);
	} else {
		$rowsPerPage = LIMIT;
	}
	
	include_once 'core/utils/PagerController.php';
	
	//query the database based on the category parsed
	//by the administrator and limit the query by 10
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$query = $db->select("SELECT * FROM `adjmeth_groups` 
					WHERE name LIKE '%$search%' OR description LIKE '%$search%' AND status='1'
				ORDER BY `id` asc LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	} else {
		$query = $db->select("SELECT * FROM `adjmeth_groups` WHERE status='1' ORDER BY `id` asc LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	}
?>
<table style="margin-top:10px">
		<tr>
			<th>No</th>
			<th>Organization Name</th>
			<th>Description </th>
			<th>Members </th>
			<th>Edit /Delete</th>
			<th>Select</th>
		</tr>
							
		<?php
	if($db->scount($query)) {
?>

	
<?php 		
	//using the while loop to display the data
	while($row = $query->fetch_assoc()) {
	
?>

<tr>
   <td> <?php echo $row['id']; ?></td>

   <td><?php echo $row['name']; ?></td>
   <td><?php echo $row['description']; ?></td>
	<td><?php echo  $tbl_count->TableCount("adjmeth_members", "WHERE organization='{$row["id"]}' or suborganization='{$row["id"]}'")->table_count;?></td>
    <td width="10%" align="center">
	<a href="<?php print SITE_URL; ?>/update_organization/<?php echo $row['slug'];?>/view_organizations" class="table-actions-button ic-table-edit"></a>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==2) { ?>
	<a href="#" onclick="javascript:confirmSubmit(<?php echo $row['id'];?>,'adjmeth_groups','view_organizations')" href="" class="table-actions-button ic-table-delete"></a>
	<?php } ?>
	</td>
	<td align="center" width="5%"><input type="checkbox" value="<?php echo $row['id']; ?>" name="checklist[]" id="check_box" /></td>

</tr>

<?php
	}

?>
</div>
</table>
<?php
	print '<br clear="all" />';
	print '<div style="color:#ff0000;font-size:15px;"><strong>'.$counter;
	print '</strong> Organizations Found. Showing Page <strong>'.$page.'</strong> of <strong>'.$pager->getTotalPages().'</strong></div>';
	print '<br clear="all" />';
?>
	<br clear="all" />
	<div class="row">
	<div style="" align="left"><?php print $paginate; ?></div>
	<br clear="all" />
	</div>
<?php	} else {
	?>
	<tr><td colspan="5" style="font-size:18px;">No results found</td></tr>
<?php
}

}	
?>
