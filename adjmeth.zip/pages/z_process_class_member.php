<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

//check if the admin wants to remove user
if(isset($_POST["removeMember"])) {
	//check if the gid and memid was parsed
	if(isset($_POST["memid"]) and isset($_POST["cid"])) {
		//check if both are numeric
		if(is_numeric($_POST["memid"]) and is_numeric($_POST['cid'])) {
			//assign variables
			$memid=$_POST["memid"];
			$cid=$_POST["cid"];
			//update the class information
			$db->update("update adjmeth_members set m_class='0'
			where id='$memid'");
		}
	}
}

if(isset($_POST["addMember"])) {
	//check if the cid and memid was parsed
	if(isset($_POST["memid"]) and isset($_POST["cid"])) {
		//check if both are numeric
		if(is_numeric($_POST["memid"]) and is_numeric($_POST['cid'])) {
			//assign variables
			$memid=$_POST["memid"];
			$cid=$_POST["cid"];
			//update the member information
			$db->update("update adjmeth_members set
			m_class='$cid' where id='$memid'");
		}
	}
}

//include the checkaccess file
if(isset($_POST["list_users_by_name"])) {
	if(isset($_POST["fname"])) {
		//clean name
		$fname=$db->cleanData($_POST["fname"]);
		
		$sql = $db->select("SELECT * FROM `adjmeth_members` WHERE `fullname` LIKE '%$fname%' LIMIT 10");
		print '<ul class="nav" id="side-menu">';
		if($db->scount($sql) > 0){
			while($row = $sql->fetch_assoc()){
				print '<li><a title="Add member to Class" class="autolist" href="javascript:add_member_to_class(\''.$row['id'].'\');">'.ucwords($row["fullname"]).'</a></li>';
			}
		}
		print '</ul>';
	}
}
?>
