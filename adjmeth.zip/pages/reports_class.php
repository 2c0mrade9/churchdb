<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Prepare Report", $pageDescription);
$tbl_count = new CountModel;
?>

<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Quick Links</h3>
	<ul>
		<?php template_sidebar4(); ?>
	</ul>                   
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Report Preparation</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">

	<div style="margin-bottom:15px;" align="left">
	
	<article style="width:100%;">
		<!-- Post content -->
		<div id="MainContent">
			<div style="font-size:35px;">Reporting - Class</div><br clear="all">
			<br style="height:20px">
			<style>
			h3 {font-family:arial;font-size:18px;font-weight:bold;color:green}
			</style>
			<hr>
			<br>
			<select id="acol" class="round my_text_box" style="padding:5px;width:130px;height:35px">
				<option value="id">Select Order</option>
				<option value="id">ID</option>
				<option value="name">Name</option>
				<option value="slug">Name Slug</option>
				<option value="abbrev">Abbreviation</option>
				<option value="ministry">Ministry</option>
			</select>
			<select id="aorder" class="round my_text_box" style="padding:5px;width:110px;height:35px">
				<option value="ASC">ASCENDING</option>
				<option value="DESC">DECENDING</option>
			</select>
			<select id="aformat" class="round my_text_box" style="padding:5px;width:90px;height:35px">
				<option value="HTML">HTML</option>
				<option value="PDF">PDF</option>
				<option value="EXCEL">EXCEL</option>
			</select>
			<input type="submit" style="padding:5px;height:35px;cursor:pointer" onclick="return severalshow();" name="Search" class="my_button round blue  text-upper" value="Print All Classes">
			<script>
				function severalshow() {
					var f = $("#aformat").val();
					var or = $("#aorder").val();
					var co = $("#acol").val();
					window.open("<?php print SITE_URL; ?>/print_class?print&address&f="+f+"&or="+or+"&co="+co);
				}
			</script>
		</div>	
	</article>
	</div>	
</div>
</div>
</div>
</div>
<?php
template_footer();
?>
