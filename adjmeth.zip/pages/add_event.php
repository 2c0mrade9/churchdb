<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Add Event", $pageDescription);
$tbl_count = new CountModel;

?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		
		$('#start_date').jdPicker();
		$('#end_date').jdPicker();
		
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {

				name: {
					required: true,
					minlength: 7,
					maxlength: 200
				},
				start_date: {
					required: true,
					minlength: 10,
					maxlength: 200
				},
				end_date: {
					required: true,
					minlength: 10,
					maxlength: 200
				},
				details: {
					required: true,
					minlength: 20,
					maxlength: 500
				}
			},
			messages: {
				name: {
					required: "Please Enter Event Name",
				}
			}
		});
	});
	$(".counter").text("500 characters left");
	function remainingText() {		
		var text = $("#details").val();
		var num = text.length;
		var remain = 500 - num;
		if(remain < 1) {
			rem = "<span style='color:red'>"+(remain*-1)+" characters exceeded</span>";
		} else {
			rem = remain + " characters left";
		}
		$(".counter").html(rem);
	}
	function numbersonly(e){
		var unicode=e.charCode ? e.charCode : e.keyCode
		if (unicode!=8 && unicode!=46 && unicode!=37 && unicode!=38 && unicode!=39 && unicode!=40 && unicode!=9) { 
		//if the key isn't the backspace key (which we should allow)
		if (unicode<48||unicode>57)
			return false
		}
	}
</script>


<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Class Management</h3>
	<ul>
		<li><a href="<?php print SITE_URL; ?>/add_event">Add Event</a></li>
		<li><a href="<?php print SITE_URL; ?>/view_events">View Events</a></li>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Add Event</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf" >
		<?php include_once('core/controllers/insert_event.php'); ?>
		<form name="form1" method="post" id="form1" action="">
                  
			<style>
			.form tr td {
				padding:5px!important;
				font-weight:bold;
			}
			</style>
            <table class="form" border="0" width="100%" cellspacing="10px" cellpadding="5px">
				<tr>
                    <td>EVENT NAME:</td>
                    <td colspan="2"><input name="name" style="width:400px" placeholder="ENTER CLASSNAME" type="text" id="name"  maxlength="200"  class="round default-width-input" value="<?php echo $name; ?>" /></td>
                     
					<td>&nbsp;</td>
                       
                </tr>
					
				<tr>
                <td>START DATE:</td>
                      <td><input name="start_date" placeholder="ENTER START DATE" type="text" id="start_date"  maxlength="200"  class="round default-width-input" value="<?php echo $start_date; ?>" /></td>
                       
					  <td>END DATE:</td>
                      <td><input name="end_date" placeholder="ENTER END DATE" type="text" id="end_date"  maxlength="200"  class="round default-width-input" value="<?php echo $end_date; ?>" /></td>
                       
                    </tr>
					<tr>
                <td>START TIME:</td>
                      <td><input placeholder='HH:MM' name="start_time" placeholder="ENTER START TIME" type="text" id="start_date"  maxlength="200"  class="round default-width-input" value="<?php echo $start_time; ?>" /></td>
                       
					  <td>END TIME:</td>
                      <td><input placeholder='HH:MM' name="end_time" placeholder="ENTER END TIME" type="text" id="end_date"  maxlength="200"  class="round default-width-input" value="<?php echo $end_time; ?>" /></td>
                       
                </tr>
				<tr>
					<td></td>
                    <td>eg: <em><?php print date("H:i",strftime(time())); ?></em> - GMT style 5:35pm => 17:35</td>
					<td></td>
					<td>eg: <em><?php print date("H:i",strftime(time())); ?></em> - GMT style 5:35pm => 17:35</td> 
                    </tr>
				<tr>
				<tr>
					<td colspan="4"><hr></td>
				</tr>
				<tr>
				<td class="LabelColumn">Attendance Counts</td>
				<td class="TextColumn" colspan="3">
				 
					  <table>
				  <tr>
					  <td><strong>Total: &nbsp;</strong></td>
					<td>
					<input type="text" name="event_total" value="<?php echo $event_total; ?>" onkeypress="return numbersonly(event)" size="8" maxlength="4" class='form-control'>
					</td>
					</tr>
				  <tr>
					  <td><strong>Members: &nbsp;</strong></td>
					<td>
					<input type="text" onkeypress="return numbersonly(event);" name="event_members" value="<?php echo $event_members; ?>" size="8" maxlength="4" class='form-control'>
					<em></em>
					</td>
					</tr>
				  <tr>
					  <td><strong>Visitors: &nbsp;</strong></td>
					<td>
					<input type="text" name="event_visitors" value="<?php echo $event_visitors; ?>" onkeypress="return numbersonly(event)" maxlength="4" size="8" class='form-control'>
					</td>
					</tr>
					   
					</table>
						</td>
			  </tr>
				<tr>
					<td colspan="4"><hr></td>
				</tr>
					<tr>
                      <td valign="top">DESCRIPTION</td>
                      <td><textarea name="details" id="details" onkeyup="return remainingText();" placeholder="ENTER DETAILS" style="height:200px;width:350px" maxlength="520" class="round full-width-textarea"><?php print $details; ?></textarea>
					  <div class="counter"></div></td>
					  <td valign="top">GROUP:</td>
					  <td valign="top">
						<select name="ministry" id="ministry" class="round my_text_box" style="padding:5px;width:200px;height:35px">
							<?php print $ministry_sel; ?>
							<option value="Entire Church">Entire Church Membership</option>
							<?php
							$sql = $db->select("SELECT * FROM adjmeth_groups");
							if($db->scount($sql) > 0) {
							while($res = $sql->fetch_assoc()) { ?>
							<option value="<?php print $res['name']; ?>"><?php print $res['name']; ?></option>
							<?php
								}
							}
							?>
						</select>
					  </td>
                    </tr>
					
					<tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
					  <td>&nbsp;</td>
					  <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
				<input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Add">
				<td align="right"><input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                </tr>
            </table>
            </form>
		
		<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Event Successfully Inserted. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
				window.location.href="<?php print SITE_URL; ?>/add_event";
			} else {
				window.location.href="<?php print SITE_URL; ?>/add_event";
			}
		});
		</script>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
