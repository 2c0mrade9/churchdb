<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";
//create new ago instance
$db = new Database;
$member =  new MemberModel;
//check if the form has been sent
if(isset($_POST['adjust']) and $_POST["adjust"]=="addTeacher") {
	//check the member id parsed
	$mid=$db->cleanData($_POST['id']);
	//update the member details
	if($db->update("update adjmeth_members set mem_type='teacher' where uniqueid='$mid'")){
		//add up to the teachers table list
		$check=$db->select("select member_id from 
			adjmeth_sunday_school_teachers where member_id='$mid'");
		//count the number of rows
		if($db->scount($check)<1){
				//insert new
				if($db->insert("insert into adjmeth_sunday_school_teachers (member_id)
					values ('$mid')")) {
						print "Teacher successfully added to list.";
					} else {
						print "Sorry! Error adding teacher to list.";
					}
			}elseif($db->scount($check)==1){
				print "Already a part of the Teachers list.";
			}
	} else {
		print "Sorry! Error adding teacher to list.";
	}
}elseif(isset($_POST['adjust']) and $_POST["adjust"]=="removeTeacher") {
	//check the member id parsed
	$mid=$db->cleanData($_POST['id']);
	//update the member details
	if($db->update("update adjmeth_members set mem_type='' where uniqueid='$mid'")){
		//add up to the teachers table list
		$check=$db->select("select member_id from 
			adjmeth_sunday_school_teachers where member_id='$mid'");
		//count the number of rows
		if($db->scount($check)>0){
				//delete new
				if($db->update("delete from adjmeth_sunday_school_teachers where member_id='$mid'")) {
						print "Teacher successfully removed from list.";
					} else {
						print "Sorry! Error removing teacher from list.";
					}
			}elseif($db->scount($check)==1){
				print "Already removed from the Teachers list.";
			}
	} else {
		print "Sorry! Error removing teacher from list.";
	}
}
?>