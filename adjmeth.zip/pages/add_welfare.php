<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Add Welfare Payment", $pageDescription);
$tbl_count = new CountModel;

?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		
		$("#cname").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#paidby").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#cleader").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				cname: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				paidby: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				amount: {
					required: true,
					minlength: 1,
					maxlength: 200
				},
				month: {
					required: true,
					minlength: 1,
					maxlength: 200
				}
			},
			messages: {
				cname: {
					required: "Please Enter Member Name",
					minlength: "Membername must consist of at least 3 characters"
				},
				amount: {
					required: "Please Enter Amount"
				},
				paidby: {
					required: "Please Enter PAYEE Name"
				}
				
			}
		});
	});
	function numbersonly(e){
		var unicode=e.charCode ? e.charCode : e.keyCode
		if (unicode!=8 && unicode!=46 && unicode!=37 && unicode!=38 && unicode!=39 && unicode!=40 && unicode!=9) { 
		//if the key isn't the backspace key (which we should allow)
		if (unicode<48||unicode>57)
			return false
		}
	}
</script>


<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Class Management</h3>
	<ul>
		<?php template_sidebar8(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Add Payment</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf" >
		<?php include_once('core/controllers/insert_welfare.php'); ?>
		<form name="form1" method="post" id="form1" action="">
                  
			<style>
			.form tr td {
				padding:5px!important;
				font-weight:bold;
			}
			</style>
            <table class="form" border="0" width="100%" cellspacing="10px" cellpadding="5px">
				<tr>
                     <td><span class="man">*</span>Member Name:</td>
                     <td><input name="cname" placeholder="ENTER MEMBER NAME" type="text" id="cname"  maxlength="200"  class="round default-width-input" value="<?php echo $cname; ?>" /></td>
					 
                     <td>&nbsp;</td>
                     <td>&nbsp;</td>
                      
                   </tr>
				
				<tr>
                     <td><span class="man">*</span>Amount:</td>
                      <td><input name="amount" onkeypress="return numbersonly(event)" placeholder="ENTER AMOUNT" type="text" id="amount"  maxlength="200"  class="round default-width-input" value="<?php print $amount ?>" /></td>
                       
					  <td>Month:</td>
                      <td>
						  <select required id="month" name="month" class="round my_text_box" style="padding:5px;width:120px;height:35px;cursor:pointer;">
							<option value="Null">Month</option>
							<?php
							$sql=$db->select("SELECT * FROM adjmeth_months");
							if($db->scount($sql) >0) {
								while($result=$sql->fetch_assoc()) {
									print "<option value='{$result["name"]}'>{$result["name"]}</option>";
								}
							}
							?>
						</select>
					  </td>
                    </tr>
					<tr>
                      <td><span class="man">*</span>Paid By:</td>
                      <td><input name="paidby" placeholder="ENTER CLASS PAYEE NAME" type="text" id="paidby"  maxlength="200"  class="round default-width-input" value="<?php echo $payee; ?>" /></td>
                       
					  <td>Year:</td>
                      <td>
						  <select required id="year" name="year" class="round my_text_box" style="padding:5px;width:120px;height:35px;cursor:pointer;">
							<option value="<?php print date("Y"); ?>"><?php print date("Y"); ?></option>
							<option value="<?php print date("Y"); ?>">--------------------------</option>
							<?php
							for($i=date("Y")-3; $i<date("Y")+5;$i++):
								if($i!=date("Y"))
									print "<option value='$i'>$i</option>";
							endfor;
							?>
						</select>
					  </td>
					  
                    </tr>
					
					
					<tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
					  <td>&nbsp;</td>
					  <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
                        <input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Add">
			<td align="right"><input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    </tr>
                  </table>
                </form>
		
		<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Welfare Payment Successfully Inserted. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
				window.location.href="<?php print SITE_URL; ?>/add_welfare";
			} else {
				window.location.href="<?php print SITE_URL; ?>/add_welfare";
			}
		});
		</script>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
