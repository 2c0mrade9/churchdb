<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Add Stock", $pageDescription);
$tbl_count = new CountModel;

?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		$("#supplier").autocomplete("<?php print SITE_URL; ?>/z_fetch_supplier_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				name: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				stockid: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				cost: {
					required: true,
				
				},
				stock_avail: {
					required:true,
				}
			},
			messages: {
				name: {
					required: "Please Enter Stock Name",
					minlength: "Stock Name must consist of at least 3 characters"
				},
				stockid: {
					required: "Please Enter Stock ID"
				},
				cost: {
					required: "Please Enter Cost Price"
				},
				stock_avail: {
					required: "Please Enter Stock Available"
				}
			}
		});
	});
	function numbersonly(e){
		var unicode=e.charCode? e.charCode : e.keyCode
		if (unicode!=8 && unicode!=46 && unicode!=37 && unicode!=38 && unicode!=39 && unicode!=40 && unicode!=9) { 
		//if the key isn't the backspace key (which we should allow)
		if (unicode<48||unicode>57)
			return false
		}
	}
</script>


<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Stock Management</h3>
	<ul>
		<?php template_sidebar5(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Add Stock</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">
		<?php include_once('core/controllers/insert_stock.php'); ?>
		<form name="form1" method="post" id="form1" action="">
                  
                
                  <table class="form"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                    <?php
					$max = $db->maxOfAll("id", "adjmeth_stock");
					$max=$max+rand(1, 9999);
					$autoid="SD".$max."";
					?>
                      <td><span class="man">*</span>Stock ID:</td>
                      <td><input name="stockid" type="text" id="stockid" readonly="readonly" maxlength="200"  class="round default-width-input" value="<?php if(isset($_POST['stockid'])) print $stockid; else print $autoid; ?>" /></td>
                       
                      <td><span class="man">*</span>Name:</td>
                      <td><input name="name"placeholder="ENTER CATEGORY NAME" type="text" id="name" maxlength="200"  class="round default-width-input" value="<?php echo $name; ?>" /></td>
                       
                    </tr>
                    <tr>
                      <td><span class="man">*</span>Cost:</td>
                      <td><input name="cost" placeholder="ENTER COST PRICE" type="text" id="cost"  maxlength="200"  class="round default-width-input" onkeypress="return numbersonly(event)" value="<?php echo $cost; ?>" /></td>
                       
                      
                    </tr>
		    <tr style="margin-top:5px;">
                      <td style="margin:5px;"><span class="man">*</span>Stock Avail:</td>
                      <td><input style="margin-top:5px;" onkeypress="return numbersonly(event)" name="stock_avail" placeholder="ENTER AVAILABLE STOCK" type="text" id="stock_avail"  maxlength="200"  class="round" value="<?php echo $stock_avail; ?>" /></td>
                       
                      <td>Parent Category</td>
                      <td><select name="parent_category" id="parent_category" onchange="return fetch_subcat();" style="padding:5px;width:200px;height:30px;cursor:pointer;">
			<?php print $cparent; ?>
			<option value="0">Select Parent Category</option>			
			<?php
			$sql = $db->select("SELECT * FROM adjmeth_stock_category WHERE category_parent='0' AND status='1'") or trigger_error($db->db_error());
			if($db->scount($sql) > 0) {
			while($res = $sql->fetch_assoc()) { ?>
			<option value="<?php print $res['id']; ?>"><?php print $res['category_name']; ?></option>
			<?php
				}
			}
			?></td>
                       
                    </tr>
                    <tr>
                      <td>Supplier:</td>
                      <td><input name="supplier" placeholder="ENTER SUPPLIER NAME" type="text" id="supplier"  maxlength="200"  class="round default-width-input" value="<?php echo $supplier; ?>" /></td>
                       
                      <td>Sub Category:</td>
                      <td><div class="sub_body"></div></td>
                       
                    </tr>
                   <tr>
                      <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                      <td><div class="subsub_body"></div></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    
                    
                    <tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
                        <input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Add">
			<td align="right"><input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    </tr>
                  </table>
                </form>
		<script>
		//$("#subcatdiv").hide();
		function fetch_subcat() { 
			var parentid = $("#parent_category").val();
			//$(".sub_header").html('Sub Category:');

			$.ajax({
				type: "POST",
				data: "parent_id="+parentid,
				url: "<?php print SITE_URL; ?>/z_fetch_product_subcat",
				success: function(response) {
					$(".sub_body").html(response);
				}
			});
		}
		</script>
		<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Stock Successfully Inserted. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
			window.location.href="<?php print SITE_URL; ?>/add_stock";
		} else {
			window.location.href="<?php print SITE_URL; ?>/add_stock";
		}
		});
		</script>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
