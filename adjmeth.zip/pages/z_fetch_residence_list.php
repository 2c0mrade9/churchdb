<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

$db = new Database;
$q = ucwords($_GET["q"]);
$q = $db->cleanData($q);
if (!$q) return;
$row = $db->select("SELECT * FROM adjmeth_residence");
  while ($res = $row->fetch_assoc()) {
  
  	if (strpos(ucwords($res['name']), $q) !== false) {
		echo "".ucwords($res['name'])."\n";
	
 }
 }

?>
