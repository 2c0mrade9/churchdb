<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Update Administrators", $pageDescription);
$user = new UserModel;
?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 

<?php if(!isset($ACTION[1]) || $ACTION[1]=="list") { ?>

<?PHP } ?>
<script>
<?php if(isset($ACTION[1]) || $ACTION[1]=="add") { ?>
$(document).ready(function() {
		$("#lname").autocomplete("<?php print SITE_URL; ?>/z_fetch_name_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#fname").autocomplete("<?php print SITE_URL; ?>/z_fetch_fname_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				lname: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				fname: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				password: {
					required: true,
					minlength: 5
				},
				uname: {
					required: true,
					minlength: 5
				},
				answer: {
					required:true,
					minlength: 4
				}
			},
			messages: {
				lname: {
					required: "Please Enter Lastname"
				},
				fname: {
					required: "Please Enter Firstname"
				},<?php if(!isset($ACTION[2])) { ?>
				password: {
					required: "Please Enter Password"
				},<?php } ?>
				<?php if(isset($ACTION[2]) and $user->UserById($ACTION[2],"alias")->found == true) { ?>
				password: {
					required: "Enter your password to confirm changes."
				},<?php } ?>
				uname: {
					required: "Please Enter Username"
				},
				role: {
					required: "Please Select Role"
				}
			}
		});
	});
<?php } ?>
<?php if(!isset($ACTION[1]) || $ACTION[1]=="list") { ?>
<!--
// Nannette Thacker http://www.shiningstar.net
function confirmSubmit(id,table,dreturn) {
	jConfirm('You Want Delete Class. Do you still wish to continue?', 'Confirmation Dialog', function (r) {
       	if(r){ 
               $.ajax({
			type: "POST",  
			url: "<?php print SITE_URL; ?>/z_delete",  
			data: "pid="+id+"&table="+table+"&return="+dreturn,
  			success: function(response) {
    				alert(response);
					//jAlert('Class Is Deleted', '<?php print SITE_NAME; ?>');
				//window.location ='<?php print SITE_URL; ?>/view_class';
  			}
		});
            }
            return r;
        });
}

function confirmDeleteSubmit()
{
   var flag=0;
  var field=document.forms.deletefiles;
for (i = 0; i < field.length; i++){
    if(field[i].checked ==true){
        flag=flag+1;
        
    }
	
}
if (flag <1) {

  jAlert('You must check one and only one checkbox', '<?php print SITE_NAME; ?>');
return false;
}else{
 jConfirm('You Want Delete Administrator. Deleting a Administrator will delete all its members too. Do you still wish to continue?', 'Confirmation Dialog', function (r) {
           if(r){ 
	
document.deletefiles.submit();}
else {
	return false ;
   
}
});
}
}
function confirmLimitSubmit()
{
    if(document.getElementById('search_limit').value!=""){

document.limit_go.submit();

    }else{
        return false;
    }
}


function checkAll()
{

	var field=document.forms.deletefiles;
for (i = 0; i < field.length; i++)
	field[i].checked = true ;
}

function uncheckAll()
{
	var field=document.forms.deletefiles;
for (i = 0; i < field.length; i++)
	field[i].checked = false ;
}
// -->
<?php } ?>
</script>
<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Administrator Management</h3>
	<ul>
		<li><a href="<?php print SITE_URL; ?>/update_admins/add">Add Administrator</a></li>
		<li><a href="<?php print SITE_URL; ?>/update_admins/list">View Administrators</a></li>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Administrators</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">
	
	<?php if(!isset($ACTION[1]) || $ACTION[1]=="list") { ?>

	<div style="margin-bottom:15px;" align="right">
		<form name="deletefiles" action="<?php print SITE_URL; ?>/z_delete" method="post">

		<input type="hidden" name="table" value="adjmeth_admin">
		<input type="hidden" name="return" value="update_admins/list">
		<input type="button" name="selectall" value="SelectAll" class="my_button round blue   text-upper" onClick="checkAll()"  style="margin-left:5px;"/>
		<input type="button" name="unselectall" value="DeSelectAll" class="my_button round blue   text-upper" onClick="uncheckAll()" style="margin-left:5px;" />
		<input name="dsubmit" type="button" value="Delete Selected" class="my_button round blue   text-upper" style="margin-left:5px;" onclick="return confirmDeleteSubmit()"/>
			
			<div class="list_administrators"></div>
			
		
		</form>
		<script>
		fetch_Administrators();
		function fetch_Administrators() {
			$.ajax({
				type: "POST",  
				url: "<?php print SITE_URL; ?>/z_fetch_administrators",  
				data: "list_administrators&cpage=<?php if(isset($_GET['cpage'])) print $_GET['cpage']; else print 0; ?>",
				beforeSend: function() {
					$('.list_administrators').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
				},  success: function(response){
					$('.list_administrators').html(response);
				}
			});
		}
		function fetch_Administrator_search() {
			var searchtxt = $("#searchtxt").val();
			if(searchtxt.length > 2) {
				$.ajax({
					type: "POST",  
					url: "<?php print SITE_URL; ?>/z_fetch_administrators",  
					data: "list_administrators&search="+searchtxt,
					beforeSend: function() {
						$('.list_administrators').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
					},  success: function(response){
						$('.list_administrators').html(response);
					}
				});
			} else {
				fetch_Administrators();
			}
		}
		</script>
	</div>	
	
	<?php } elseif(isset($ACTION[1]) and $ACTION[1]=="add") { ?>
	<?php include_once 'core/controllers/insert_user.php'; ?>
	<form name="form1" method="post" id="form1" action="">
		<style>
		.form tr td {
			padding:5px!important;
			font-weight:bold;
		}
		</style>
		
		<p><strong>Add New Administrator </strong></p>
		<table class="form"  border="0" style="margin:5px">
			<tr>
				<td><span class="man">*</span>Lastname:</td>
				<td><input name="lname" placeholder="ENTER LASTNAME" type="text" id="lname" maxlength="200"  class="round default-width-input" value="<?php echo $lname; ?>" /></td>
				<td><span class="man">*</span>Firstname:</td>
				<td><input name="fname" placeholder="ENTER FIRSTNAME" type="text" id="fname" maxlength="200"  class="round default-width-input" value="<?php echo $fname; ?>" /></td>
			</tr>
			<tr>
				<td><span class="man">*</span>Username:</td>
				<td><input name="uname" placeholder="ENTER ABBREVIATION" type="text" id="uname" maxlength="200"  class="round default-width-input" value="<?php echo $uname; ?>" /></td>
				<td><span class="man">*</span>Role:</td>
				<td>
					<select name="role" id="role" class="round my_text_box" style="padding:5px;width:170px;height:35px">
						<option value="0">Select Role</option>
						<?php print $level; ?>
						<?php
						$sql = $db->select("SELECT * FROM adjmeth_admin_roles");
						if($db->scount($sql) > 0) {
						while($res = $sql->fetch_assoc()) { ?>
						<option value="<?php print $res['id']; ?>"><?php print $res['name']; ?></option>
						<?php
							}
						}
						?>
					</select>
				</td>
			</tr>
			
			<tr>
				<td><span class="man">*</span>Password:</td>
				<td><input name="password" placeholder="ENTER PASSWORD" type="text" id="password"  maxlength="200"  class="round default-width-input"/></td>
				<td>Email:</td>
				<td><input name="email" placeholder="ENTER EMAIL (OPTIONAL)" type="email" id="email"  maxlength="200" value="<?php print $email; ?>" class="round default-width-input"/></td>
			</tr>
			<tr>
				<td><span class="man">*</span>Secure Question:</td>
				<td>
					<select name="question" id="question" class="round my_text_box" style="padding:5px;width:200px;height:35px">
						<option value="0">Select Question</option>
						<?php print $question_opt; ?>
						<?php
						$sql = $db->select("SELECT * FROM adjmeth_admin_questions");
						if($db->scount($sql) > 0) {
						while($res = $sql->fetch_assoc()) { ?>
						<option value="<?php print $res['question']; ?>"><?php print $res['question']; ?></option>
						<?php
							}
						}
						?>
					</select>
				</td>
				<td><span class="man">*</span>Secure Answer:</td>
				<td><input name="answer" placeholder="ENTER ANSWER" type="text" id="answer" maxlength="200"  class="round default-width-input" value="<?php echo $answer; ?>" /></td>
				
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>
				<input type="hidden" name="adduser" id="adduser" value="adduser">
				<input type="hidden" name="uid" id="uid" value="null">
				<input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Add"></td>
				<td align="right"><input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
				<td>&nbsp;</td>
			</tr>
		</table>
	</form>
	
	<?php } elseif(isset($ACTION[1]) and $ACTION[1]=="mem") { ?>
	<?php include_once 'core/controllers/insert_user.php'; ?>
		<?php if(isset($ACTION[2]) and $user->UserById($ACTION[2],"alias")->found == true) { ?>
		<form name="form1" method="post" id="form1" action="">
			<style>
			.form tr td {
				padding:5px!important;
				font-weight:bold;
			}
			</style>
			<p><strong>Add New Administrator </strong></p>
			<table class="form"  border="0" style="margin:5px">
				<tr>
					<td><span class="man">*</span>Lastname:</td>
					<td><input name="lname" placeholder="ENTER LASTNAME" type="text" id="lname" maxlength="200"  class="round default-width-input" value="<?php echo $lname; ?>" /></td>
					<td><span class="man">*</span>Firstname:</td>
					<td><input name="fname" placeholder="ENTER FIRSTNAME" type="text" id="fname" maxlength="200"  class="round default-width-input" value="<?php echo $fname; ?>" /></td>
				</tr>
				<tr>
					<td><span class="man">*</span>Username:</td>
					<td><input name="uname" placeholder="ENTER ABBREVIATION" type="text" id="uname" maxlength="200"  class="round default-width-input" value="<?php echo $uname; ?>" /></td>
					<td><span class="man">*</span>Role:</td>
					<td>
						<select name="role" id="role" class="round my_text_box" style="padding:5px;width:170px;height:35px">
							<option value="0">Select Role</option>
							<?php print $level; ?>
							<?php
							$sql = $db->select("SELECT * FROM adjmeth_admin_roles");
							if($db->scount($sql) > 0) {
							while($res = $sql->fetch_assoc()) { ?>
							<option value="<?php print $res['id']; ?>"><?php print $res['name']; ?></option>
							<?php
								}
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td><span class="man">*</span>Password:</td>
					<td><input name="password" placeholder="ENTER PASSWORD" type="text" id="password"  maxlength="200"  class="round default-width-input"/></td>
					<td>Email:</td>
					<td><input name="email" placeholder="ENTER EMAIL (OPTIONAL)" type="email" id="email"  maxlength="200"  value="<?php print $email; ?>" class="round default-width-input"/></td>
				</tr>
				<tr>
				<td><span class="man">*</span>Secure Question:</td>
				<td>
					<select name="question" id="question" class="round my_text_box" style="padding:5px;width:200px;height:35px">
						<option value="0">Select Question</option>
						<?php print $question_opt; ?>
						<?php
						$sql = $db->select("SELECT * FROM adjmeth_admin_questions");
						if($db->scount($sql) > 0) {
						while($res = $sql->fetch_assoc()) { ?>
						<option value="<?php print $res['id']; ?>"><?php print $res['question']; ?></option>
						<?php
							}
						}
						?>
					</select>
				</td>
				<td><span class="man">*</span>Secure Answer:</td>
				<td><input name="answer" placeholder="ENTER ANSWER" type="text" id="answer" maxlength="200"  class="round default-width-input" value="<?php echo $answer; ?>" /></td>
				
			</tr>
				<tr>
					<td>&nbsp;</td>
					<td>
					<input type="hidden" name="adduser" id="adduser" value="adduser">
					<input type="hidden" name="level" id="level" value="<?php print $user->UserById($ACTION[2], "alias")->LEVEL; ?>">
					<input type="hidden" name="uid" id="uid" value="<?php print $user->UserById($ACTION[2], "alias")->UID; ?>">
					<input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Update"></td>
					<td align="right"><input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
					<td>&nbsp;</td>
				</tr>
			</table>
		</form>
		<?php } else { ?>
			<?php notFoundMessage("The Administrator you are trying to view does not exist on this server. Please contact Website Administrator"); ?>
		<?php } ?>
	<?php } ?>
	<center>
		<hr>
		<span style="color:#ff4000"><em>The Secure Question & Secure Answer will be used whenever you want to reset your password!</em></span>
	</center>
</div></div>
</div></div>
<?php
template_footer();
?>
