<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Update Member Details", $pageDescription);
$tbl_count = new CountModel;
$member = new MemberModel;

?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		
		$('#dob').jdPicker();
		$('#datejoin').jdPicker();
		
		$("#class").autocomplete("<?php print SITE_URL; ?>/z_fetch_class_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#organization").autocomplete("<?php print SITE_URL; ?>/z_fetch_organization_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#organization2").autocomplete("<?php print SITE_URL; ?>/z_fetch_organization_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#residence").autocomplete("<?php print SITE_URL; ?>/z_fetch_residence_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#occupation").autocomplete("<?php print SITE_URL; ?>/z_fetch_occupation_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				gender: {
					required: true,
					minlength: 1
				},
				lname: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				fname: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				memberid: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				residence: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				phone1: {
					required: true,
					minlength: 3,
					maxlength: 200
				}
			},
			messages: {
				gender: {
					required: "Please Select Gender",
					minlength: "Select one option"
				},
				lname: {
					required: "Please Enter Lastname",
					minlength: "Lastname must consist of at least 3 characters"
				},
				fname: {
					required: "Please Enter Firstname",
					minlength: "Firstname must consist of at least 3 characters"
				},
				memberid: {
					required: "Please Enter Member ID"
				},
				residence: {
					required: "Please Enter Place of Residence",
					minlength: "Place of Residence must consist of at least 3 characters"
				},
				phone1: {
					required: "Please Enter Phone Number",
					minlength: "Phone Number must consist of at least 3 characters"
				},
			}
		});
	});
	function numbersonly(e){
		var unicode=e.charCode ? e.charCode : e.keyCode
		if (unicode!=8 && unicode!=46 && unicode!=37 && unicode!=38 && unicode!=39 && unicode!=40 && unicode!=9) { 
		//if the key isn't the backspace key (which we should allow)
		if (unicode<48||unicode>57)
			return false
		}
	}
</script>


<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Member Management</h3>
	<ul>
		<?php template_sidebar(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Update Member Details</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf" >
		
		<?php if(isset($ACTION[1]) and $member->MemberById($ACTION[1])->found == true) { ?>
		<?php if(isset($_GET["adj"]) and !empty($_GET["adj"])) { ?>
		<script>
		addTeacher();
		function addTeacher() {
			$.ajax({
				type:"post",
				data:"adjust=<?php print $_GET["adj"]; ?>&id=<?php print $ACTION[1]; ?>",
				url:"<?php print SITE_URL; ?>/z_add_teacher",
				success:function(response){
					alert(response);
				}
			});
		}
		</script>
		<?php } ?>
		
		<?php include_once('core/controllers/update_member.php'); ?>
		<form name="form1" enctype="multipart/form-data" autocomplete="off" method="post" id="form1" action="">
                  
					<style>
					.form tr td {
						padding:5px!important;
						font-weight:bold;
					}
					</style>
                  <table class="form" border="0" width="100%" cellspacing="10px" cellpadding="5px">
                    <tr>
                      <td colspan="4" align="center">
						<strong style="color:blue"><hr>PERSONAL DETAILS<hr></strong></td>
                    </tr>
					<tr>
                          <?php
							$max = $db->maxOfAll("id", "adjmeth_members");
							$max=$max+rand(1, 9999);
							$autoid="AMC".$max."";
						   ?>
                      <td><span class="man">*</span>Member ID:</td>
                      <td><input name="memberid" type="text" id="memberid" maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_id; ?>" /></td>
                      
					  <td>Gender: </td>
					  <td><select name="gender" class="round my_text_box" style="padding:5px;width:120px;height:35px;cursor:pointer;">
						<option selected="selected" value="<?php print $member->MemberById($ACTION[1])->mem_gender; ?>"><?php print $member->MemberById($ACTION[1])->mem_gender; ?></option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select></td>
					<td rowspan="5" valign="top">
						<?php print $member->MemberById($ACTION[1])->mem_image; ?>
						<input type="file" name="userimage" id="userimage">
					</td>
                    </tr>
                    <tr>
                      <td>Title:</td>
                      <td><input name="title" placeholder="ENTER TITLE" type="text" id="title"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_title; ?>" /></td>
                       
                      <td>Date of Birth 
						<span style="font-weight:normal" class="man">(dd-mm-yyyy)</span></td>
                      <td><input name="dob" placeholder="ENTER DATE OF BIRTH" type="text" id="dob"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_dob; ?>" /></td>
                       
                       
                    </tr>
					<tr>
                      <td><span class="man">*</span>Lastname:</td>
                      <td><input name="lname" placeholder="ENTER LASTNAME" type="text" id="lname"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_lname; ?>" /></td>
                       
                      <td><span class="man">*</span>Firstname:</td>
                      <td><input name="fname" placeholder="ENTER FIRSTNAME" type="text" id="fname" maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_fname; ?>" /></td>
                       
                    </tr>
					<tr>
                      <td><span class="man">*</span>MARITAL STATUS:</td>
                      <td>
						<select style="padding:5px;width:120px;height:35px;cursor:pointer;" name="marstat" id="marstat">
							<option value="Single">Please Select</option>
							<?php
							$sql = $db->select("SELECT * FROM `adjmeth_marital`");
							while($res=$sql->fetch_assoc()){
							?>
							<option value="<?php print $res['name']; ?>"><?php print $res['status']; ?></option>
							<?php } ?>
						</select>
					  </td>
                      <td>Number of Children:</td>
                      <td><input name="noofchild" onkeypress="return numbersonly(event)" placeholder="ENTER NUMBER OF CHILDREN" type="text" id="noofchild" maxlength="2"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_noofchild; ?>" /></td>
                       
                    </tr>
					<tr>
                      <td colspan="4" align="center">
						<strong style="color:blue"><hr>CONTACT DETAILS<hr></strong></td>
                    </tr>
					<tr>
                      <td><span class="man">*</span>Phone 1:</td>
                      <td><input name="phone1" onkeypress="return numbersonly(event)" placeholder="ENTER PHONE NUMBER 1" type="text" id="phone1"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_phone; ?>" /></td>
                       
                     <td>Phone 2:</td>
                      <td><input name="phone2" onkeypress="return numbersonly(event)" placeholder="ENTER PHONE NUMBER 2" type="text" id="phone2"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_phone1; ?>" /></td>
                    </tr>
					<tr>
                      <td valign="top">Address</td>
                      <td><textarea style="border-radius:3px;width:95%;height:100px;" name="address" id="address"><?php print $member->MemberById($ACTION[1])->mem_add; ?></textarea></td>
					  
					  <td valign="top">Email:</td>
                      <td  valign="top"><input name="email" placeholder="ENTER EMAIL ADDRESS" type="email" id="email"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_email; ?>" /></td>
                      
                    </tr>
					<tr>
					 <td valign="top">Occupation:</td>
                      <td  valign="top"><input name="occupation" placeholder="ENTER OCCUPATION" type="text" id="occupation"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_occup; ?>" /></td>
                      <td valign="top">Place of Abode:</td>
                      <td  valign="top"><input name="residence" placeholder="ENTER AREA OF RESIDENCE" type="text" id="residence"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_res; ?>" /></td>
                    </tr>
					<tr>
                      <td colspan="4" align="center">
						<strong style="color:blue"><hr>MEMBERSHIP DETAILS<hr></strong></td>
                    </tr>
					<tr>
                      <td>Main Organization:</td>
                      <td><input name="organization" placeholder="ENTER ORGANIZATION" type="text" id="organization"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_org; ?>" /></td>
                       
					  <td>Other Organization:</td>
                      <td><input name="organization2" placeholder="ENTER OTHER ORGANIZATION" type="text" id="organization2"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_sorg; ?>" /></td>
                       
                    </tr>
					<tr>
                      <td>Class:</td>
                      <td><input name="class" placeholder="ENTER CLASS" type="text" id="class"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_nclass; ?>" /></td>
                       <td valign="top">Date Joining:</td>
                      <td  valign="top"><input name="datejoin" placeholder="ENTER DATE JOINING" type="text" id="datejoin"  maxlength="200"  class="round default-width-input" value="<?php print $member->MemberById($ACTION[1])->mem_join; ?>" /></td>
                      
                    </tr>
					
					<tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
					  <td>&nbsp;</td>
					  <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
                        <input class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Update">
						<a class="button round dark image-right ic-print text-upper" target="_blank" href="<?php print SITE_URL; ?>/print/member/<?php print $ACTION[1]; ?>">
						Print </a>
					<td align="right"><input class="button round red text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    </tr>
                  </table>
                </form>
		
		<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Member Information Successfully Updated. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
			window.location.href="<?php print SITE_URL; ?>/update_member/<?php print $ACTION[1]; ?>/update_members";
		} else {
			window.location.href="<?php print SITE_URL; ?>/update_member/<?php print $ACTION[1]; ?>/update_members";
		}
		});
		</script>
		<?php } ?>
		<?php } else { ?>
		<?php notFoundMessage("The Member you are trying to view does not exist on this server. Please contact Website Administrator"); ?>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
