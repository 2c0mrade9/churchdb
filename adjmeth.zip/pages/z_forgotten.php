<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
$db = new Database;
$models = new Models;
$usern = "";
//check if the user wants to retrieve the username 
if(isset($_POST['username'])) {
	//check if the user has supplied the password and question field
	if(isset($_POST['pass']) and isset($_POST['quest'])) {
		$pass = stripcslashes($_POST['pass']);
		$quest = $db->cleanData($_POST['quest']);
		$answer = $db->cleanData($_POST['answer']);
		//check if the password length is 0 and the question is not parsed
		if(strlen($pass) < 1 and $quest=="0") {
			//return error message
			print "<div class='btn btn-danger'>Sorry! You are to submit at least one object.</div>";
		} else {
			//continue processing
			//check if the password  only was supplied
			if($quest=="0" and strlen($pass) > 1) {
				//continue
				//check if the password characters is less than 5 characters
				if(strlen($pass) < 5) {
					print "<div class='btn btn-danger'>Sorry! Password should be at least 5 characters.</div>";
				} else {
					//fetch the username using the password.
					$passkey = md5(sha1($pass));
					$sql = $db->select("select Username, Password from adjmeth_admin where Password='$passkey'");
					if($db->scount($sql) == 1) {
						//fetch the information
						while($result = $sql->fetch_assoc()) {
							$usern .= $result['Username'];
							if($db->scount($sql) > 1)
								$usern .=" or ";
						}
						//print the success message
						print "<div class='btn btn-danger'>Congrats! You supplied a valid Password!</div>";
						print "<div class='btn btn-danger' style='color:green'>The Username to the Account is either: $usern</div>";
					} else {
						//print an error message telling the user the password submitted does not match any account.
						print "<div class='btn btn-danger' style='color:green'>Sorry! Password supplied does not match any account in the database. Thank You!</div>";
					}
				}
				//if the password was not supplied lets try the question option
			} elseif($quest!="0") {
				//check if the answer is less than 4 characters then supply an error message
				if(strlen($answer) < 4) {
					print "<div class='btn btn-danger'>Sorry! The answer length is too short. Thank You!</div>";
				} else {
					//continue
					$quest = $models->create_slug($quest);
					$answer = $models->create_slug($answer);
					//verify if the question chosen and the answer submitted matches that in the database
					$sql = $db->select("Select * from adjmeth_admin where SecureQuestion='$quest' AND SecureAnswer='$answer'");
					//count the number of rows
					if($db->scount($sql) > 0) {
						while($result = $sql->fetch_assoc()) {
							$usern .= $result['Username'];
							if($db->scount($sql) > 1)
								$usern .=" or ";
						}
						//print success message
						print "<div class='btn btn-danger' style='color:green'>Congrats! You supplied a Answer to the question!</div>";
						print "<div class='btn btn-danger' style='color:green'>The Username to the Account is either: $usern</div>";
					} else {
						//print error message
						print "<div class='btn btn-danger'>Sorry! Information supplied does not match any account in the database. Thank You!</div>";
					}
				}
			}
		}
	} else {
		//return error message if the password and question field were not supplied
		print "<div class='btn btn-danger'>Sorry! You supplied invalid data</div>";
	}
}
?>
<style>
.btn-danger {
	color:#ff4000;
	margin-top:10px;
	font-weight:bold;
}
</style>