<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";
include_once 'core/utils/TimeStamp.php';
include_once 'core/utils/SimplePager.php';

//create new ago instance
$db = new Database();
$org = new OrganizationModel;
$res = new ResidenceModel;
$cla = new ClassModel;
$display_news_headlines = '';

//check if the form has been sent
if(isset($_POST['list_members'])) {
	
	if(isset($_POST["sundaySchoolList"]))
		$addQuery="and mem_type='teacher'";
	else
		$addQuery="";
	
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$fquery = $db->select("SELECT * FROM `adjmeth_members` 
			WHERE 
				(fullname LIKE '%$search%' OR address LIKE '%$search%' OR 
				phone LIKE '%$search%' OR 
				phone1 LIKE '%$search%' OR orgname LIKE '%$search%' OR orgsub LIKE '%$search%') and type='main' $addQuery AND
				`status`='1' ORDER BY fullname ASC");
	}else {
		$fquery = $db->select("SELECT * FROM `adjmeth_members` WHERE type='main' $addQuery and `status`='1' ORDER BY fullname ASC");
	}
	$counter = $db->scount($fquery);
		
	//This is the number of contents to display on each page
	if(isset($_POST['limit']) and $_POST['limit'] > 0) {
		$rowsPerPage = $db->cleanData($_POST['limit']);
	} else {
		$rowsPerPage = LIMIT;
	}
	
	include_once 'core/utils/PagerController.php';
	
	//query the database based on the category parsed
	//by the administrator and limit the query by 10
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$query = $db->select("SELECT * FROM `adjmeth_members` 
					WHERE 
				(fullname LIKE '%$search%' OR address LIKE '%$search%' OR 
				phone LIKE '%$search%' OR 
				phone1 LIKE '%$search%' OR orgname LIKE '%$search%' OR orgsub LIKE '%$search%') and type='main' $addQuery AND
				`status`='1' ORDER BY `fullname` ASC LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	} else {
		$query = $db->select("SELECT * FROM `adjmeth_members` 
					WHERE type='main' $addQuery and `status`='1' ORDER BY `fullname` ASC LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	}
?>
<table style="margin-top:10px">
		<tr>
			<th width="5%">No</th>
			<th>Fullname</th>
			<th>Contact</th>							
			<th>Organizations</th>
			<th>Class</th>
			<th>Edit /Delete</th>
            <th width="5%">Select</th>
		</tr>
<?php 		
	if($db->scount($query)) {
?>

<?php 		
	//using the while loop to display the data
	while($row = $query->fetch_assoc()) {
			
?>
	<tr>
   <td  width="5%"> <?php echo $row['id']; ?></td>

	<td><?php echo $row['fullname']; ?></td>
    <td> <?php echo $row['phone'];?> / <?php echo $row['phone1'];?></td>
    <td> <?php echo $org->OrganizationById($row['organization'],"id")->gname;?>
	 / <?php echo $org->OrganizationById($row['suborganization'],"id")->gname;?></td>
	<td> <?php echo $cla->ClassById($row['m_class'],"id")->cname;;?></td>
	<td>
	<?php if(!isset($_POST["searchTeacher"])) { ?>
		<a title="Update member details" href="<?php print SITE_URL; ?>/update_member/<?php echo $row['uniqueid'];?>/view_member"	class="table-actions-button ic-table-edit"></a>
		<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==2) { ?>
		<a  title="Delete member" href="#" onclick="javascript:confirmSubmit(<?php echo $row['id'];?>,'adjmeth_members','view_member')" class="table-actions-button ic-table-delete"></a>
		<?php } ?>
		<a title="Print member details" class="table-actions-button ic-print" target="_blank" href="<?php print SITE_URL; ?>/print/member/<?php print $row['uniqueid']; ?>"></a>
		<?php if(isset($_POST["sundaySchoolList"]) and $row['mem_type']=="teacher") { ?>
		<a class="table-actions-button ic-delete" title="Click to Remove as Sunday School Teacher" href="<?php print SITE_URL; ?>/update_member/<?php echo $row['uniqueid'];?>/view_member?adj=removeTeacher" style="color:#ff4000" class="table-actions-button ic-table-">
			
		</a>
		<?php } ?>
	<?php } else { ?>
		<?php if($row['mem_type']=="teacher") { ?>
		<a class="table-actions-button ic-delete"  title="Click to Remove as Sunday School Teacher" href="<?php print SITE_URL; ?>/update_member/<?php echo $row['uniqueid'];?>/view_member?adj=removeTeacher" style="color:#ff4000" class="table-actions-button ic-table-">
			
		</a>
		<?php } else { ?>
		<a class="table-actions-button ic-add" title="Click to add as Sunday School Teacher" href="<?php print SITE_URL; ?>/update_member/<?php echo $row['uniqueid'];?>/view_member?adj=addTeacher" class="table-actions-button ic-table-">
			
		</a>
		<?php } ?>
	<?php } ?>
	
	</td>
	<td width="5%"><input type="checkbox" value="<?php echo $row['id']; ?>" name="checklist[]" id="check_box" /></td>

</tr>		
<?php
	}

?>
</table>
<?php if(isset($_POST["searchTeacher"])) { ?>
<hr>
<input name="Search" type="submit" onclick="return reload();" class="my_button addnew round blue text-upper" value="not in list?">
<hr>
<script>
function reload(){
	window.location.href="<?php print SITE_URL; ?>/add_member";
}
</script>
<?php } ?>

<?php
	print '<br clear="all" />';
	print '<div style="color:#ff0000;font-size:15px;"><strong>'.$counter;
	print '</strong> Members Found. Showing Page <strong>'.$page.'</strong> of <strong>'.$pager->getTotalPages().'</strong></div>';
	print '<br clear="all" />';
?>
	<br clear="all" />
	<div class="row">
	<div style="" align="left"><?php print $paginate; ?></div>
	<br clear="all" />
	</div>
<?php	} else {
	
	?>
	<tr><td colspan="5" style="font-size:18px;">No results found</td></tr>
	
	<?php
}
?>
</table>
<?php if(isset($_POST["searchTeacher"])) { ?>
<hr>
<input name="Search" type="submit" onclick="return reload();" class="my_button addnew round blue text-upper" value="not in list?">
<hr>
<script>
function reload(){
	window.location.href="<?php print SITE_URL; ?>/add_member";
}
</script>
<?php }
}	
?>
