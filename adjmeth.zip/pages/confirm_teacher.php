<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("View Members", $pageDescription);
$tbl_count = new CountModel;
?>
 <script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >

<script LANGUAGE="JavaScript">
<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==2) { ?>
<!--
// Nannette Thacker http://www.shiningstar.net
function confirmSubmit(id,table,dreturn) {
	jConfirm('You Want Delete Member', 'Confirmation Dialog', function (r) {
       	if(r){ 
               $.ajax({
			type: "POST",  
			url: "<?php print SITE_URL; ?>/z_delete",  
			data: "pid="+id+"&table="+table+"&return="+dreturn,
  			success: function(response) {
    			jAlert('Member Is Deleted', '<?php print SITE_NAME; ?>');
				alert(response);
				//window.location ='<?php print SITE_URL; ?>/view_members';
  			}
		});
            }
            return r;
        });
}


function confirmDeleteSubmit()
{
   var flag=0;
  var field=document.forms.deletefiles;
for (i = 0; i < field.length; i++){
    if(field[i].checked ==true){
        flag=flag+1;
        
    }
	
}
if (flag <1) {

  jAlert('You must check one and only one checkbox', '<?php print SITE_NAME; ?>');
return false;
}else{
 jConfirm('You Want Delete Members', 'Confirmation Dialog', function (r) {
           if(r){ 
	
document.deletefiles.submit();}
else {
	return false ;
   
}
});
}
}

<?php } ?>

function confirmLimitSubmit()
{
    if(document.getElementById('search_limit').value!=""){

document.limit_go.submit();

    }else{
        return false;
    }
}


function checkAll()
{

	var field=document.forms.deletefiles;
for (i = 0; i < field.length; i++)
	field[i].checked = true ;
}

function uncheckAll()
{
	var field=document.forms.deletefiles;
for (i = 0; i < field.length; i++)
	field[i].checked = false ;
}
// -->
</script>
<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>SUNDAY SCHOOL Management</h3>
	<ul>
		<?php template_sidebar6(); ?>
	</ul>                             
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">SUNDAY SCHOOL TEACHERS</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
		<style>.addnew{line-height:20px!important;width:200px!important;} .my_button {
	font-size:18px!important;
	padding-bottom:20px!important;
	line-height:5px;
	width:100px;
}</style>
	<div class="content-module-main cf">
	<h1 style="font-weight:bold;font-family:arial">CHECK IF THE TEACHER ALREADY EXISTS IN THE DATABASE</h1>
<table style="width:600px" border="0">
<tr><td>
<form action="javascript:fetch_members_search();" method="post" name="search" >
    <input id="searchtxt" name="searchtxt" style="width:300px;" type="text" class="round my_text_box" placeholder="Search by Name of Phone Number"> 
&nbsp;&nbsp;<input name="Search" type="submit" class="my_button round blue text-upper" value="Search">
</form><br>
<!-- <form action="" method="get" name="limit_go">
    Page per Record<input name="limit" type="text" class="round my_text_box" id="search_limit" style="margin-left:5px;" value="<?php if(isset($_GET['limit'])) echo $_GET['limit']; else echo "10"; ?>" size="3" maxlength="3">
    <input name="go"  type="button" value="Go" class=" round blue my_button  text-upper" onclick="return confirmLimitSubmit()">
</form>--></td>
</tr>
</table>

<div style="margin-bottom:15px;" align="right">
	<div class="list_members"></div>
	<script>
	function fetch_members_search() {
		var searchtxt = $("#searchtxt").val();
		if(searchtxt.length>1){
			$.ajax({
				type: "POST",  
				url: "<?php print SITE_URL; ?>/z_fetch_members",  
				data: "searchTeacher&list_members&search="+searchtxt,
				beforeSend: function() {
					$('.list_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
				},  success: function(response){
					$('.list_members').html(response);
				}
			});
		} else {
			$('.list_members').html('<div class="alert alert-danger">Please enter a search term.</div>');
		}
	}
	</script>
</div>	</div></div>
</div></div>
<?php
template_footer();
?>
