<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Update Class", $pageDescription);
$tbl_count = new CountModel;
$class = new ClassModel;

?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		
		$("#csecretary").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#acleader").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#cleader").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				cname: {
					required: true,
					minlength: 3,
					maxlength: 200
				}
			}
		});
	});
	$(".side-content").onclick(function() {
		$(".autosuggestions").html('');
	});
</script>


<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Class Management</h3>
	<ul>
		<?php template_sidebar3(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Update Class Details</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf" >
		<?php if(isset($ACTION[1]) and $class->ClassById($ACTION[1],"alias")->found == true) { ?>

		<?php include_once('core/controllers/update_class.php'); ?>
		<form name="" method="post" id="form1" action="">
                  
					<style>
					.table tr td {
						padding:5px!important;
						font-weight:bold;
					}
					</style>
                  <table class="table" border="0" width="100%" cellspacing="10px" cellpadding="5px">
					<tr>
                      <td width="20%" valign="top"><span class="man">*</span>Class Name:
					  <br><br><br>
					  Class Leader
					  <br><br><br>
					  Assist Class Leaders:
					  <br><br><br>
					  Class Secretary:
					  </td>
                      <td width="30%" valign="top">
					  <input required="required" name="cname" placeholder="ENTER CLASSNAME" type="text" id="cname"  maxlength="200"  class="round default-width-input" value="<?php echo $cname; ?>" />
					  <br><br>
					  <input name="cleader" placeholder="ENTER CLASS LEADER" type="text" id="cleader"  maxlength="200"  class="round default-width-input" value="<?php echo $cleader; ?>" />
					  <br><br>
					  <input name="acleader" placeholder="ENTER ASSIST CLASS LEADER" type="text" id="acleader"  maxlength="200"  class="round default-width-input" value="<?php echo $acleader; ?>" />
					  <br><br>
					  <input name="csecretary" placeholder="ENTER CLASS SECRETARY" type="text" id="csecretary"  maxlength="200"  class="round default-width-input" value="<?php echo $csecretary; ?>" />
					  <br></br><br>
					  <input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Update">
						<input type="hidden" name="classid" value="<?php print $ACTION[1]; ?>">
						<input class="button round red text-upper"  type="reset" name="Reset" value="Reset">
						
					  </td>
                       
                      <td valign="top" rowspan="2" style="border-left:solid 1px #000">
						<div style="height:100px;">
							<strong>ADD MEMBER TO CLASS</strong>
							<div class="input-group custom-search-form">
								<input style="width:400px;height:30px;font-size:18px;" onkeyup="return searchUser();" name="newmember" placeholder="ENTER MEMBER NAME" type="text" id="newmember"  maxlength="200"  class="round default-width-input" value="" />
									<span class="input-group-btn">
									</span>
								<div class="autosuggestions"></div>
							</div>
						</div>
						<span style="font-weight:bold;font-size:20px;">
							Class Member List:</span><hr>
						<style>
								.list_members{
								max-height:350px!important;
								overflow:scroll;
								overflow-x:none;
							}
							</style>
							<div class="list_members">
								<div class="list_class_members"></div>
							</div>
							<script>
							class_by_id('<?php echo $class_id; ?>');
							function class_by_id(cid) {
								$.ajax({
									type: "POST",  
									url: "<?php print SITE_URL; ?>/z_fetch_members_by_cid",  
									data: "list_class_members&cid="+cid,
									beforeSend: function() {
										$('.list_class_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
									},  success: function(response){
										$('.list_class_members').html(response);
									}
								});
							}
							function removeFromClass(memid,cid) {
								$.ajax({
									type: "POST",  
									url: "<?php print SITE_URL; ?>/z_process_class_member",  
									data: "removeMember&cid="+cid+"&memid="+memid,
									beforeSend: function() {
										$('.list_class_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
									},  success: function(response){
										class_by_id(cid);
									}
								});
							}
							function add_member_to_class(memid) {
								var cid = '<?php echo $class_id; ?>';
								$.ajax({
									type: "POST",  
									url: "<?php print SITE_URL; ?>/z_process_class_member",  
									data: "addMember&cid="+cid+"&memid="+memid,
									beforeSend: function() {
										$('.list_class_members').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
									},  success: function(response){
										class_by_id(cid);
										$(".autosuggestions").html('');
										$("#newmember").val('');
										$("#newmember").focus();
									}
								});
							}
							function searchUser() {
								var fname = jQuery("#newmember").val();
								if(fname.length > 2) {
									jQuery.ajax({
										type: "POST",
										data: "list_users_by_name&fname="+fname,
										url: "<?php print SITE_URL; ?>/z_process_class_member",
										beforeSend: function() {},
										success: function(response) {
											$(".autosuggestions").html(response);
										}
									});
								} else {
									$(".autosuggestions").html('');
								}
							}
							</script>
					  </td>
                       
                    </tr>
                  </table>
                </form>
		
		<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Class Information Successfully Updated. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
			window.location.href="<?php print SITE_URL; ?>/update_class/<?php print $ACTION[1]; ?>/update_class";
		} else {
			window.location.href="<?php print SITE_URL; ?>/update_class/<?php print $ACTION[1]; ?>/update_class";
		}
		});
		</script>
		<?php } ?>
		<?php } else { ?>
		<?php notFoundMessage("The Class you are trying to view does not exist on this server. Please contact Website Administrator"); ?>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
