<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Financial Panel", $pageDescription);

?>

<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Quick Links</h3>
	<ul>
		<?php template_sidebar10(); ?>
	</ul>                   
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Financial Panel:</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">

	<div style="margin-bottom:15px;" align="center">
	
	<article style="width:65%;">
		<!-- Post content -->
		<div id="MainContent">
			<div style="font-size:35px;">Financial Panel:</div><br clear="all">
			<div style="font-size:18px;font-family:Times New Roman;line-height:25px">
				You are welcomed to the Financial Panel: page of this Church Management System.
				You are free to go through the various options that are available to your disposal 
				in order to generate reports that suite your need and requirement.<hr>
				The following are the formats in which you can export your data
				<br>
				<ul style="color:green;list-style:none">
					<li><img src="<?php print SITE_IMAGE_PATH; ?>/checked.gif"> PDF Format</li>
					<li><img src="<?php print SITE_IMAGE_PATH; ?>/checked.gif"> EXCEL Format</li>
					<li><img src="<?php print SITE_IMAGE_PATH; ?>/checked.gif"> HTML Format</li>
				</ul>
				<strong>NOTE</strong>: If you do not select any option the default 
				<strong>"HTML"</strong> will be selected by default.
				<hr>
				Use the quick links on the left side of this page to perform your duties.
			</div>
		</div>	
	</article>
	</div>	
</div>
</div>
</div>
</div>
<?php
template_footer();
?>
