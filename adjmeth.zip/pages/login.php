<?php

//include the header of the website
$pageDescription = $site->getSiteDescription();

//create a sessiono f the current page
$_SESSION['curpage_session'] = 'home';
$_SESSION['show_backgroundimage'] = 'show';

template_header($site->getSiteName(), $pageDescription);

$logoutGoTo = "dashboard";
if (!isset($_SESSION)) {
    session_start();
}

if (isset($_GET['logout'])) {
	$db->update("delete from adjmeth_sessions where sessions='{$_SESSION['theAdjMethAdminLoggedIn']}'");
    $_SESSION['AdjMethUsername'] = NULL;
    $_SESSION['aUserID'] = NULL;
    $_SESSION['Level'] = NULL;
    $_SESSION['User_Role'] = NULL;
    $_SESSION['LastAccess'] = NULL;
	$_SESSION['theAdjMethAdminLoggedIn'] = NULL;
	$_SESSION['FullName'] = NULL;		
	$_SESSION['Administrator'] = NULL;
	$_SESSION['theAdjMethAdminLoggedIns'] = NULL;
	
	unset($_SESSION['theAdjMethAdminLoggedIn']);
	unset($_SESSION['theAdjMethAdminLoggedIns']);
    unset($_SESSION['AdjMethUsername']);
    unset($_SESSION['aUserID']);
    unset($_SESSION['Level']);
    unset($_SESSION['User_Role']);
    unset($_SESSION['LastAccess']);   
	unset($_SESSION['FullName']);
    unset($_SESSION['Administrator']);
}

// *** Validate request to login to this site.
if (!isset($_SESSION)) {
    session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['reload'])) {
	print "<script>window.location.href='".SITE_URL."/login?logout_success'</script>";
} elseif (isset($_GET['expired']) and isset($_GET['true'])) {
	print "<script>window.location.href='".SITE_URL."/login?expired'</script>";
} else {
	$_SESSION['PrevUrl'] = $site->getSiteUrl()."/dashboard";
}

if (isset($_POST['Username'])) {
    $Username = stripslashes($_POST['Username']);
    $password = stripslashes($_POST['Password']);
    $cmsUserAuthorization = "Level";
    $cmsRedirectLoginFailed = "?error&";
    $cmsRedirectToReferer = true;
	
	//trim the information give by user
	$Username = $db->cleanData($Username);
	$Username = htmlspecialchars($Username);
	
	$password = $db->cleanData($password);
	
	//encrypt the password given by the user
	$actPassword = $password;
	//$actPassword = md5("LoggedInAdmin").$encryptedPassword;
	$actPassword = md5(sha1($actPassword));
	//print $actPassword;
	
	//make query
	$sql = $db->select("SELECT * FROM `adjmeth_admin` WHERE `Username`='$Username' AND `Password`='$actPassword' AND `activated`='1' and status='1'"); 
	$count = $db->scount($sql);
	
	$login_check = $sql->fetch_assoc();

	if( $count == 1 ){ 

		// Create the id session var
		$id = $login_check["id"];   
		$_SESSION['aUserID'] = $id;
			
		$username = $login_check["Username"];   
		$_SESSION['AdjMethUsername'] = $username;
			
		//getnerate the main session for the website
		$randNum = rand(9999, 999999999999);
		$_SESSION['theAdjMethAdminLoggedIn'] = $id.base64_encode("g4p3h9xfn8sq03hs2234$id").$randNum.time(); 

		$role = $login_check["Role"];   
		$_SESSION['User_Role'] = $role;
		
		if($role==2 || $role==1)
			$_SESSION['theAdjMethAdminLoggedIns'] = $randNum.time();
			
		$LastAccess = $login_check["LastAccess"];   
		$_SESSION['AdjMethLastAccess'] = $LastAccess;
			
		$FullName = $login_check["FullName"];   
		$_SESSION['AdjMethFullName'] = $FullName;
			
		$FirstName = $login_check["FirstName"];   
		$_SESSION['AdjMethFirstName'] = $FirstName;
		
		$Level = $login_check["Level"];   
		$_SESSION['Level'] = $role;
			
		$Administrator = $login_check["Role"];   
		$_SESSION['AdjMethAdministrator'] = $Administrator;
			
		//update the information
		$db->update("UPDATE `".TABLE_PREFIX."admin` SET `LastAccess`=now() WHERE id='$id'");
		$db->insert("insert into adjmeth_sessions (sessions) values ('{$_SESSION['theAdjMethAdminLoggedIn']}')");
		//redirect the user the success page
		print "<script>window.location.href='".SITE_URL."/dashboard'</script>";
	} else {
		print "<script>window.location.href='".SITE_URL."/login?error'</script>";
   }
} 

$pageTitle = "Sign In";
$cPageRedirect = str_ireplace(
		array("login","logout","logout_success"),
		array("dashboard","","login"), 
	$_SERVER['REQUEST_URI']);

?>
<script>
// validate signup form on keyup and submit
$("#login-form").validate({
	rules: {
		username: {
			required: true,
			minlength: 3
	},
		password: {
			required: true,
			minlength: 3
		}
	},
messages: {
	username: {
			required: "Please enter a username",
			minlength: "Your username must consist of at least 3 characters"
		},
		password: {
			required: "Please provide a password",
			minlength: "Your password must be at least 3 characters long"
		}
	}
});

</script>
	<?php if(!isset($ACTION[1])) { ?>
		<form action="<?php print SITE_URL; ?>/login" method="POST" id="login-form" class="cmxform" autocomplete="off">
		
			<fieldset>
				<?php if(isset($_GET['error']))  { ?>
					<div style="text-align:center" class="alert alert-danger error-box round">
						<strong>Invalid Username and / or Password</strong>
					</div>
				<?php } ?>
				<?php if(isset($_GET['expired']))  { ?>
					<div style="text-align:center" class="alert alert-danger error-box round">
						<strong>Sorry Session has Expired.</strong>
					</div>
				<?php } ?>
				<?php if(isset($_GET['logout_success']))  { ?>
					<div style="text-align:center" class="alert alert-success confirmation-box round">
						<strong>Successfully Logged out</strong>
					</div>
				<?php } ?>
				<p>
					<label>Username</label>
					<input type="text" id="login-username" required="required" class="round full-width-input" placeholder="Enter Username" name="Username" autofocus  />
				</p>
				<p>
					<label>Password</label>
					<input type="password" id="login-password" required="required" name="Password" placeholder="Enter Password" class="round full-width-input"  />
				</p>
				 <!-- login-intro -->
				<input type="submit" class="button round blue image-right ic-right-arrow" name="submit" value="LOG IN" />
				<input onclick="return needHelp();" type="button" class="button round red image-right" style="cursor:pointer" name="submit" value="NEED HELP?" />
			</fieldset>
			<br/>
      </form>
	  <?php } ?>
	  <?php if(isset($ACTION[1]) and $ACTION[1]=="username") { ?>
		<div id="login-form" class="cmxform">
			<center>
				<h1>FORGOTTEN USERNAME?</h1>
				<form id="login-form" class="cmxform" action="javascript:fetch_username();">
					<p>
						<input type="password" id="password" name="Password" placeholder="ENTER CURRENT PASSWORD" class="round full-width-input"  />
					</p>
					<p><strong>OR</strong></p>
					<P>
						<select name="question" onchange="showAnswerEntry();" id="question" class="round my_text_box" style="padding:5px;width:300px;height:35px">
							<option value="0">Select Secure Question</option>
							<?php
							$sql = $db->select("SELECT * FROM adjmeth_admin_questions");
							if($db->scount($sql) > 0) {
							while($res = $sql->fetch_assoc()) { ?>
							<option value="<?php print $res['id']; ?>"><?php print $res['question']; ?></option>
							<?php
								}
							}
							?>
						</select>
					</P>
					<p id="answerdiv">
						<input type="text" id="answer" name="answer" placeholder="ENTER ANSWER" class="round full-width-input"  />
					</p>
					<input type="submit" class="button round red image-right ic-right-arrow" name="submit" value="FETCH USERNAME" />
				</form>
				<div class="results"></div>
				<br><br><HR><br>
				<input onclick="return login();" type="submit" class="button round blue image-right ic-right-arrow" style="cursor:pointer" name="submit" value="LOG IN INSTEAD" />
			</center>
		</div>
		<script>
		$("#answerdiv").hide();
		function showAnswerEntry() {
			var quest = $("#question").val();
			if(quest==0) {
				$("#answer").val("");
				$("#answerdiv").slideUp();
			} else {
				$("#answer").focus();
				$("#answerdiv").slideDown();
			}
			$("#answer").focus();
		}
		
		function fetch_username() {
			var pass = $("#password").val();
			var quest = $("#question").val();
			var answer = $("#answer").val();
			
			$.ajax({
				type: "POST",
				data: "username&pass="+pass+"&quest="+quest+"&answer="+answer,
				url: "<?php print SITE_URL; ?>/z_forgotten",
				success: function(response) {
					$(".results").html(response);
				}
			})
		}
		</script>
	  <?php } ?>
	  <?php if(isset($ACTION[1]) and $ACTION[1]=="help") { ?>
		<div id="login-form" class="cmxform">
			<center>
				<h1>Select the option of your choice.</h1>
				
				<input onclick="return username();" type="button" class="button round red image-right" style="cursor:pointer" name="submit" value="FORGOTTEN USERNAME?" />
				<input onclick="return password();" type="button" class="button round blue image-right" style="cursor:pointer" name="submit" value="FORGOTTEN PASSWORD?" />
				<br><br><HR><br>
				<input onclick="return login();" type="submit" class="button round blue image-right ic-right-arrow" style="cursor:pointer" name="submit" value="LOG IN INSTEAD" />
			</center>
		</div>
	  <?php } ?>
	  
	  <script>
	  function needHelp() {
		  window.location.href='<?php print SITE_URL; ?>/login/help'; 
	  }
	  function login() {
		  window.location.href='<?php print SITE_URL; ?>/login'; 
	  }
	  function username() {
		  window.location.href='<?php print SITE_URL; ?>/login/username'; 
	  }
	  function password() {
		  window.location.href='<?php print SITE_URL; ?>/login/password'; 
	  }
	  </script>
<?php
//get the page footer to include
template_footer();
?>
