<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";
include_once 'core/utils/TimeStamp.php';
include_once 'core/utils/SimplePager.php';

//create new ago instance
$db = new Database();
$org = new OrganizationModel;
$res = new ResidenceModel;
$cla = new ClassModel;
$display_news_headlines = '';

//check if the form has been sent
if(isset($_POST['list_members'])) {
	
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$fquery = $db->select("SELECT * FROM `adjmeth_sunday_school_members` 
			WHERE 
				(fullname LIKE '%$search%' OR address LIKE '%$search%' OR 
				phone LIKE '%$search%' OR  m_class LIKE '%$search%') AND
				`status`='1' ORDER BY fullname ASC");
	}else {
		$fquery = $db->select("SELECT * FROM `adjmeth_sunday_school_members` WHERE `status`='1' ORDER BY fullname ASC");
	}
	$counter = $db->scount($fquery);
		
	//This is the number of contents to display on each page
	if(isset($_POST['limit']) and $_POST['limit'] > 0) {
		$rowsPerPage = $db->cleanData($_POST['limit']);
	} else {
		$rowsPerPage = LIMIT;
	}
	
	include_once 'core/utils/PagerController.php';
	
	//query the database based on the category parsed
	//by the administrator and limit the query by 10
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$query = $db->select("SELECT * FROM `adjmeth_sunday_school_members` 
					WHERE 
				(fullname LIKE '%$search%' OR address LIKE '%$search%' OR 
				phone LIKE '%$search%' OR m_class LIKE '%$search%') AND
				`status`='1' ORDER BY `fullname` ASC LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	} else {
		$query = $db->select("SELECT * FROM `adjmeth_sunday_school_members` 
					WHERE `status`='1' ORDER BY `fullname` ASC LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	}
?>
<table style="margin-top:10px">
		<tr>
			<th width="5%">No</th>
			<th>Fullname</th>
			<th>Contact</th>							
			<th>Class</th>
			<th>Edit /Delete</th>
            <th width="5%">Select</th>
		</tr>
<?php 		
	if($db->scount($query)) {
?>

<?php 		
	//using the while loop to display the data
	while($row = $query->fetch_assoc()) {
			
?>
	<tr>
   <td  width="5%"> <?php echo $row['id']; ?></td>

	<td><?php echo $row['fullname']; ?></td>
    <td> <?php echo $row['phone'];?></td>
    <td> <?php echo $row['m_class'];?></td>
	<td><a href="<?php print SITE_URL; ?>/update_sunday_school_member/<?php echo $row['studentid'];?>/view_sunday_school"	class="table-actions-button ic-table-edit"></a>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==2) { ?>
	<a  href="#" onclick="javascript:confirmSubmit(<?php echo $row['id'];?>,'adjmeth_sunday_school_members','view_sunday_school')" class="table-actions-button ic-table-delete"></a>
	<?php } ?>
	<a class="table-actions-button ic-print"  target="_blank" href="<?php print SITE_URL; ?>/print/sunday_school_member/<?php print $row['studentid']; ?>">
	</a>
	</td>
	<td width="5%"><input type="checkbox" value="<?php echo $row['id']; ?>" name="checklist[]" id="check_box" /></td>

</tr>		
<?php
	}

?>
</table>
<?php
	print '<br clear="all" />';
	print '<div style="color:#ff0000;font-size:15px;"><strong>'.$counter;
	print '</strong> Members Found. Showing Page <strong>'.$page.'</strong> of <strong>'.$pager->getTotalPages().'</strong></div>';
	print '<br clear="all" />';
?>
	<br clear="all" />
	<div class="row">
	<div style="" align="left"><?php print $paginate; ?></div>
	<br clear="all" />
	</div>
<?php	} else {
	
	?>
	<tr><td colspan="5" style="font-size:18px;">No results found</td></tr>
	<?php
}

}	
?>
