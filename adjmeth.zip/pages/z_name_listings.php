<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

//include the checkaccess file
if(isset($_POST["list_users_by_name"])) {
	if(isset($_POST["fname"])) {
		//clean name
		$fname=$db->cleanData($_POST["fname"]);
		
		$sql = $db->select("SELECT * FROM `adjmeth_members` WHERE `fullname` LIKE '%$fname%' LIMIT 10");
		print '<ul class="nav" id="side-menu">';
		if($db->scount($sql) > 0){
			while($row = $sql->fetch_assoc()){
				print '<li><a style="cursor:pointer" class="autolist" onclick="javascript:add_to_field(\''.$row['fullname'].'\',\''.$row['uniqueid'].'\');">'.ucwords($row["fullname"]).'</a></li>';
			}
		}
		print '</ul>';
	}
}
?>
