<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Add Pledge", $pageDescription);
?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		$("#redeem_date").jdPicker();
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				name: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				amount: {
					required: true,
					minlength: 2,
					maxlength: 250
				},
				redeem_date: {
					required: true,
					minlength: 10,
					maxlength: 250
				}
			}
		});
	
	});
	$(".counter").text("500 characters left");
	function remainingText() {		
		var text = $("#description").val();
		var num = text.length;
		var remain = 500 - num;
		if(remain < 1) {
			rem = "<span style='color:red'>"+(remain*-1)+" characters exceeded</span>";
		} else {
			rem = remain + " characters left";
		}
		$(".counter").html(rem);
	}
	function numbersonly(e){
		var unicode=e.charCode ? e.charCode : e.keyCode
		if (unicode!=8 && unicode!=46 && unicode!=37 && unicode!=38 && unicode!=39 && unicode!=40 && unicode!=9) { 
		//if the key isn't the backspace key (which we should allow)
		if (unicode<48||unicode>57)
			return false
		}
	}
	</script>
<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Harvest Management</h3>
	<ul>
		<?php pledges_sidebar(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Add Pledge</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">
	<?php include_once('core/controllers/process_harvest.php'); ?>
			<form name="form1" autocomplete="off" method="post" id="form1" action="">
                  <style>
					.table tr td {
						padding:5px!important;
						font-weight:bold;
					}
					</style>
                  <p><strong>Record Pledge </strong></p>
                  <table class="table"  border="0" style="margin:5px">
                    <tr>
                      <td width="15%"><span class="man">*</span>Member Name:</td>
                      <td>
						<input onkeyup="return searchUser();" name="name" placeholder="ENTER MEMBER NAME" type="text" id="mem_name" maxlength="200"  class="round default-width-input" value="<?php echo $name; ?>" />
						<div class="autosuggestions"></div>
					  </td>
					  <td valign="top" width="50%" style="border-left:1px solid #000" rowspan="8">
						<span style="font-weight:bold;font-size:20px;">
							PLEDGE HISTORIES:</span><hr>
						<div class="display_pledge_details"></div>
					  </td>
                    </tr>
					 <tr>
                      <td width="15%">Member UID:</td>
                      <td>
						<input name="mem_uid" placeholder="ENTER MEMBER UID" type="text" id="mem_uid" maxlength="200"  class="round default-width-input" value="<?php echo $mem_uid; ?>" />
					  </td>
                    </tr>
					<tr>
                      <td width="15%">Type:</td>
                      <td>
						<select onchange="return list_events();" name="evt_type" id="evt_type" class="round my_text_box" style="padding:5px;width:260px;height:35px;cursor:pointer;">
							<option value="NULL">PLEASE SELECT EVENT TYPE</option>
							<?php 
							$evt=$db->select("select * from adjmeth_finance_type");
							if($db->scount($evt)>0){
								while($res=$evt->fetch_assoc()){
									print "<option value='{$res["id"]}'>{$res["name"]}</option>";
								}
							}
							?>
						</select>
					  </td>
                    </tr>
					<tr>
                      <td>&nbsp;</td>
                      <td><div class="display_list"></div></td>
                    </tr>
					<tr>
                      <td>Redeem Date:</td>
                      <td><input name="redeem_date" onkeyup="return display_details();" onkeypress="return numbersonly(event);" placeholder="SELECT REDEEM DATE" type="text" id="redeem_date"  maxlength="200"  class="round default-width-input" value="<?php echo $redeem_date; ?>" /></td>
                    </tr>
					<tr>
                      <td>Amount:</td>
                      <td><input name="amount" onkeyup="return display_details();" onkeypress="return numbersonly(event);" placeholder="ENTER PLEDGE AMOUNT" type="text" id="amount"  maxlength="200"  class="round default-width-input" value="<?php echo $pamount; ?>" /></td>
                    </tr>
					
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr><tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
                        <input type="hidden" name="recordHarvestPledge">
						<input class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Add">
						<input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    </tr>
                  </table>
            </form>
			<script>
			function add_to_field(name,uid) {
				$("#mem_name").val(name);
				$("#mem_uid").val(uid);
				$(".autosuggestions").html('');
				$("#mem_uid").attr("readonly","readonly");
			}
			function list_events() {
				var evt_type = $("#evt_type").val();
				var mem_uid = $("#mem_uid").val();
				$.ajax({
					type: "POST",
					data: "display_list&evt_type="+evt_type+"&mem_uid="+mem_uid,
					url: "<?php print SITE_URL; ?>/z_events_listings",
					beforeSend: function() {},
					success: function(response) {
						$(".display_list").html(response);
					}
				});
			}
			function display_details() {}
			function searchUser() {
				var fname = $("#mem_name").val();
				if(fname.length > 2) {
					$.ajax({
						type: "POST",
						data: "list_users_by_name&fname="+fname,
						url: "<?php print SITE_URL; ?>/z_name_listings",
						beforeSend: function() {},
						success: function(response) {
							$(".autosuggestions").html(response);
						}
					});
				} else {
					$(".autosuggestions").html('');
					$("#mem_uid").val('');
					$("#mem_uid").removeAttr("readonly","");
				}
			}
			</script>
	<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Pledge Successfully Inserted. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
			window.location.href="<?php print SITE_URL; ?>/view_pledges";
		} else {
			window.location.href="<?php print SITE_URL; ?>/view_pledges";
		}
		});
		</script>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
