<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();
//call the template header function
template_header("Print", $pageDescription);
$tbl_count = new CountModel;
$member = new MemberModel;
$class = new ClassModel;
$org = new OrganizationModel;
?>
<link href="<?php print SITE_CSS_PATH; ?>/print.css" rel="stylesheet">
<link href="<?php print SITE_CSS_PATH; ?>/inilabs.css" rel="stylesheet">

<div>
	<div class="side-content border" style="width:95%;margin:auto auto">			
	<div class="content-module">
		<div class="content-module-heading cf">
		<span class="expand-collapse-text initial-expand">
			<a href="<?php print SITE_URL; ?>">HOME</a>
		</span>	
		<span class="fr expand-collapse-text initial-expand">
			<?php print SITE_NAME; ?> |
			<?php print date("l d M Y"); ?>
		</span>
		</div> <!-- end content-module-heading -->
		<div class="content-module-main cf">
			<h1 align="center" style="font-family:arial;font-size:26px;font-weight:bold;">
				<?php print SITE_NAME; ?></h1>
				<h1 align="center" style="font-family:arial;font-size:26px;font-weight:bold;">
				Accra North Circuit, Adjiringanor Society</h1>
			<?php if(isset($_GET['address'])) { ?>
				<h1 align="center" style="font-family:arial;font-size:20px;font-weight:bold;">ADDRESS DETAILS</h1>
			<?php } ?>
			<?php if(!isset($_GET['address'])) { ?>
				<h1 align="center" style="font-family:arial;font-size:20px;font-weight:bold;">MEMBER DETAILS</h1>
			<?php } ?>
			<?php 
			//initial values
			$query = "";
			$filter = "";
			//call the fetch data info from the database
			if(isset($_GET)) {
				//check if the class was set
				if(isset($_GET['print'])){
					//fetch every single file
					$exp = "/^[a-zA-Z]+$/";
					//set the initial query 
					$query = "select * from adjmeth_members where ";
					//check if the dayborn was set
					if(isset($_GET['d']) and preg_match($exp, $_GET['d']) and strlen($_GET['d']) > 2) {
						$query .= "and day_born='".ucwords($_GET['d'])."' ";
						$filter .= "<strong>Day Born: </strong>".ucwords($_GET['d'])." ";
					}
					//check if the monthborn was set
					if(isset($_GET['m']) and preg_match($exp, $_GET['m']) and strlen($_GET['m']) > 2) {
						$query .= "and month_born='".ucwords($_GET['m'])."' ";
						$filter .= "<strong>Month Born: </strong>".ucwords($_GET['m'])." ";
					}
					//check if the class was queried
					if(isset($_GET['c']) and is_numeric($_GET['c']) and $_GET['c'] > 0) {
						$query .= "and m_class='{$_GET['c']}' ";
						$filter .= "<strong>Organization: </strong>".$class->ClassById($_GET['c'],"id")->cname." | ";
					}
					//check if the gender was set
					if(isset($_GET['g']) and preg_match($exp, $_GET['g']) and strlen($_GET['g']) > 2) {
						$query .= "and gender='".ucwords($_GET['g'])."' ";
						$filter .= "<strong>Gender: </strong>".	ucwords($_GET['g'])." | ";
					}
					//check if the organization was queried
					if(isset($_GET['o']) and is_numeric($_GET['o']) and $_GET['o'] > 0) {
						$query .= "and organization='{$_GET['o']}' ";
						$filter .= "<strong>Organization: </strong>".$org->OrganizationById($_GET['o'],"id")->gname." | ";
					}
					//call the status column
					$query .="and status='1' ";
					//call other parameters
					//check if the class was queried
					if(isset($_GET['co']) and preg_match($exp, $_GET['co']) and strlen($_GET['co']) > 3) {
						$query .= "order by {$_GET['co']} ";
						$filter .= "<strong>Order By: </strong>".strtoupper($_GET['co'])." | ";
					} else {
						$query .= "order by fullname ";
						$filter .= "<strong>Order By: </strong>Surname | ";
					}
					if(isset($_GET['or']) and preg_match($exp, $_GET['or']) and strlen($_GET['or']) > 2) {
						$query .= "{$_GET['or']}";
					} else {
						$query .= "asc";
					}
					//FILTER THE QUERY STRING
					$query = str_replace("where and", "where", $query);	
					//process the query parse
					$sql = $db->select($query);
					//count the rows and fetch the total number of rows
					if($db->scount($sql) > 0) {
						print "<span style='color:#ff4000;font-weight:bold'> Filter By: </span>";
						print "<span style='padding:10px 0px 10px;width:500px;
							border-bottom:solid #000 2px;margin-bottom:15px;'>";
						print $filter;
						print "</span><br><br>";
					}
					?>
					<table style="margin-top:10px">	
					<tr align="left" style="background:#fff;color:#000">
						<th>ID</th>
						<?php if(!isset($_GET['address'])) { ?>
							<th>Surname</th>
							<th>Firstname</th>
							<th>Organization</th>
							<th>Class</th>
							<th>Date of Birth</th>
							<th>Day Born</th>							
							<th>Gender</th>
							<th>Occupation</th>
						<?php } elseif(isset($_GET['address'])) { ?>
							<th>Fullname</th>
							<th>Residence</th>
							<th>Contact</th>
							<th>Email Address</th>
							<th>Postal Address</th>
						<?php } ?>
					</tr>
					<?php if($db->scount($sql) > 0) { ?>
					<?php 		
						//using the while loop to display the data
						while($row = $sql->fetch_assoc()) {
								
					?>
					<tr align="left">
						<td> <?php echo $row['uniqueid']; ?></td>
						<?php if(!isset($_GET['address'])) { ?>
							<td><?php echo $row['lname']; ?></td>
							<td><?php echo $row['fname']; ?></td>
							<td> <?php echo $org->OrganizationById($row['organization'],"id")->gname;?>
							 / <?php echo $org->OrganizationById($row['suborganization'],"id")->gname;?></td>
							<td> <?php echo $class->ClassById($row['m_class'],"id")->cname;;?></td>
							<td><?php echo $row['dob']; ?></td>
							<td><?php echo $row['day_born']; ?></td>
							<td><?php echo $row['gender']; ?></td>
							<td><?php echo $row['occupation']; ?></td>
						<?php } elseif(isset($_GET['address'])) { ?>
							<td><?php echo $row['fullname']; ?></td>
							<td><?php echo $row['residence']; ?></td>
							<td> <?php echo $row['phone'];?> / <?php echo $row['phone1'];?></td>
							<td><?php echo $row['email']; ?></td>
							<td><?php echo $row['address']; ?></td>
						<?php } ?>
					</tr>
					<?php
						}
					?>
					<?php }	?>
					</table>
					
					<?php 
						print '<br clear="all" />';
						print '<div style="color:#ff0000;font-size:15px;"><strong>'.$db->scount($sql);
						print '</strong> Members found for the above filtration</div>';
						print '<br clear="all" />';
					?>
					<?php
				}
			}
			?>
			
			<script>
				//window.print();
				//window.close();
			</script>
			<div style="margin-bottom:15px;" align="center">
			<hr style="margin-top:20px;">
			<div style="margin-top:20px;" align="right">
				<?php print SITE_NAME ." - ". $_SERVER['REQUEST_URI'] ." - ". date("l d M Y, H:ia"); ?>
			</div>
		</div>
		
		</div>
	</div>
	</div>
</div>
<?php
template_footer();
?>
