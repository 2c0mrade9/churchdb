<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Add Harvest", $pageDescription);
?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		
		$('#harv_date').jdPicker();
		
		$("#ministry").autocomplete("<?php print SITE_URL; ?>/z_fetch_ministry_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				name: {
					required: true,
					minlength: 3,
					maxlength: 200
				},
				description: {
					required: true,
					minlength: 3,
					maxlength: 250
				},
				amount: {
					required: true,
					minlength: 2,
					maxlength: 250
				},
				harv_date: {
					required: true,
					minlength: 10,
					maxlength: 250
				}
			}
		});
	
	});
	$(".counter").text("500 characters left");
	function remainingText() {		
		var text = $("#description").val();
		var num = text.length;
		var remain = 500 - num;
		if(remain < 1) {
			rem = "<span style='color:red'>"+(remain*-1)+" characters exceeded</span>";
		} else {
			rem = remain + " characters left";
		}
		$(".counter").html(rem);
	}
	function numbersonly(e){
		var unicode=e.charCode ? e.charCode : e.keyCode
		if (unicode!=8 && unicode!=46 && unicode!=37 && unicode!=38 && unicode!=39 && unicode!=40 && unicode!=9) { 
		//if the key isn't the backspace key (which we should allow)
		if (unicode<48||unicode>57)
			return false
		}
	}
	</script>
<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Harvest Management</h3>
	<ul>
		<?php harvest_sidebar(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Add Harvest</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf">
	<?php include_once('core/controllers/process_harvest.php'); ?>
			<form name="form1" autocomplete="off" method="post" id="form1" action="">
                  <style>
					.table tr td {
						padding:5px!important;
						font-weight:bold;
					}
					</style>
                  <p><strong>Add New Havest Record </strong></p>
                  <table class="table"  border="0" style="margin:5px">
                    <tr>
                      <td width="15%"><span class="man">*</span>Harvest Name:</td>
                      <td><input name="name" placeholder="ENTER HARVEST NAME" type="text" id="name" maxlength="200"  class="round default-width-input" value="<?php echo $name; ?>" /></td>
                    </tr>
					<tr>
                      <td width="15%">Type:</td>
                      <td>
						<select name="harv_type" id="harv_type" class="round my_text_box" style="padding:5px;width:220px;height:35px;cursor:pointer;">
							<option value="NULL">Please select harvest type</option>
							<option value="Mini">Mini Harvest</option>
							<option value="Main">Main Harvest</option>
						</select>
					  </td>
                    </tr>
					<tr>
                      <td>Harvest Date:</td>
                      <td><input name="harv_date" placeholder="SELECT HARVEST DATE" type="text" id="harv_date"  maxlength="200"  class="round default-width-input" value="<?php echo $harv_date; ?>" /></td>
                    </tr>
					<tr>
                      <td>Amount:</td>
                      <td><input name="amount" onkeypress="return numbersonly(event)" placeholder="SELECT HARVEST AMOUNT" type="text" id="amount"  maxlength="200"  class="round default-width-input" value="<?php echo $amount; ?>" /></td>
                    </tr>
					<tr>
                      <td>Pledges:</td>
                      <td><input name="pledges" onkeypress="return numbersonly(event)" placeholder="SELECT HARVEST PLEDGES" type="text" id="pledges"  maxlength="200"  class="round default-width-input" value="<?php echo $pledges; ?>" /></td>
                    </tr>
					
                    <tr>
                      <td valign="top">Description</td>
                      <td><textarea style="width:400px;" name="description" id="description" onkeyup="return remainingText();" placeholder="ENTER DESCRIPTION" cols="10" maxlength="500" class="round full-width-textarea"><?php echo $description; ?></textarea>
					  <div class="counter"></div></td>
                    </tr>
					
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    
                    
                    <tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
                        <input type="hidden" name="recordHarvest">
						<input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Add">
						<input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    </tr>
                  </table>
            </form>
	<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Harvest Successfully Inserted. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
			window.location.href="<?php print SITE_URL; ?>/view_harvest";
		} else {
			window.location.href="<?php print SITE_URL; ?>/view_harvest";
		}
		});
		</script>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
