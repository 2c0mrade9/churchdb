<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

include_once 'core/utils/TimeStamp.php';
include_once 'core/utils/SimplePager.php';

//create new ago instance
$db = new Database();
$sup = new SupplierModel;
$display_news_headlines = '';

//check if the form has been sent
if(isset($_POST['list_products'])) {
	
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$fquery = $db->select("SELECT * FROM `adjmeth_stock` 
			WHERE 
				stock_name LIKE '%$search%' OR stock_id LIKE '%$search%' OR 
				supplier_id LIKE '%$search%' OR 
				company_price LIKE '%$search%' OR 
				selling_price LIKE '%$search%' OR 
				date  LIKE '%$search%' AND
				`status`='1'");
	}else {
		$fquery = $db->select("SELECT * FROM `adjmeth_stock` WHERE `status`='1'");
	}
	$counter = $db->scount($fquery);
		
	//This is the number of contents to display on each page
	if(isset($_POST['limit']) and $_POST['limit'] > 0) {
		$rowsPerPage = $db->cleanData($_POST['limit']);
	} else {
		$rowsPerPage = LIMIT;
	}
	
	include_once 'core/utils/PagerController.php';
	
	//query the database based on the category parsed
	//by the administrator and limit the query by 10
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$query = $db->select("SELECT * FROM `adjmeth_stock` 
					WHERE 
				stock_name LIKE '%$search%' OR stock_id LIKE '%$search%' OR 
				supplier_id LIKE '%$search%' OR 
				company_price LIKE '%$search%' OR 
				selling_price LIKE '%$search%' OR 
				date  LIKE '%$search%' AND
				`status`='1' ORDER BY `id` DESC LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	} else {
		$query = $db->select("SELECT * FROM `adjmeth_stock` 
					WHERE `status`='1' ORDER BY `id` DESC LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	}
?>	
<table style="margin-top:10px">
		<tr>
			<th>No</th>
			<th>Stock Name</th>
			<th>Stock Id</th>
			<th>Date</th>							
			<th>Supplier</th>
			<th>Selling Price</th>
			<th>Stock</th>
			<th>Edit /Delete</th>
			<th>Select</th>
		</tr>
<?php
	if($db->scount($query)) {
?>

<?php 		
	//using the while loop to display the data
	while($row = $query->fetch_assoc()) {
	
		$whenPosted = RelativeTimeCommented($row['date']);		
?>
	<tr>
   <td width="3%"> <?php echo $row['id']; ?></td>

   <td><?php echo $row['stock_name']; ?></td>
      <td> <?php echo $row['stock_id'];?></td>
      <td> <?php echo $row['date'];?></td>
   <td> <?php echo $sup->supplierById($row['supplier_id'], "id","null")->supname; ?></td>
   <td> <?php echo $row['selling_price']; ?></td>
   <td> <?php $quan=$db->select("SELECT quantity FROM stock_avail WHERE palias='".$row['stock_id']."'");
	if($db->scount($quan) > 0) { 
		$res=$quan->fetch_assoc();
		print $res['quantity'];
	}else {
		print 0;
	}?></td>

    <td>
	<a href="<?php print SITE_URL; ?>/update_stock/<?php echo $row['stock_id'];?>/view_product"	class="table-actions-button ic-table-edit"></a>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==2) { ?>
	<a  href="#" onclick="javascript:confirmSubmit(<?php echo $row['id'];?>,'stock_details','view_product')" class="table-actions-button ic-table-delete"></a>	
    <?php } ?>
	</td>
	<td width="5%"><input type="checkbox" value="<?php echo $row['id']; ?>" name="checklist[]" id="check_box" /></td>

</tr>		
<?php
	}

?>
</table>
<?php
	print '<br clear="all" />';
	print '<div style="color:#ff0000;font-size:15px;"><strong>'.$counter;
	print '</strong> Products Found. Showing Page <strong>'.$page.'</strong> of <strong>'.$pager->getTotalPages().'</strong></div>';
	print '<br clear="all" />';
?>
	<br clear="all" />
	<div class="row">
	<div style="" align="left"><?php print $paginate; ?></div>
	<br clear="all" />
	</div>
<?php	} else {
	?>
	<tr><td colspan="5" style="font-size:18px;">No results found</td></tr>
<?php
}

}	
?>