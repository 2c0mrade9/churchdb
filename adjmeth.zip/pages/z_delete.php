<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";
//check if its the administrator who is logged in
if(!isset($_SESSION['theAdjMethAdminLoggedIns'])) {
	print "Sorry! You dont have permission to perform this action.";
	exit;
}
//delete file
if(isset($_POST['pid']) and isset($_POST['table'])) {
	$id= $db->cleanData($_POST['pid']);
	$tablename= $db->cleanData($_POST['table']);
	$return= $db->cleanData($_POST['return']);
	$time = date("d-m-Y H:i:s");
	$uname = $_SESSION['AdjMethUsername'];
	
	$tablename = str_ireplace(array("adjmeth","__"), array("adjmeth_","_"), $tablename);
	
	$db->update("UPDATE $tablename SET status='0', deleted_details='by $uname - $time' WHERE id=$id");

	print "Item has been successfully deleted";

}
if(isset($_POST['table']) && isset($_POST['checklist'])) {
	$data=$_POST['checklist'];
	$tablename=$_POST['table'];
	$return =$_POST['return'];
	$time = date("d-m-Y H:i:s");
	$uname =$_SESSION['AdjMethUsername'];

	$tablename = str_ireplace(array("adjmeth","__"), array("adjmeth_","_"), $tablename);
	
	for($i=0;$i<count($data);$i++){
		$db->update("UPDATE $tablename SET status='0',deleted_details='by $uname - $time' WHERE id=$data[$i]");
	}
	
	print "List of Items has been successfully deleted";
}
?>
