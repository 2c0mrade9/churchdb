<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();
//call the template header function
template_header("Print", $pageDescription);
$tbl_count = new CountModel;
$member = new MemberModel;
$class = new ClassModel;
$org = new OrganizationModel;

error_reporting(0);
?>
<link href="<?php print SITE_CSS_PATH; ?>/print.css" rel="stylesheet">
<link href="<?php print SITE_CSS_PATH; ?>/inilabs.css" rel="stylesheet">

<div class="page-full-width cf">
	<div class="side-content border" style="margin:auto auto">			
	<div class="content-module">
		<div class="content-module-heading cf">
		<span class="expand-collapse-text initial-expand">
			<a href="<?php print SITE_URL; ?>">HOME</a>
		</span>	
		<span class="fr expand-collapse-text initial-expand">
			<?php print SITE_NAME; ?> |
			<?php print date("l d M Y"); ?>
		</span>
		</div> <!-- end content-module-heading -->
		<div class="content-module-main cf">
		
		<?php if(isset($ACTION[2]) and $member->MemberById($ACTION[2])->found == true) { ?>
		
			<div style="margin-bottom:15px;" align="center">
			<h1 align="center" style="font-family:arial;font-size:26px;font-weight:bold;">
				<?php print SITE_NAME; ?></h1>
				<h1 align="center" style="font-family:arial;font-size:26px;font-weight:bold;">
				Accra North Circuit, Adjiringanor Society</h1>
				<h1 style="font-family:arial;font-size:20px;font-weight:bold;">MEMBERSHIP DIRECTORY</h1>
				<article style="width:100%;">
					<!-- Post content -->
					<div id="MainContent">
						
					<div id="printablediv">
					<section class="panel">
						<div class="profile-view-head bg-blue">
							<a href="#"><?php print $member->MemberById($ACTION[1])->mem_image; ?></a>
							<h1><?php print $member->MemberById($ACTION[2])->mem_fulln; ?></h1>
							<p><?php print $member->MemberById($ACTION[2])->mem_nclass; ?></p>
						</div>
						<div class="panel-body profile-view-dis" style="color:#000;font-size:14px;
									background:#fff;">
							<table border="1" width="90%" style="margin:auto auto;">
							<tr>
								<td>
								<style>
								span {font-weight:bold}
								</style>
								<h1  style="color:green">PERSONAL INFORMATION</h1>
								 <div class="profile-view-tab">
									<span>Member ID</span>: <?php print $member->MemberById($ACTION[2])->mem_id; ?>
								</div>
								<div class="profile-view-tab">
									<span>Date of Birth </span>: <?php print $member->MemberById($ACTION[2])->mem_dob1; ?>
								</div>
								<div class="profile-view-tab">
									<span>Day Born </span>: <?php print date("l", strtotime($member->MemberById($ACTION[2])->mem_dob1)); ?>
								</div>
								<div class="profile-view-tab">
									<span>Contact 1 </span>: <?php print $member->MemberById($ACTION[2])->mem_phone; ?>
								</div>
								<div class="profile-view-tab">
									<span>Contact 2 </span>: <?php print $member->MemberById($ACTION[2])->mem_phone1; ?>
								</div>
								<div class="profile-view-tab">
									<span>Gender </span>: <?php print $member->MemberById($ACTION[2])->mem_gender; ?>
								
								</div>
								</td>
								<td width="50%" valign="top">
									<h1 style="color:green">OTHER INFORMATION</h1>
									<div class="profile-view-tab">
										<span>Occupation</span>: <?php print $member->MemberById($ACTION[2])->mem_occup; ?>
									</div>
									<div class="profile-view-tab">
										<span>Place of Abode</span>: <?php print $member->MemberById($ACTION[2])->mem_res; ?>
									</div>
									<div class="profile-view-tab">
										<span>Postal Address</span>: <?php print $member->MemberById($ACTION[2])->mem_add; ?>
									</div>
									<div class="profile-view-tab">
										<span>Email Address</span>: <?php print $member->MemberById($ACTION[2])->mem_email; ?>
									</div>
									<div class="profile-view-tab">
										<span>Date Joining</span>: <?php print $member->MemberById($ACTION[2])->mem_join; ?>
									</div>
								</td>
							</tr>
							<tr>
								<td valign="top">
									<h1  style="color:green">CLASS DETAILS</h1>
									<div class="profile-view-tab">
										<span>Class</span>: <?php print $member->MemberById($ACTION[2])->mem_nclass; ?>
									</div>
									<div class="profile-view-tab">
										<span>Class Leader</span>: <?php print $class->ClassById($member->MemberById($ACTION[2])->mem_class, "id")->cleader; ?>
									</div>
									<div class="profile-view-tab">
										<span>Assist Class Leader</span>: <?php print $class->ClassById($member->MemberById($ACTION[2])->mem_class, "id")->acleader; ?>
									</div>
									<div class="profile-view-tab">
										<span>Class Secretary</span>: <?php print $class->ClassById($member->MemberById($ACTION[2])->mem_class, "id")->csecretary; ?>
									</div>
								</td>
								<td valign="top">
									<h1  style="color:green">ORGANIZATION DETAILS</h1>
									<div class="profile-view-tab">
										<span>Main Organization</span>: <?php print $org->OrganizationById($member->MemberById($ACTION[2])->mem_org1, "id")->gname; ?>
									</div>
									<div class="profile-view-tab">
										<span>Other Organization</span>: <?php print $org->OrganizationById($member->MemberById($ACTION[2])->mem_sorg1, "id")->gname; ?>
									</div>
								</td>
							</tr>
							</table>
							<div align="right">
								<?php print SITE_NAME ." - ". $_SERVER['REQUEST_URI'] ." - ". date("l d M Y, H:ia"); ?>
							</div>
						</div>
					</section>
				</div>
						
					</div>	
				</article>
			</div>	
			<script>
				//window.print();
				//window.close();
			</script>
		<?php } else { ?>
		<div style="margin-bottom:15px;" align="center">
			<?php notFoundMessage("The Member you are trying to view does not exist on this server. Please contact Website Administrator"); ?>
			<hr>
			<div align="right">
				<?php print SITE_NAME ." - ". $_SERVER['REQUEST_URI'] ." - ". date("l d M Y, H:ia"); ?>
			</div>
		</div>
		<?php } ?>
			
			
		</div>
	</div>
	</div>
</div>
<?php
template_footer();
?>
