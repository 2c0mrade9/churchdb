<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Update System Information", $pageDescription);
$tbl_count = new CountModel;
?>

<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>System Management</h3>
	<ul>
		<?php template_sidebar(); ?>
	</ul>                   
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Update System Information</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
		<?php include_once 'core/controllers/update_settings.php'; ?>
		<div class="content-module-main cf">
			<form action="<?php print SITE_URL; ?>/update_details" role="form" method="post" enctype="multipart/form-data">
               <table class="content_pane" align="center" border="1" cellpadding="4" cellspacing="0">
               
               	<tbody><tr style="background:#f1f1f1">
                   <td class="page_title"><label>Edit Site Information </label></td>
                   </tr>
                    <tr>
                       <td class="newsContent">
                       	<div class="cms-pages" style="width:100%; padding:20px;">
                       	  <div class="pages-block"> </div>
						  <?php if ( isset($_GET['msg'])) { ?>
							
						<?php } ?>
                       	  <div>
								<style>
								label {font-weight:bold}
								input,textarea {border:solid 1px #cccccc!important;}
								input:hover,textarea:hover {border:solid 1px #000!important;}
								</style>
                                 <table width="100%" border="0" cellpadding="5" cellspacing="5">
                                   <tr valign="baseline">
                                       <td colspan="2" class="sectionTitle3" style="color: #000" align="left" nowrap="nowrap" valign="middle">
                                          <label> SITE DEFINITION  </label>
										</td>
                                   </tr>
									<tr>
                                     <td width="26%" align="right" valign="top" class="sectionTitle1">&nbsp;</td>
                                     <td width="">&nbsp;</td>
                                   </tr>
                                   <tr>
                                     <td align="right" valign="top">
										<div class="form-group"><span class="sectionTitle1"><label>Site Name:</label> </span></div></td>
                                     <td><input name="SiteName" type="text" class="round default-width-input" value="<?php print $site->getSiteName(); ?>" size="40"></td>
                                   </tr>
                                    <tr>
                                     <td align="right" valign="top"><span class="sectionTitle1"><label>Site Slogan:</label></span></td>
                                     <td><input name="SiteSlogan" type="text" class="round default-width-input" id="SiteSlogan" value="<?php print $site->getSiteSlogan(); ?>" size="50" maxlength="255"></td>
                                   </tr>
                                   <tr>
                                     <td align="right" valign="top"><span class="sectionTitle1"><label>Site Email: </label> </span></td>
                                     <td><input name="SiteEmail" type="text" class="round default-width-input" id="SiteEmail" value="<?php print stripslashes($site->getSiteEmail()); ?>" size="40"></td>
                                   </tr>
                                   <tr>
                                     <td align="right" valign="top"><span class="sectionTitle1"><label>Address: </label></span></td>
                                     <td><textarea name="SiteAddress" cols="40" rows="5" class="round default-width-textarea" id="SiteAddress"><?php print stripslashes($site->getSiteAddress()); ?></textarea></td>
                                   </tr>
                                   <tr>
                                     <td align="right" valign="top"><span class="sectionTitle1"><label>Contact Number(s): Mob </label></span></td>
                                     <td><input name="SitePhone" type="text" class="round default-width-input" id="SitePhone" value="<?php print $site->getSitePhone(); ?>" size="40"></td>
                                   </tr>
                                  
                                   <tr>
                                     <td colspan="2" align="right" valign="top">&nbsp;</td>
                                   </tr>
                                 </table>
							  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
							<tbody><tr valign="baseline">
                       <td colspan="2" class="sectionTitle3" style="color: #333" align="left" nowrap="nowrap" valign="top">
                          <label>Site Customisation  </label>                      </td>
                                   </tr>
                     <tr valign="baseline">
                         <td  width="30%" class="sectionTitle1" align="right" nowrap="nowrap" valign="top">&nbsp;</td>
                         <td>&nbsp;</td>
                     </tr>
                     <tr valign="baseline">
                         <td align="right" nowrap="nowrap" valign="top" width="184">
                             <span class="sectionTitle1"><label>Site Description:</label></span><br>
                         <span class="small"><label>(Used By Meta Data)</label></span>                          </td>
                         <td width="">
                         <textarea name="SiteDescription" id="SiteDescription" cols="50" rows="5" class="round default-width-textarea" style=""><?php print $site->getMetaDescription(); ?></textarea>                          </td>
                     </tr>
                     <tr valign="baseline">
                         <td align="right" nowrap="nowrap" valign="top">
                             <span class="sectionTitle1"><label>Site Keywords:</label></span><br>
                             <span class="small"><label>(Used By Meta Data)</label></span>                          </td>
                         <td>
                             <textarea name="SiteKeywords" cols="50" rows="5" class="round default-width-textarea" id="SiteKeywords" style=""><?php print stripslashes($site->getSiteKeyWords()); ?></textarea>                          </td>
                     </tr>
                     <tr valign="baseline">
                         <td class="sectionTitle1" align="right" nowrap="nowrap" valign="top"> <p><label>Search Engine Optimization:</label> <br>
                             <span class="small">(Add script code and link</span>
                           <br>
			<span class="small">as they appear here)</span> </p></td>
                         <td><textarea name="seo" cols="70" rows="8" class="round default-width-textarea" id="seo" style=""><?php print stripslashes($site->getSiteSEO()); ?></textarea></td>
                     </tr>
                     <tr valign="baseline">
                         <td colspan="2" align="center" nowrap="nowrap" valign="middle">&nbsp;                          </td>
                     </tr>
                     <tr valign="baseline">
                         <td colspan="2" align="center" nowrap="nowrap" valign="middle">
                        <input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Update">
						<input class="button round red   text-upper"  type="reset" name="Reset" value="Reset">
				  </tr>
                 </tbody>
               </table>
                      	  </div>
                         </div> 
						</td>
                   </tr>
               </tbody></table>
			 </form>  
		</div>
	</div>
	</div>
</div>
<?php
template_footer();
?>
