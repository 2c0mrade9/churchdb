<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

//include the checkaccess file
if(isset($_POST["display_list"])) {
	if(isset($_POST["evt_type"])) {
		//clean name
		$evt_type=$db->cleanData($_POST["evt_type"]);
		$mem_uid=$db->cleanData($_POST["mem_uid"]);
		
		$sql = $db->select("SELECT * FROM `adjmeth_finance` WHERE `typeid`='$evt_type' and typename!='redeem-pledge' order by fulldate desc");
		print '<select onchange="return display_details();" id="evt_type_sub" name="evt_type_sub" style="padding:5px;width:260px;height:35px;cursor:pointer;">';
		if($db->scount($sql) > 0){
			while($row = $sql->fetch_assoc()){
				print '<option value="'.$row["trancid"].'">
					'.ucwords($row["name_of"]).'
					(
						'.date("F",strtotime($row["fulldate"])).'
						'.date("Y",strtotime($row["fulldate"])).'
					)</option>';
			}
		} else {
			//fetch the right name
			$sql2 = $db->select("SELECT * FROM `adjmeth_finance_type` WHERE `id`='$evt_type'");
			//using the while loop to fetch the information
			if($db->scount($sql2) == 1) {
				//using fetch_assoc to get information
				$result=$sql2->fetch_assoc();
				//assign variable
				$res_name=$result["name"];
				
				//continue to get the right id
				$sql3 = $db->select("SELECT * FROM 
					`adjmeth_finance_pledge` WHERE 
					mem_uid='$mem_uid' and `event_name`='$res_name'");
				//using the counter
				if($db->scount($sql3)==1){
					//using the fetch_assoc to get information
					$result2=$sql3->fetch_assoc();
					//assign variables
					$evt_type=$result2["trancid"];
					//print out the name of the events
					print '<option value="'.$evt_type.'">
					'.$res_name.'
					</option>';
				}
			
			}
			
		}
		print '</select>';
	}
}
?>
<script>
display_details();
</script>
