<?php
//include the checkaccess file
include_once "core/checkaccess.php";
//include the header of the website
$pageDescription = $site->getSiteDescription();

template_header("Add Class", $pageDescription);
$tbl_count = new CountModel;

?>
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/date_input.css">
<link rel="stylesheet" href="<?php print SITE_ASSETS_PATH; ?>/lib/auto/css/jquery.autocomplete.css">
<script src="<?php print SITE_ASSETS_PATH; ?>/js/script.js"></script>
<script src="<?php print SITE_ASSETS_PATH; ?>/js/date_pic/jquery.date_input.js"></script>  
<script src="<?php print SITE_ASSETS_PATH; ?>/lib/auto/js/jquery.autocomplete.js "></script> 
<script>
	/*$.validator.setDefaults({
		submitHandler: function() { alert("submitted!"); }
	});*/
	$(document).ready(function() {
		
		$("#csecretary").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#acleader").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		$("#cleader").autocomplete("<?php print SITE_URL; ?>/z_fetch_members_list", {
			width: 220,
			autoFill: true,
			selectFirst: true
		});
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				cname: {
					required: true,
					minlength: 3,
					maxlength: 200
				}
			},
			messages: {
				cname: {
					required: "Please Enter Classname",
					minlength: "Classname must consist of at least 3 characters"
				}
			}
		});
	});
</script>


<div class="page-full-width cf">

	<div class="side-menu fl border">

	<h3>Class Management</h3>
	<ul>
		<?php template_sidebar3(); ?>
	</ul>                         
	</div> <!-- end side-menu -->
	<div class="side-content fr border">			
	<div class="content-module">
				
		<div class="content-module-heading cf">
		<h3 class="fl">Add Class</h3>
		<span class="fr expand-collapse-text">Click to collapse</span>
		<span class="fr expand-collapse-text initial-expand">Click to expand</span>
		</div> <!-- end content-module-heading -->
			
	<div class="content-module-main cf" >
		<?php include_once('core/controllers/insert_class.php'); ?>
		<form name="form1" method="post" id="form1" action="">
                  
					<style>
					.form tr td {
						padding:5px!important;
						font-weight:bold;
					}
					</style>
                  <table class="form" border="0" width="100%" cellspacing="10px" cellpadding="5px">
					<tr>
                      <td><span class="man">*</span>Class Name:</td>
                      <td><input name="cname" placeholder="ENTER CLASSNAME" type="text" id="cname"  maxlength="200"  class="round default-width-input" value="<?php echo $cname; ?>" /></td>
                       
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                       
                    </tr>
					
					<tr>
                      <td>Class Leader:</td>
                      <td><input name="cleader" placeholder="ENTER CLASS LEADER" type="text" id="cleader"  maxlength="200"  class="round default-width-input" value="<?php echo $cleader; ?>" /></td>
                       
					  <td>Assist Class Leaders:</td>
                      <td><input name="acleader" placeholder="ENTER ASSIST CLASS LEADER" type="text" id="acleader"  maxlength="200"  class="round default-width-input" value="<?php echo $acleader; ?>" /></td>
                       
                    </tr>
					<tr>
                      <td>Class Secretary:</td>
                      <td><input name="csecretary" placeholder="ENTER CLASS SECRETARY" type="text" id="csecretary"  maxlength="200"  class="round default-width-input" value="<?php echo $csecretary; ?>" /></td>
                       
					  <td>&nbsp;</td>
                      <td>&nbsp;</td>
					  
                    </tr>
					
					
					<tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
					  <td>&nbsp;</td>
					  <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>
					 &nbsp;
					  </td>
                      <td>
                        <input  class="button round blue image-right ic-add text-upper" type="submit" name="Submit" value="Add">
			<td align="right"><input class="button round red   text-upper"  type="reset" name="Reset" value="Reset"> </td>
                    </tr>
                  </table>
                </form>
		
		<?php if(isset($_GET['success'])) { ?>
		<script  src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.ui.draggable.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.js"></script>
		<script src="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.js"></script>
		<link rel="stylesheet"  href="<?php print SITE_ASSETS_PATH; ?>/dist/js/jquery.alerts.css" >
		<script type="text/javascript">
		jConfirm('Class Successfully Inserted. Do you still wish to continue?', 'Confirmation', function (r) {
       		if(r){ 				
				window.location.href="<?php print SITE_URL; ?>/add_class";
			} else {
				window.location.href="<?php print SITE_URL; ?>/add_class";
			}
		});
		</script>
		<?php } ?>
	</div>
</div>	
</div></div>
<?php
template_footer();
?>
