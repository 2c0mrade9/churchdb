<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";

include_once 'core/utils/TimeStamp.php';
include_once 'core/utils/SimplePager.php';

//create new ago instance
$db = new Database;
$org = new OrganizationModel;
$tbl_count = new CountModel;
$display_news_headlines = '';

//check if the form has been sent
if(isset($_POST['list_pledges'])) {
	//check if the current page number has been sent
	if(isset($_POST['cpage']))
		$current_page = $_POST['cpage'];
	else
		$current_page = '1';
	
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$fquery = $db->select("SELECT * FROM `adjmeth_finance_pledge` 
			WHERE mem_name LIKE '%$search%' OR event_name LIKE '%$search%' AND status='1'");
	}else {
		$fquery = $db->select("SELECT * FROM `adjmeth_finance_pledge` WHERE status='1'");
	}
	$counter = $db->scount($fquery);
		
	//This is the number of contents to display on each page
	if(isset($_POST['limit']) and $_POST['limit'] > 0) {
		$rowsPerPage = $db->cleanData($_POST['limit']);
	} else {
		$rowsPerPage = LIMIT;
	}
	
	include_once 'core/utils/PagerController.php';
	
	//query the database based on the category parsed
	//by the administrator and limit the query by 10
	if(isset($_POST['search'])) {
		$search = $db->cleanData($_POST['search']);
		$query = $db->select("SELECT * FROM `adjmeth_finance_pledge` 
					WHERE mem_name LIKE '%$search%' OR event_name LIKE '%$search%' AND status='1'
				ORDER BY `id` desc LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	} else {
		$query = $db->select("SELECT * FROM `adjmeth_finance_pledge` WHERE status='1' ORDER BY `id` desc LIMIT " . $pager->getStartRow() . ", " . $rowsPerPage );
	}
?>
<table style="margin-top:10px">
		<tr>
			<th>Member Name</th>
			<th>Event</th>
			<th>Amount Pledged</th>
			<th>Balance</th>
			<th>Redeem Date</th>
			<th>Edit/Delete</th>
		</tr>
							
		<?php
	if($db->scount($query)) {
?>

	
<?php 		
	//using the while loop to display the data
	while($row = $query->fetch_assoc()) {
	
?>

<tr>
	<td width="17%"><?php echo $row['mem_name']; ?></td>
	<td width="24%"><?php echo $row["event_name"];?></td>
	<td><?php echo "GHc".$row["amount"];?></td>
	<td><?php echo "GHc".$row["balance"];?></td>
	<td><?php echo date("d F Y",$row['date']); ?></td>
    <td width="10%" align="center">
	<a href="<?php print SITE_URL; ?>/update_pledges/<?php echo $row['id'];?>/view_pledges" class="table-actions-button ic-table-edit"></a>
	<?php if($_SESSION["Level"]==1 || $_SESSION["Level"]==2) { ?>
	<a href="#" onclick="javascript:confirmSubmit(<?php echo $row['id'];?>,'adjmeth_finance_pledge','view_pledges')" href="" class="table-actions-button ic-table-delete"></a>
	<?php } ?>
	</td>
	
</tr>

<?php
	}

?>
</div>
</table>
<?php
	print '<br clear="all" />';
	print '<div style="color:#ff0000;font-size:15px;"><strong>'.$counter;
	print '</strong> Pledges Found. Showing Page <strong>'.$page.'</strong> of <strong>'.$pager->getTotalPages().'</strong></div>';
	print '<br clear="all" />';
?>
	<br clear="all" />
	<div class="row">
	<div style="" align="left"><?php print $paginate; ?></div>
	<br clear="all" />
	</div>
<?php	} else {
	?>
	<tr><td colspan="5" style="font-size:18px;">No results found</td></tr>
<?php
}

}	
?>
